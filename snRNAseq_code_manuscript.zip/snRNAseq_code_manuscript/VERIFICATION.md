# Verification (2026-10-12)

`bash run_all.sh` was run in an empty directory containing only this package, the two processed objects and the
ChIP-Atlas downloads. Every output was then compared with the files used for the manuscript figures.

## Figure panels: pixel-identical PNGs

`umap_coarse_celltypes`, `dotplot_pfc_markers` (Fig. 3A–B) · `fig_augur_prioritization` (3C–D) ·
`fig3_astrocyte` (3E–H) · `fig_slc6a11_program` (3I) · `fig_nrf1_axis` (5A, 5C, 5G, S8E) ·
`fig_astro_featureplots_split` (5B) · `fig_astro_featureplots` (S8A–D) · `fig_nrf1_story2` (5D–E) ·
`fig_nrf1_program_targets` (5F) · `figS_excitatory_subtypes` (S7A–C) · `FigS7D_predefined_homeostatic_geneset` (S7D) ·
`fig_wgcna_slc6a11` (S7E–G) · `FigS8G_NRF1_ChIP_mouse`, `FigS8H_NRF1_ChIP_human` (S8G–H).
`FigS8F_NRF1_motif` (S8F) is a standalone copy of a previously embedded inset (same drawing code), so no earlier
file exists to compare it with.

## Tables and objects recomputed and identical to the published files

Astrocyte states, markers, SNI vs Sham DE and Enrichr tables; Augur AUCs (all three tables); metacells and WGCNA
modules, hub genes and module–trait correlations; turquoise-module enrichment; TF activity (differences ≤ 1e-15);
motif screen of 217 TFs, candidate-regulator evidence matrix, best-site positions, NRF1 PFM and site; OXPHOS
subunit, PGC-1α and respiratory-TF tables; Nrf1 target table; Fig. S7D gene table; ChIP-Atlas peak tables;
`excitatory_subset.h5ad` (identical cluster labels and UMAP coordinates). The supplementary data table passes all
33 checks against numbers stated in the manuscript.

## Taken from `published_results/`

`qc_summary_by_sample.csv`, `qc_thresholds.csv` (identical when `scil_reanalysis.py` is re-run),
`nrf1_axis_rank.csv` (gene ranking for GSEA; per-gene statistics identical when re-run, tied genes ordered
differently), `nrf1_axis_kegg_full.csv` and `nrf1_axis_gsea_kegg.npz` (Fig. 5A/5C).

## Differences on re-run

- `scil_reanalysis.py` from the raw matrices: QC and Scrublet results identical; Harmony embeddings differ between
  runs (harmonypy 0.2.0 is not deterministic), and 98.8% of nuclei kept their cell-type label in a test re-run.
- KEGG GSEA re-run (`nrf1_axis_kegg_full_rerun.csv`): NES equal to two decimals; FDRs within permutation
  variability (e.g. Phagosome 0.043 published, 0.05–0.06 on re-runs).
- `nrf1_axis_geneset_stats.csv`, `nrf1_axis_gsea_hero.npz` (project-defined gene sets; not shown in the
  manuscript): NES differ by ≤ 0.01 because of the tie order of the re-computed ranking.
