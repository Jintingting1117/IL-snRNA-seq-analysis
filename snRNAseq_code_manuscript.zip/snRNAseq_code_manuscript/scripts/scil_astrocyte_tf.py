#!/usr/bin/env python3
"""TF-regulon (TF-activity) analysis of PFC astrocytes — decoupler + CollecTRI (mouse).

Infers per-cell transcription-factor activity (ULM over the CollecTRI regulon prior), then:
  1. ranks the TFs that define each astrocyte substate (esp. the synapse-associated state),
  2. tests sham-vs-SNI TF-activity changes (exploratory, n=1/condition),
  3. flags 'lost-driver' candidates: TFs that mark the synapse-associated state AND decline in
     SNI (i.e. would track the depletion of that state).

pySCENIC (de-novo regulons) is available but needs the cisTarget motif databases (~1-2 GB, not
present); CollecTRI gives curated, literature-backed regulons with no large download.
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import pandas as pd
import scanpy as sc
import decoupler as dc
import warnings
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests

warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False, "legend.frameon": False})

P = {"blue": "#0F4D92", "blue2": "#3775BA", "red": "#B64342", "teal": "#2E8B8B",
     "grey_m": "#767676", "grey_d": "#4D4D4D"}
OBJ = Path("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
TAB = Path("results/scil_reanalysis/tables")
FIG = Path("results/scil_reanalysis/figures/pub")
MAIN = ["Homeostatic", "Synapse-associated", "Reactive"]


def main():
    a = sc.read_h5ad(OBJ)
    net = dc.op.collectri(organism="mouse")
    dc.mt.ulm(data=a, net=net, tmin=5)
    acts = a.obsm["score_ulm"]                     # cells x TFs
    sub = a.obs["substate"].astype(str).values
    cond = a.obs["condition"].astype(str).values
    keep = np.isin(sub, MAIN)
    acts, sub, cond = acts[keep], sub[keep], cond[keep]

    # ── per-substate mean activity + state specificity
    state_mean = pd.DataFrame({s: acts[sub == s].mean(0) for s in MAIN})   # TF x state
    state_mean.to_csv(TAB / "astro_tf_activity_by_substate.csv")
    syn_spec = state_mean["Synapse-associated"] - state_mean[["Homeostatic", "Reactive"]].mean(1)

    # ── sham vs SNI differential TF activity (exploratory)
    rows = []
    for tf in acts.columns:
        x = acts[tf].values[cond == "sham"]; y = acts[tf].values[cond == "sni"]
        p = mannwhitneyu(x, y).pvalue if x.size and y.size else np.nan
        rows.append({"TF": tf, "mean_sham": float(x.mean()), "mean_sni": float(y.mean()),
                     "delta_sni": float(y.mean() - x.mean()), "mwu_p": float(p),
                     "synapse_specificity": float(syn_spec[tf])})
    de = pd.DataFrame(rows)
    de["padj"] = multipletests(de["mwu_p"].fillna(1), method="fdr_bh")[1]
    de = de.sort_values("delta_sni")
    de.to_csv(TAB / "astro_tf_sham_vs_sni.csv", index=False)

    # ── 'lost-driver' candidates: synapse-specific AND down in SNI
    lost = de[(de.synapse_specificity > 0) & (de.delta_sni < 0) & (de.padj < 0.05)] \
        .sort_values("synapse_specificity", ascending=False)
    lost.to_csv(TAB / "astro_tf_lost_drivers.csv", index=False)

    # targets (in CollecTRI) of top lost-driver TFs that are also down-regulated DE genes
    de_genes = pd.read_csv(TAB / "astro_de_sni_vs_sham_deepdive.csv")
    down = set(de_genes[(de_genes.pvals_adj < 0.05) & (de_genes.logfoldchanges < -0.5)].names)
    syn_genes = {"Gria1", "Gria2", "Slc4a4", "Lrrc4c", "Car10", "Robo2", "Sema6d", "Slc6a11", "Slc6a1", "Slc6a9"}
    tgt_rows = []
    for tf in lost.TF.head(12):
        tg = set(net.loc[net.source == tf, "target"])
        tgt_rows.append({"TF": tf, "n_targets": len(tg),
                         "down_DE_targets": ";".join(sorted(tg & down)[:12]),
                         "synaptic_targets": ";".join(sorted(tg & syn_genes))})
    pd.DataFrame(tgt_rows).to_csv(TAB / "astro_tf_lost_driver_targets.csv", index=False)

    print("n TFs:", acts.shape[1])
    print("\n== Top synapse-associated-defining TFs ==")
    print(syn_spec.sort_values(ascending=False).head(12).round(3).to_string())
    print("\n== Top TFs DOWN in SNI (delta, padj) ==")
    print(de.head(12)[["TF", "delta_sni", "padj", "synapse_specificity"]].round(3).to_string(index=False))
    print("\n== Lost-driver candidates (synapse-high & SNI-down, padj<0.05):", len(lost), "==")
    print(lost.head(12)[["TF", "synapse_specificity", "delta_sni", "padj"]].round(3).to_string(index=False))

    figures(state_mean, syn_spec, de, lost)


def figures(state_mean, syn_spec, de, lost):
    # heatmap: top state-defining TFs x substates (z-scored per TF)
    top = []
    for s in MAIN:
        others = [o for o in MAIN if o != s]
        sc_ = state_mean[s] - state_mean[others].mean(1)
        top += sc_.sort_values(ascending=False).head(7).index.tolist()
    top = list(dict.fromkeys(top))
    M = state_mean.loc[top]
    Z = M.sub(M.mean(1), axis=0).div(M.std(1) + 1e-9, axis=0)

    fig = plt.figure(figsize=(7.2, 4.6))
    gs = fig.add_gridspec(1, 2, width_ratios=[0.85, 1.15], wspace=0.55)
    axh = fig.add_subplot(gs[0, 0])
    im = axh.imshow(Z.values, aspect="auto", cmap="RdBu_r", vmin=-1.4, vmax=1.4)
    axh.set_xticks(range(3)); axh.set_xticklabels(["Homeo.", "Synapse", "Reactive"], fontsize=6.6)
    axh.set_yticks(range(len(top))); axh.set_yticklabels(top, fontsize=6.0, style="italic")
    axh.set_title("State-defining TF activity (z)", fontsize=8, pad=4)
    for sp in axh.spines.values():
        sp.set_visible(False)
    axh.tick_params(length=0)
    cb = fig.colorbar(im, ax=axh, fraction=0.045, pad=0.04); cb.ax.tick_params(labelsize=5.5)

    # lost-driver scatter
    axs = fig.add_subplot(gs[0, 1])
    axs.scatter(de.synapse_specificity, de.delta_sni, s=6, c="#cfcfcf", linewidths=0, rasterized=True)
    sig = de[de.padj < 0.05]
    axs.scatter(sig.synapse_specificity, sig.delta_sni, s=10, c=P["grey_m"], linewidths=0)
    axs.scatter(lost.synapse_specificity, lost.delta_sni, s=26, c=P["teal"], edgecolor="white", linewidth=0.4, zorder=4)
    for _, r in lost.head(8).iterrows():
        axs.text(r.synapse_specificity, r.delta_sni, r.TF, fontsize=6.0, style="italic",
                 color=P["teal"], ha="left", va="center")
    axs.axhline(0, color=P["grey_d"], lw=0.7); axs.axvline(0, color=P["grey_d"], lw=0.7)
    axs.set_xlabel("synapse-associated specificity (TF activity)")
    axs.set_ylabel("Δ TF activity (SNI − sham)")
    axs.set_title("'Lost-driver' TFs: synapse-high & SNI-down", fontsize=8, pad=4)
    axs.text(0.98, 0.03, "candidate drivers ↘", transform=axs.transAxes, fontsize=6,
             style="italic", color=P["teal"], ha="right")

    for ax, lab in [(axh, "a"), (axs, "b")]:
        ax.text(-0.18, 1.04, lab, transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom")
    fig.text(0.5, -0.02, "Astrocyte TF activity (decoupler ULM over CollecTRI mouse regulons). "
             "n = 1 library/condition (exploratory).", ha="center", fontsize=5.2, color=P["grey_m"])
    stem = FIG / "fig_astrocyte_TF"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=400, bbox_inches="tight")
    plt.close(fig)
    print("\nwrote", stem)


if __name__ == "__main__":
    main()
