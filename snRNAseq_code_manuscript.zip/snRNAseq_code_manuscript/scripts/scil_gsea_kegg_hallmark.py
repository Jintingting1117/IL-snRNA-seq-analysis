#!/usr/bin/env python3
"""Preranked GSEA of SNI vs Sham astrocytes against KEGG 2019 Mouse and MSigDB Hallmark 2020 (Fig. 5A, 5C).

Ranking: Wilcoxon statistic (SNI vs Sham, all genes) from scil_nrf1_axis_stats.py
(tables/nrf1_axis_rank.csv). Gene sets: Enrichr libraries via gseapy (cached after the first download).
GSEApy prerank, 2,000 permutations, seed 7, gene-set size 8-1,000 (299 KEGG / 50 Hallmark terms).

Outputs (results/scil_reanalysis/tables/):
  nrf1_axis_kegg_full.csv      all KEGG terms (Fig. 5A)
  nrf1_axis_gsea_kegg.npz      running ES of KEGG Oxidative phosphorylation (Fig. 5C)
  nrf1_axis_hallmark_full.csv  all Hallmark terms
  nrf1_axis_gsea_hallmark.npz  running ES of Hallmark Oxidative Phosphorylation

About half of the genes share a ranking value (ties), so permutation FDRs can differ slightly between runs
that order tied genes differently; NES agree to two decimals with the values shown in Fig. 5A/5C.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import gseapy as gp

TAB = Path("results/scil_reanalysis/tables")
PARAMS = dict(min_size=8, max_size=1000, permutation_num=2000, seed=7, no_plot=True, outdir=None, threads=8)


def run(rnk, library, term, stem):
    pre = gp.prerank(rnk=rnk, gene_sets=library, **PARAMS)
    res = pre.res2d.rename(columns={"Term": "term", "NES": "nes", "NOM p-val": "p", "FDR q-val": "fdr"})
    for c in ["ES", "nes", "p", "fdr", "FWER p-val"]:
        res[c] = res[c].astype(float)
    res = res.sort_values("nes").reset_index(drop=True)
    res.to_csv(TAB / f"{stem}_full.csv", index=False)
    r = pre.results[term]
    hits = np.asarray(r.get("hits", r.get("hit_indices", [])), int)
    np.savez(TAB / f"nrf1_axis_gsea_{stem.split('_')[-1]}.npz", RES=np.asarray(r["RES"], float), hits=hits,
             nes=float(r["nes"]), fdr=float(r["fdr"]), rank_z=rnk["z"].to_numpy(float), nhit=len(hits))
    ox = res.set_index("term").loc[term]
    print(f"{library}: {len(res)} terms; {term}: NES {ox.nes:.2f}, FDR {ox.fdr:.3g}, n={len(hits)}")


def main():
    rk = pd.read_csv(TAB / "nrf1_axis_rank.csv")[["gene", "z"]].dropna()
    run(rk, "KEGG_2019_Mouse", "Oxidative phosphorylation", "nrf1_axis_kegg")
    hk = rk.assign(gene=rk["gene"].str.upper()).drop_duplicates("gene")      # human-symbol library
    hk = hk.sort_values("z", ascending=False).reset_index(drop=True)
    run(hk, "MSigDB_Hallmark_2020", "Oxidative Phosphorylation", "nrf1_axis_hallmark")


if __name__ == "__main__":
    main()
