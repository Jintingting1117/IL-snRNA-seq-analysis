#!/usr/bin/env python3
"""Subtype-matched Augur: decompose sham-vs-SNI separability into composition vs cell-intrinsic.

For each coarse cell type we report three AUCs:
  - total_auc      : Augur on all cells of the type (= composition + intrinsic). From scil_augur.py.
  - composition_auc: predict condition from SUBTYPE (Leiden cluster) identity alone. High => the
                     separability is mostly "which subtypes were captured per group" (composition).
  - intrinsic_auc  : Augur run WITHIN each matched subtype (same Leiden cluster, balanced sham vs SNI)
                     then aggregated. Holds composition constant => reflects the same subtype changing.

Goal: test whether the top-ranked neuron signal is compositional (subtypes segregate by condition,
intrinsic AUC drops) while astrocytes stay high on the intrinsic axis (shared subtypes that change).
n=1/condition caveat still applies to every AUC (batch vs biology cannot be separated).
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
os.environ.setdefault("OMP_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import warnings
from scipy import sparse
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score

warnings.simplefilter("ignore")

matplotlib.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42, "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans"], "font.size": 11, "axes.linewidth": 0.8,
})

OBJ = Path("results/scil_reanalysis/objects/scil_reanalysis_annotated.h5ad")
TAB = Path("results/scil_reanalysis/tables")
FIG = Path("results/scil_reanalysis/figures/pub")
COARSE = TAB / "augur_celltype_auc.csv"

MIN_PER_COND = 40
N_PER_COND = 40
N_SUBSAMPLES = 30
N_TREES = 100
N_FOLDS = 3
SEED = 0
DROP = ["Doublet_cluster", "Low_quality_Unknown", "Unknown"]


def get_features(adata):
    a = adata.copy()
    vl = a.var_names.str.lower()
    techy = (np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl")))
             | np.asarray(vl.str.match(r"^hb[ab]")))
    a = a[:, ~techy].copy()
    if "highly_variable" in a.var and a.var["highly_variable"].sum() >= 500:
        hv = a.var["highly_variable"].fillna(False).to_numpy()
    else:
        sc.pp.highly_variable_genes(a, n_top_genes=min(2000, a.n_vars), flavor="seurat")
        hv = a.var["highly_variable"].to_numpy()
    a = a[:, hv].copy()
    X = a.X.toarray() if sparse.issparse(a.X) else np.asarray(a.X)
    return X.astype(np.float32)


def auc_subset(X, y, rng):
    i0 = rng.choice(np.where(y == 0)[0], N_PER_COND, replace=False)
    i1 = rng.choice(np.where(y == 1)[0], N_PER_COND, replace=False)
    idx = np.concatenate([i0, i1])
    clf = RandomForestClassifier(n_estimators=N_TREES, n_jobs=4, random_state=int(rng.integers(1e6)))
    cv = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=int(rng.integers(1e6)))
    proba = cross_val_predict(clf, X[idx], y[idx], cv=cv, method="predict_proba")[:, 1]
    return roc_auc_score(y[idx], proba)


def within_cluster_auc(X, y, rng):
    n0, n1 = int((y == 0).sum()), int((y == 1).sum())
    if n0 < MIN_PER_COND or n1 < MIN_PER_COND:
        return None
    return float(np.mean([auc_subset(X, y, rng) for _ in range(N_SUBSAMPLES)]))


def composition_auc(condition, leiden):
    """AUC from predicting condition using subtype identity alone (cluster's SNI fraction as score)."""
    y = (condition == "sni").astype(int).to_numpy()
    frac = pd.Series(y, index=leiden.index).groupby(leiden.to_numpy()).transform("mean").to_numpy()
    if len(np.unique(y)) < 2 or np.ptp(frac) == 0:
        return np.nan
    return float(roc_auc_score(y, frac))


def main():
    adata = sc.read_h5ad(OBJ)
    adata = adata[~adata.obs["celltype_final"].astype(str).isin(DROP)].copy()
    X = get_features(adata)
    rng = np.random.default_rng(SEED)

    ct = adata.obs["celltype_final"].astype(str).to_numpy()
    cond = adata.obs["condition"].astype(str)
    leiden = adata.obs["leiden"].astype(str)
    y = (cond == "sni").astype(int).to_numpy()

    coarse = pd.read_csv(COARSE).set_index("celltype")["mean_auc"].to_dict() if COARSE.exists() else {}

    # Per-cluster intrinsic AUC.
    clu_rows = []
    for cl in sorted(pd.unique(leiden)):
        m = (leiden == cl).to_numpy()
        a = within_cluster_auc(X[m], y[m], rng)
        clu_rows.append({"leiden": cl, "celltype": pd.Series(ct[m]).mode()[0],
                         "n_sham": int((y[m] == 0).sum()), "n_sni": int((y[m] == 1).sum()),
                         "within_cluster_auc": a})
    clu = pd.DataFrame(clu_rows)
    clu.to_csv(TAB / "augur_within_cluster_auc.csv", index=False)

    # Aggregate per cell type.
    rows = []
    for c in sorted(pd.unique(ct)):
        m = (ct == c)
        comp = composition_auc(cond[m], leiden[m])
        sub = clu[(clu.celltype == c) & clu.within_cluster_auc.notna()]
        # cell-weighted mean intrinsic AUC across that type's matchable subtypes
        if len(sub):
            w = (sub.n_sham + sub.n_sni).to_numpy(float)
            intrinsic = float(np.average(sub.within_cluster_auc.to_numpy(), weights=w))
            cov = float((sub.n_sham + sub.n_sni).sum() / m.sum())
        else:
            intrinsic, cov = np.nan, 0.0
        rows.append({"celltype": c, "n_cells": int(m.sum()),
                     "total_auc": coarse.get(c, np.nan), "composition_auc": comp,
                     "intrinsic_auc": intrinsic, "n_matched_subtypes": int(len(sub)),
                     "matched_coverage": round(cov, 3)})
    res = pd.DataFrame(rows).sort_values("total_auc", ascending=False)
    res.to_csv(TAB / "augur_decomposition.csv", index=False)
    pd.set_option("display.width", 200)
    print(res.round(3).to_string(index=False))

    plot(res)


def plot(res):
    d = res[res.total_auc.notna()].sort_values("total_auc")
    yy = np.arange(len(d))
    h = 0.26
    fig, ax = plt.subplots(figsize=(7.6, 0.62 * len(d) + 1.4))
    ax.barh(yy + h, d.total_auc - 0.5, left=0.5, height=h, color="#27408b", label="Total (all cells)")
    ax.barh(yy, d.composition_auc - 0.5, left=0.5, height=h, color="#d1813f", label="Composition (subtype identity)")
    ax.barh(yy - h, d.intrinsic_auc - 0.5, left=0.5, height=h, color="#3a9c54", label="Cell-intrinsic (within subtype)")
    ax.axvline(0.5, color="black", lw=0.8)
    ax.set_yticks(yy); ax.set_yticklabels(d.celltype)
    ax.set_xlim(0.5, 1.0)
    ax.set_xlabel("AUC (sham vs SNI)")
    ax.set_title("Condition separability: composition vs cell-intrinsic", fontsize=12)
    ax.legend(frameon=False, fontsize=8.6, loc="lower right")
    for i, (_, r) in enumerate(d.iterrows()):
        if np.isfinite(r.intrinsic_auc):
            ax.text(r.intrinsic_auc + 0.006, i - h, f"{r.intrinsic_auc:.2f}", va="center", fontsize=7.5)
    fig.tight_layout()
    fig.savefig(FIG / "augur_decomposition.pdf", bbox_inches="tight")
    fig.savefig(FIG / "augur_decomposition.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("Wrote", FIG / "augur_decomposition.(png/pdf)")


if __name__ == "__main__":
    main()
