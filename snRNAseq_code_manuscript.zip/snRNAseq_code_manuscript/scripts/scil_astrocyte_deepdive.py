#!/usr/bin/env python3
"""Astrocyte deep-dive: clean subset -> substates -> within-astrocyte DE + pathway enrichment.

Step 0  Define a clean, COMPLETE astrocyte set. Pool high-confidence astrocyte clusters,
        gate per-cell on astrocyte-dominant signal (drop neuron/oligo doublets, low-complexity
        nuclei), and run a completeness check so reactive astrocytes hiding elsewhere are not lost.
Step 1  Recluster astrocytes with AMBIENT genes excluded from HVG (pervasive neuronal/oligo
        ambient in snRNA must not drive 'states'); Harmony on sample.
Step 2  Characterize substates: markers, homeostatic/reactive/transport/hypoxia scores,
        sham-vs-SNI composition.
Step 3  Mechanism: within-astrocyte DE (sham vs SNI, mt/ribo/ambient excluded, effect-size first)
        + GO/KEGG enrichment (Enrichr, mouse) + a targeted inhibitory-transmitter-transport test.

Design limit: 1 library/condition -> all sham-vs-SNI results are EXPLORATORY (batch-confounded).

--from-object  start from an existing objects/astrocytes_deepdive.h5ad (keeps its Harmony embedding,
               clusters and UMAP; Harmony is not bit-reproducible between runs) and recompute Steps 2-3 only.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
os.environ.setdefault("OMP_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
import warnings
from scipy import sparse
import harmonypy

warnings.simplefilter("ignore")
sc.settings.verbosity = 1

OBJ = Path("results/scil_reanalysis/objects/scil_reanalysis_annotated.h5ad")
OUT = Path("results/scil_reanalysis")
TAB = OUT / "tables"
FIG = OUT / "figures/astro_deepdive"
OBJD = OUT / "objects"
for d in (TAB, FIG, OBJD):
    d.mkdir(parents=True, exist_ok=True)

SEED = 0

# Genes excluded from HVG/clustering and DE: contaminant-lineage ambient + technical + ubiquitous.
AMBIENT_LINEAGE = [
    "Snap25", "Syt1", "Rbfox3", "Meg3", "Stmn2", "Nrgn", "Map1b", "Syp",   # neuronal
    "Plp1", "Mbp", "Mog", "Mobp", "Mal", "Cldn11",                          # oligo
    "Pdgfra", "Cspg4",                                                       # OPC
    "Csf1r", "P2ry12", "Cx3cr1", "C1qa", "C1qb",                            # microglia
    "Cldn5", "Flt1", "Rgs5",                                                 # vascular
]
UBIQUITOUS = ["Malat1", "Xist", "Gm42418", "Gm26917", "AY036118", "Gm10754", "Gm26871", "Kcnq1ot1"]

# Astrocyte biology gene sets (scoring + targeted test).
SETS = {
    "homeostatic": ["Aqp4", "Aldh1l1", "Slc1a2", "Slc1a3", "Glul", "Gja1", "Sox9", "Fgfr3", "Ndrg2"],
    "reactive": ["Gfap", "Vim", "Serpina3n", "C3", "Lcn2", "Timp1", "Cp", "Cd44", "Osmr", "Hspb1"],
    "gaba_glycine_transport": ["Slc6a11", "Slc6a1", "Slc6a9", "Slc6a13"],
    "glutamate_transport": ["Slc1a2", "Slc1a3"],
    "hypoxia": ["Hif1a", "Vegfa", "Slc2a1", "Ldha", "Pdk1", "Bnip3", "Ndrg1", "Egln1", "P4ha1"],
}


def dense(x):
    return np.asarray(x.todense()).ravel() if sparse.issparse(x) else np.asarray(x).ravel()


def gv(a, g):
    return dense(a[:, g].X) if g in a.var_names else np.zeros(a.n_obs)


def present(a, genes):
    s = set(a.var_names)
    return [g for g in genes if g in s]


def run_harmony(a, key, basis="X_pca", adj="X_pca_harmony"):
    x = np.asarray(a.obsm[basis]).astype(np.float64)
    out = harmonypy.run_harmony(x, a.obs, key, random_state=SEED, device="cpu")
    z = np.asarray(out.Z_corr)
    a.obsm[adj] = (z if z.shape == x.shape else z.T).astype(np.float32)


# ───────────────────────────────── Step 0: clean, complete astrocyte set
def define_astrocytes(adata):
    # Completeness check: astro-identity vs pan-neuron score across ALL cells.
    sc.tl.score_genes(adata, present(adata, ["Aqp4", "Slc1a3", "Gja1", "Aldh1l1"]), score_name="astro_id", use_raw=False)
    sc.tl.score_genes(adata, present(adata, ["Snap25", "Syt1", "Rbfox3"]), score_name="neuron_id", use_raw=False)
    in_astro_clusters = (
        adata.obs["major_celltype"].astype(str).eq("Astrocyte")
        & adata.obs["cluster_confidence"].astype(str).eq("high_conf")
        & (~adata.obs["putative_doublet_cluster"].to_numpy())
    )
    astro_like = (adata.obs["astro_id"] > 0.5) & (adata.obs["astro_id"] > adata.obs["neuron_id"])
    outside = int((astro_like & ~in_astro_clusters).sum())
    rescue_breakdown = (
        adata.obs.loc[astro_like & ~in_astro_clusters, "celltype_final"].astype(str).value_counts().head(6).to_dict()
    )
    print(f"[completeness] astro-like cells OUTSIDE astrocyte clusters: {outside} "
          f"({100*outside/max(1,int(astro_like.sum())):.1f}% of astro-like). Top labels: {rescue_breakdown}")

    a = adata[in_astro_clusters].copy()
    # Strict per-cell purity: astrocyte signal must dominate contaminants.
    astro_sig = gv(a, "Slc1a3") + gv(a, "Aqp4") + gv(a, "Gja1")
    neuron_sig = gv(a, "Snap25") + gv(a, "Syt1")
    oligo_sig = gv(a, "Plp1") + gv(a, "Mbp")
    opc_sig = gv(a, "Pdgfra")
    keep = (
        ((gv(a, "Aqp4") > 0) | (gv(a, "Slc1a3") > 0))
        & (astro_sig > neuron_sig) & (astro_sig > oligo_sig) & (astro_sig > opc_sig)
        & (a.obs["doublet_score"].to_numpy() < 0.2)
        & (a.obs["n_genes_by_counts"].to_numpy() >= 500)
    )
    print(f"[purity] {int(keep.sum())}/{a.n_obs} astrocytes pass strict per-cell purity "
          f"({a.n_obs-int(keep.sum())} dropped).")
    a = a[keep].copy()
    print(f"[clean astro] {a.n_obs} cells | sham {(a.obs.condition=='sham').sum()} / sni {(a.obs.condition=='sni').sum()}")
    return a


# ───────────────────────────────── Step 1: ambient-aware reclustering
def recluster(a, resolution=0.3):
    a.X = a.layers["counts"].copy()
    sc.pp.normalize_total(a, target_sum=1e4)
    sc.pp.log1p(a)
    a.raw = a

    vl = a.var_names.str.lower()
    tech = np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl"))) | np.asarray(vl.str.match(r"^hb[ab]"))
    exclude = set(AMBIENT_LINEAGE) | set(UBIQUITOUS) | set(a.var_names[tech])
    sc.pp.highly_variable_genes(a, n_top_genes=1500, flavor="seurat", batch_key="sample")
    hv = a.var["highly_variable"].fillna(False).to_numpy() & ~np.asarray(a.var_names.isin(exclude))
    a.var["use_for_clustering"] = hv
    print(f"[HVG] {hv.sum()} genes used (excluded {a.var['highly_variable'].sum()-hv.sum()} ambient/technical)")

    sub = a[:, hv].copy()
    sc.pp.scale(sub, max_value=10)
    sc.tl.pca(sub, n_comps=30, svd_solver="arpack", random_state=SEED)
    run_harmony(sub, "sample")
    sc.pp.neighbors(sub, n_neighbors=15, n_pcs=30, use_rep="X_pca_harmony", random_state=SEED)
    sc.tl.umap(sub, random_state=SEED)
    sc.tl.leiden(sub, resolution=resolution, key_added="leiden_sub", random_state=SEED, flavor="igraph", n_iterations=2)
    a.obs["leiden_sub"] = sub.obs["leiden_sub"].astype(str).astype("category")
    a.obsm["X_umap"] = sub.obsm["X_umap"]
    a.obsm["X_pca_harmony"] = sub.obsm["X_pca_harmony"]
    print("[raw clusters]", a.obs["leiden_sub"].value_counts().to_dict())
    return a


# De-novo marker programs for NAMING (independent of the GABA-transport hypothesis genes).
# Derived from each cluster's own rank_genes_groups markers, NOT from Slc6a11/Slc6a1/Slc6a9.
DENOVO = {
    "synapse": ["Gria1", "Gria2", "Slc4a4", "Lrrc4c", "Car10", "Robo2", "Sema6d", "Shisa9", "Zfhx4"],
    "reactive": ["Gfap", "Apoe", "Sparcl1", "Vim", "Id3", "Myoc", "Serpina3n", "Nrp2"],
}


def name_substates(a):
    """Name clusters by their OWN de-novo marker programs (synapse-associated vs reactive),
    NOT by the transport score — so the labelling does not assume the mechanism. Tiny clusters
    (<50) -> Low-quality. The GABA/glycine-transport phenotype is reported downstream as a
    property of the (independently named) synapse-associated state."""
    for prog, genes in DENOVO.items():
        sc.tl.score_genes(a, present(a, genes), score_name=f"dn_{prog}", use_raw=False)
    names, rows = {}, []
    for c in a.obs["leiden_sub"].cat.categories:
        m = (a.obs["leiden_sub"] == c).to_numpy()
        if m.sum() == 0:
            continue
        n = int(m.sum())
        syn = float(a.obs.loc[m, "dn_synapse"].mean())
        react = float(a.obs.loc[m, "dn_reactive"].mean())
        rows.append((c, n, round(syn, 3), round(react, 3)))
        # A cluster is 'activated' only if its dominant de-novo program is clearly high
        # (>0.6) and dominates the other (margin >0.3); otherwise it is Homeostatic.
        if n < 50:
            names[c] = "Low-quality"
        elif syn > 0.6 and syn - react > 0.3:
            names[c] = "Synapse-associated"
        elif react > 0.6 and react - syn > 0.3:
            names[c] = "Reactive"
        else:
            names[c] = "Homeostatic"
    print("[de-novo scores per cluster (cluster, n, synapse, reactive)]", rows)
    order = ["Homeostatic", "Synapse-associated", "Reactive", "Low-quality"]
    present_cats = [o for o in order if o in set(names.values())]
    a.obs["substate"] = pd.Categorical(a.obs["leiden_sub"].map(names), categories=present_cats, ordered=True)
    print("[named substates]", a.obs["substate"].value_counts().reindex(present_cats).to_dict())
    return a


# ───────────────────────────────── Step 2: characterize substates
def characterize(a):
    for name, genes in SETS.items():
        g = present(a, genes)
        if g:
            sc.tl.score_genes(a, g, score_name=f"score_{name}", use_raw=False)

    name_substates(a)

    sc.tl.rank_genes_groups(a, "substate", method="wilcoxon", use_raw=False, n_genes=40)
    marks = []
    for s in a.obs["substate"].cat.categories:
        d = sc.get.rank_genes_groups_df(a, group=s).head(25).assign(substate=s)
        marks.append(d)
    pd.concat(marks, ignore_index=True).to_csv(TAB / "astro_substate_markers.csv", index=False)

    score_cols = [f"score_{k}" for k in SETS]
    genes_show = ["Slc6a11", "Slc6a1", "Slc6a9", "Aqp4", "Gja1", "Gfap", "Slc1a2", "Slc1a3"]
    rows = []
    for s in a.obs["substate"].cat.categories:
        m = (a.obs["substate"] == s).to_numpy()
        sub = a[m]
        row = {"substate": s, "n_cells": int(m.sum()),
               "pct_sni": 100 * float((sub.obs["condition"].astype(str) == "sni").mean())}
        for c in score_cols:
            row[c] = float(sub.obs[c].mean())
        for g in genes_show:
            if g in a.var_names:
                row[g] = float(np.mean(gv(sub, g)))
        rows.append(row)
    summ = pd.DataFrame(rows).set_index("substate")
    summ.to_csv(TAB / "astro_substate_summary.csv")
    print("\n[substate summary]\n", summ.round(3).to_string())

    comp = pd.crosstab(a.obs["substate"], a.obs["condition"])
    comp_pct = comp.div(comp.sum(0), axis=1) * 100  # within-condition % (composition)
    comp.to_csv(TAB / "astro_substate_counts_by_condition.csv")
    comp_pct.round(2).to_csv(TAB / "astro_substate_pct_within_condition.csv")
    return a


# ───────────────────────────────── Step 3: DE + enrichment
def de_and_enrichment(a):
    aa = a.copy()
    aa.obs["condition"] = aa.obs["condition"].astype(str).astype("category")
    vl = aa.var_names.str.lower()
    tech = np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl"))) | np.asarray(vl.str.match(r"^hb[ab]"))
    drop = np.asarray(aa.var_names.isin(set(UBIQUITOUS))) | tech
    aa = aa[:, ~drop].copy()
    sc.tl.rank_genes_groups(aa, "condition", groups=["sni"], reference="sham",
                            method="wilcoxon", use_raw=False, pts=True, n_genes=aa.n_vars)
    de = sc.get.rank_genes_groups_df(aa, group="sni").sort_values("pvals_adj")
    de.to_csv(TAB / "astro_de_sni_vs_sham_deepdive.csv", index=False)

    sig = de[de.pvals_adj < 0.05]
    up = sig[sig.logfoldchanges > 0.5].names.tolist()
    down = sig[sig.logfoldchanges < -0.5].names.tolist()
    print(f"\n[DE] up={len(up)} down={len(down)} (padj<0.05, |log2FC|>0.5)")

    # Targeted: inhibitory-transmitter transport axis
    tgt = present(a, SETS["gaba_glycine_transport"] + SETS["glutamate_transport"])
    trows = []
    for g in tgt:
        r = de[de.names == g]
        if len(r):
            trows.append({"gene": g, "log2FC": float(r.logfoldchanges.iloc[0]),
                          "pvals_adj": float(r.pvals_adj.iloc[0]),
                          "pct_sni": float(r.pct_nz_group.iloc[0]) if "pct_nz_group" in r else np.nan,
                          "pct_sham": float(r.pct_nz_reference.iloc[0]) if "pct_nz_reference" in r else np.nan})
    pd.DataFrame(trows).to_csv(TAB / "astro_transport_axis_de.csv", index=False)
    print("[transport axis]\n", pd.DataFrame(trows).round(4).to_string(index=False))

    # Pathway enrichment via Enrichr (mouse)
    enrich_results = {}
    try:
        import gseapy as gp
        libs = ["GO_Biological_Process_2021", "KEGG_2019_Mouse"]
        for direction, genes in [("down_in_sni", down), ("up_in_sni", up)]:
            if len(genes) < 8:
                print(f"[enrichr] {direction}: only {len(genes)} genes, skipping")
                continue
            enr = gp.enrichr(gene_list=genes, gene_sets=libs, organism="mouse", outdir=None)
            res = enr.results.sort_values("Adjusted P-value")
            res.to_csv(TAB / f"astro_enrichr_{direction}.csv", index=False)
            enrich_results[direction] = res
            print(f"\n[enrichr {direction}] top terms:")
            print(res.head(8)[["Gene_set", "Term", "Adjusted P-value", "Genes"]].to_string(index=False)[:1200])
    except Exception as e:
        print("[enrichr] failed:", type(e).__name__, e)
    return de, enrich_results


# ───────────────────────────────── diagnostic figures (publication versions later)
def figures(a, de):
    sns.set_theme(style="whitegrid")
    for color, fn in [("substate", "astro_umap_substate.png"), ("condition", "astro_umap_condition.png")]:
        sc.pl.umap(a, color=color, show=False, frameon=False)
        plt.savefig(FIG / fn, dpi=200, bbox_inches="tight"); plt.close("all")

    panel = present(a, ["Aqp4", "Gja1", "Slc1a2", "Slc1a3", "Glul", "Gfap", "Vim",
                        "Slc6a11", "Slc6a1", "Slc6a9"])
    sc.pl.dotplot(a, panel, groupby="substate", standard_scale="var", show=False)
    plt.savefig(FIG / "astro_substate_dotplot.png", dpi=200, bbox_inches="tight"); plt.close("all")

    comp = pd.crosstab(a.obs["condition"], a.obs["substate"])
    (comp.div(comp.sum(1), axis=0) * 100).plot(kind="bar", stacked=True, colormap="viridis", figsize=(6, 4))
    plt.ylabel("% of astrocytes"); plt.xlabel(""); plt.legend(bbox_to_anchor=(1.02, 1), frameon=False)
    plt.tight_layout(); plt.savefig(FIG / "astro_substate_proportions.png", dpi=200); plt.close("all")

    for g in ["Slc6a11", "Slc6a1", "Slc6a9"]:
        if g in a.var_names:
            df = a.obs[["condition"]].copy(); df[g] = gv(a, g)
            plt.figure(figsize=(3.6, 3.8))
            sns.violinplot(data=df, x="condition", y=g, cut=0, inner="quartile", order=["sham", "sni"])
            plt.title(g); plt.tight_layout(); plt.savefig(FIG / f"astro_{g.lower()}_violin.png", dpi=200); plt.close("all")

    d = de.copy()
    d["nlp"] = -np.log10(d.pvals_adj.replace(0, np.nextafter(0, 1)).clip(lower=np.nextafter(0, 1)))
    hl = set(SETS["gaba_glycine_transport"] + SETS["glutamate_transport"] + ["Gfap", "Vim"])
    plt.figure(figsize=(6, 5))
    plt.scatter(d.logfoldchanges, d.nlp, s=6, c="#bbbbbb", linewidths=0)
    sub = d[d.names.isin(hl)]
    plt.scatter(sub.logfoldchanges, sub.nlp, s=22, c="#c44e52")
    for _, r in sub.iterrows():
        plt.text(r.logfoldchanges, r.nlp, r.names, fontsize=7)
    plt.axvline(0, color="k", lw=0.6); plt.xlabel("log2FC (SNI vs sham)"); plt.ylabel("-log10 adj p")
    plt.tight_layout(); plt.savefig(FIG / "astro_de_volcano.png", dpi=200); plt.close("all")


def main():
    p = argparse.ArgumentParser(description="Astrocyte deep-dive")
    p.add_argument("--from-object", action="store_true",
                   help="reuse objects/astrocytes_deepdive.h5ad and recompute only Steps 2-3")
    args = p.parse_args()
    if args.from_object:
        a = sc.read_h5ad(OBJD / "astrocytes_deepdive.h5ad")
    else:
        adata = sc.read_h5ad(OBJ)
        a = define_astrocytes(adata)
        a = recluster(a)
    a = characterize(a)
    de, enr = de_and_enrichment(a)
    figures(a, de)
    if not args.from_object:
        a.write_h5ad(OBJD / "astrocytes_deepdive.h5ad", compression="gzip")
    print("\nDONE -> astrocytes_deepdive.h5ad + tables/figures")


if __name__ == "__main__":
    main()
