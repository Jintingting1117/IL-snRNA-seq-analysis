#!/usr/bin/env python3
"""Publication figure: Augur cell-type prioritization motivating the astrocyte focus.

Panel a: Augur ranking (total AUC, sham vs SNI) with permutation null.
Panel b (hero): composition vs cell-intrinsic AUC. Points above the diagonal separate the
conditions via a cell-INTRINSIC program (astrocyte); points below are COMPOSITION-driven
(inhibitory neuron). Single-subtype cell types have composition AUC = 0.5 by definition.

Backend: Python/matplotlib (nature-figure skill). Editable-text SVG/PDF + PNG + TIFF.
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# ── MANDATORY editable-text rules (nature-figure) ──────────────────────────────
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({
    "font.size": 7, "axes.linewidth": 0.8,
    "axes.spines.right": False, "axes.spines.top": False, "legend.frameon": False,
    "xtick.major.width": 0.8, "ytick.major.width": 0.8,
})

PALETTE = {
    "blue_main": "#0F4D92", "blue_secondary": "#3775BA", "red_strong": "#B64342",
    "neutral_light": "#CFCECE", "neutral_mid": "#767676", "neutral_dark": "#4D4D4D",
}
TAB = Path("results/scil_reanalysis/tables")
OUT = Path("results/scil_reanalysis/figures/pub")
OUT.mkdir(parents=True, exist_ok=True)

MIN_N = 250  # exclude underpowered cell types (only VLMC/Fibroblast, n=182) for AUC stability

DISPLAY = {
    "Inhibitory_neuron": "Inhibitory neuron", "Excitatory_neuron": "Excitatory neuron",
    "Astrocyte": "Astrocyte", "Oligodendrocyte": "Oligodendrocyte", "OPC": "OPC",
    "Microglia": "Microglia", "Endothelial": "Endothelial",
    "Fibroblast_meningeal": "VLMC/Fibroblast",
}
SHORT = {
    "Inhibitory_neuron": "InN", "Excitatory_neuron": "ExN", "Astrocyte": "Astro",
    "Oligodendrocyte": "Oligo", "OPC": "OPC", "Microglia": "Micro",
    "Endothelial": "Endo", "Fibroblast_meningeal": "VLMC",
}


def load():
    coarse = pd.read_csv(TAB / "augur_celltype_auc.csv")
    dec = pd.read_csv(TAB / "augur_decomposition.csv")
    df = coarse.merge(dec[["celltype", "composition_auc", "intrinsic_auc", "n_cells"]],
                      on="celltype", how="left")
    # single-subtype types have no within-type composition signal -> 0.5 by definition
    df["composition_auc"] = df["composition_auc"].fillna(0.5)
    return df


def panel_a(ax, df):
    d = df.sort_values("mean_auc").reset_index(drop=True)
    y = np.arange(len(d))
    for i, r in d.iterrows():
        hero = r.celltype == "Astrocyte"
        col = PALETTE["red_strong"] if hero else PALETTE["blue_main"]
        ax.plot([0.5, r.mean_auc], [i, i], color=PALETTE["neutral_light"], lw=1.4, zorder=1)
        ax.errorbar(r.mean_auc, i, xerr=r.std_auc, fmt="o", ms=6 if hero else 4.5,
                    color=col, ecolor=PALETTE["neutral_mid"], elinewidth=0.8, capsize=1.6, zorder=3)
        ax.plot(r.mean_auc_perm, i, marker="|", ms=6, color=PALETTE["neutral_mid"], mew=1.0, zorder=2)
    ax.set_yticks(y)
    ax.set_yticklabels([DISPLAY[c] for c in d.celltype])
    for tl, c in zip(ax.get_yticklabels(), d.celltype):
        if c == "Astrocyte":
            tl.set_color(PALETTE["red_strong"])
            tl.set_fontweight("bold")
    ax.axvline(0.5, color=PALETTE["neutral_dark"], lw=0.8)
    ax.set_xlim(0.5, 1.0)
    ax.set_xticks([0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
    ax.set_xlabel("Augur AUC (sham vs SNI)")
    ax.set_title("Cell-type prioritization", fontsize=8, pad=4)
    # legend proxies
    ax.plot([], [], "o", color=PALETTE["blue_main"], ms=4.5, label="cell type (mean ± s.d.)")
    ax.plot([], [], marker="|", color=PALETTE["neutral_mid"], ls="none", ms=6, label="permuted null")
    ax.legend(loc="lower right", fontsize=5.8, handletextpad=0.4, borderaxespad=0.3)


def panel_b(ax, df):
    sizes = 6 + np.sqrt(df["n_cells"].to_numpy()) * 2.2
    # diagonal + zones
    ax.plot([0.5, 1.0], [0.5, 1.0], ls="--", lw=0.9, color=PALETTE["neutral_mid"], zorder=1)
    ax.axvline(0.5, color=PALETTE["neutral_light"], lw=0.8, ls=":", zorder=0)
    ax.text(0.515, 0.985, "cell-intrinsic responders", fontsize=6.2, style="italic",
            color=PALETTE["neutral_dark"], va="top")
    ax.text(0.985, 0.585, "composition-\ndriven", fontsize=6.2, style="italic",
            color=PALETTE["neutral_dark"], ha="right", va="bottom")
    for _, r in df.iterrows():
        hero = r.celltype == "Astrocyte"
        col = PALETTE["red_strong"] if hero else PALETTE["blue_secondary"]
        s = (6 + np.sqrt(r.n_cells) * 2.2)
        ax.scatter(r.composition_auc, r.intrinsic_auc, s=s * (1.6 if hero else 1.0),
                   color=col, edgecolor="white", linewidth=0.6, zorder=4 if hero else 3,
                   alpha=0.95)
    # labels with manual nudges to avoid overlap
    nudge = {"Microglia": (0.008, 0.012), "Oligodendrocyte": (0.008, -0.018),
             "Endothelial": (0.008, 0.0), "OPC": (0.008, -0.004),
             "Excitatory_neuron": (0.01, -0.004), "Inhibitory_neuron": (-0.012, 0.012),
             "Astrocyte": (-0.03, 0.0), "Fibroblast_meningeal": (0.01, 0.0)}
    for _, r in df.iterrows():
        dx, dy = nudge.get(r.celltype, (0.008, 0.006))
        hero = r.celltype == "Astrocyte"
        ha = "right" if r.celltype in ("Inhibitory_neuron", "Astrocyte") else "left"
        ax.text(r.composition_auc + dx, r.intrinsic_auc + dy, SHORT[r.celltype],
                fontsize=6.6 if hero else 6.0, ha=ha, va="center",
                color=PALETTE["red_strong"] if hero else PALETTE["neutral_dark"],
                fontweight="bold" if hero else "normal")
    # annotate astrocyte as the focus
    ax.annotate("intrinsic responder\n→ mechanism focus",
                xy=(0.622, 0.860), xytext=(0.70, 0.965), fontsize=6.0,
                color=PALETTE["red_strong"], ha="left", va="top",
                arrowprops=dict(arrowstyle="-|>", color=PALETTE["red_strong"], lw=0.9,
                                shrinkA=0, shrinkB=4))
    ax.set_xlim(0.48, 1.0)
    ax.set_ylim(0.55, 1.0)
    ax.set_xlabel("Composition AUC  (subtype identity alone)")
    ax.set_ylabel("Cell-intrinsic AUC  (within matched subtype)")
    ax.set_title("Composition vs cell-intrinsic separability", fontsize=8, pad=4)


def main():
    df = load()
    df = df[df.celltype.isin(DISPLAY)].copy()
    dropped = df[df.n_cells < MIN_N]
    df = df[df.n_cells >= MIN_N].copy()
    if len(dropped):
        print("excluded (n <", MIN_N, "):", dict(zip(dropped.celltype, dropped.n_cells)))
    fig = plt.figure(figsize=(7.2, 3.15))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.25], wspace=0.42)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    panel_a(ax_a, df)
    panel_b(ax_b, df)
    for ax, lab in [(ax_a, "a"), (ax_b, "b")]:
        ax.text(-0.16, 1.06, lab, transform=ax.transAxes, fontsize=8, fontweight="bold",
                ha="left", va="bottom")
    fig.text(0.5, -0.02,
             "Augur AUC: random-forest cross-validation on balanced sham/SNI subsamples (50×); "
             "null = permuted condition labels. Point size ∝ √(nuclei). VLMC/Fibroblast (n=182) "
             "excluded for AUC stability. n=1 library/condition (exploratory).",
             ha="center", fontsize=5.2, color=PALETTE["neutral_mid"])
    stem = OUT / "fig_augur_prioritization"
    fig.savefig(f"{stem}.svg", bbox_inches="tight")
    fig.savefig(f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=400, bbox_inches="tight")
    fig.savefig(f"{stem}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem, "(.svg/.pdf/.png/.tiff)")


if __name__ == "__main__":
    main()
