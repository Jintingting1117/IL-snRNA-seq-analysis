#!/usr/bin/env python3
"""Figure S8G/H as editable vector panels: public NRF1 ChIP-seq at mouse Slc6a11 / human SLC6A11.

Same data, coordinates and layout as the manuscript panels, with the gene model corrected:
exon 1 of Slc6a11 is 279 bp (mm10 chr6:114,131,239-114,131,517; ENSMUST00000032451 / NM_172890.3),
so the +412 NRF1 motif lies in intron 1. Human exon 1: hg38 chr3:10,816,201-10,816,521
(ENST00000454147); motif +409 lies in intron 1.

draw(fig, P, cfg, letter) renders one panel; main() writes the G and H panels (PDF/SVG/600-dpi PNG)
at final print size.
"""
from __future__ import annotations
import os, sys
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pyBigWig
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scil_panel_box import Panel

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42

ROOT = Path(__file__).resolve().parents[1]
BW = ROOT / "results/scil_reanalysis/chip_bigwig"
OUT = ROOT / "results/scil_reanalysis/figures/revision_1011"
NAVY, SIG, PEAK, MOTIF = "#22314E", "#3A6EA5", "#22314E", "#E4572E"
SLOT_DPI = 220
SLOTS = {"G": (0, 672, 647, 1050), "H": (647, 672, 1268, 1050)}   # panel boxes in px at 220 dpi (sets panel size)

MOUSE = dict(
    title="Mouse  Slc6a11   ·   NRF1 ChIP-seq (ChIP-Atlas)", gene="Slc6a11 →",
    chrom="chr6", win=(114130300, 114132700), tss=114131239, exon1=(114131239, 114131517),
    motif=(114131644, 114131658), motif_label="NRF1 motif (+412)", scale_off=250,
    build="chr6  (bp, mm10 / GRCm38)", qcolor="#E8262A", ax_l=0.0726, ax_w=0.876,
    tracks=[("SRX12197087.bw", "NRF1 ChIP  ·  mESC-derived motor neuron (Auts2 KO)", (114131052, 114131765), 518),
            ("SRX12197081.bw", "NRF1 ChIP  ·  mESC-derived motor neuron (WT)", (114131082, 114131769), 465),
            ("SRX1280435.bw", "NRF1 ChIP  ·  ES cell (Domcke et al. 2015 Nature)", (114131580, 114131755), 330)])
HUMAN = dict(
    title="Human  SLC6A11   ·   NRF1 ChIP-seq (ENCODE)", gene="SLC6A11 →",
    chrom="chr3", win=(10815700, 10817300), tss=10816201, exon1=(10816201, 10816521),
    motif=(10816603, 10816617), motif_label="NRF1 motif (+409)", scale_off=170,
    build="chr3  (bp, hg38 / GRCh38)", qcolor=NAVY, ax_l=0.048, ax_w=0.878,
    tracks=[("hs_SRX2636389.bw", "NRF1 ChIP  ·  HepG2  (ENCODE)", (10816461, 10816952), 1000),
            ("hs_SRX150388.bw", "NRF1 ChIP  ·  H1-hESC  (ENCODE)", (10816633, 10816766), 223),
            ("hs_SRX186635.bw", "NRF1 ChIP  ·  SK-N-SH neuroblastoma  (ENCODE)", (10816620, 10816744), 109)])
CFG = {"G": MOUSE, "H": HUMAN}


def read_bw(fn, chrom, s, e):
    bw = pyBigWig.open(str(BW / fn)); v = np.array(bw.values(chrom, s, e), dtype=float); bw.close()
    return np.nan_to_num(v)


def draw(fig, P, cfg, letter):
    WS, WE = cfg["win"]; W = WE - WS; TSS = cfg["tss"]; E1S, E1E = cfg["exon1"]; MS, ME = cfg["motif"]
    MC = (MS + ME) / 2
    l, w = cfg["ax_l"], cfg["ax_w"]
    x = np.arange(WS, WE)
    P.text(0.046, 0.975, letter, ha="left", va="top", fontsize=7.5, fontweight="bold")
    P.text(0.58, 0.955, cfg["title"], ha="center", va="top", fontsize=5.6, fontweight="bold", color=NAVY)

    def style(ax):
        ax.set_xlim(WS, WE); ax.set_yticks([])
        ax.tick_params(labelbottom=False, length=0)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        for s in ("left", "bottom"):
            ax.spines[s].set_linewidth(0.6)
        ax.axvspan(MS - 6, ME + 6, color=MOTIF, alpha=0.16, lw=0, zorder=0)
        ax.axvline(TSS, color="#888", lw=0.5, ls=(0, (2, 1.5)), zorder=1)

    # gene model
    g = P.axes(l, 0.7275, w, 0.124); style(g); g.set_ylim(0, 1); g.spines["left"].set_visible(False)
    g.hlines(0.5, TSS, WE, color=NAVY, lw=0.7, zorder=2)
    g.add_patch(plt.Rectangle((E1S, 0.22), E1E - E1S, 0.56, color=NAVY, lw=0, zorder=3))
    g.text((E1S + E1E) / 2, 0.5, "exon 1", ha="center", va="center", fontsize=4.6, color="white", zorder=4)
    g.vlines(TSS, 0.5, 1.02, color=NAVY, lw=0.8, zorder=4)
    g.annotate("", xy=(TSS + W * 0.115, 1.02), xytext=(TSS, 1.02),
               arrowprops=dict(arrowstyle="-|>", color=NAVY, lw=0.8, mutation_scale=4), annotation_clip=False)
    g.text(TSS - W * 0.012, 1.0, "TSS", ha="right", va="center", fontsize=4.8, color=NAVY, clip_on=False)
    g.text(MC, 1.2, cfg["motif_label"], ha="center", va="bottom", fontsize=4.8, color=MOTIF, clip_on=False)
    g.text(WS + W * 0.012, 0.5, cfg["gene"], ha="left", va="center", fontsize=4.8, color=NAVY, clip_on=False)
    bx = WS + cfg["scale_off"]
    g.hlines(0.12, bx, bx + 500, color="#333", lw=0.7, clip_on=False)
    g.text(bx + 250, 0.27, "500 bp", ha="center", va="bottom", fontsize=4.8, color="#333")

    # ChIP tracks
    bottoms = [0.553, 0.362, 0.169]
    for (fn, lbl, (ps, pe), score), b in zip(cfg["tracks"], bottoms):
        s = read_bw(fn, cfg["chrom"], WS, WE); smax = float(s.max()) or 1.0
        ax = P.axes(l, b, w, 0.161); style(ax); ax.set_ylim(0, smax * 1.22)
        ax.fill_between(x, 0, s, color=SIG, lw=0, zorder=2, step="mid")
        ax.hlines(smax * 0.012, ps, pe, color=PEAK, lw=1.6, zorder=3)
        ax.text(WS + W * 0.006, smax * 1.2, lbl, ha="left", va="top", fontsize=4.6, color="#222")
        ax.text(WE - W * 0.004, smax * 1.2, f"q<<1e-10 (score {score})", ha="right", va="top",
                fontsize=4.6, color=cfg["qcolor"])
        ax.text(WS - W * 0.012, smax * 0.5, f"[0–{smax:.1f}]", ha="right", va="center", rotation=90,
                fontsize=4.4, color="#9A9A9A", fontweight="bold", clip_on=False)
    ticks = np.linspace(WS, WE, 5).astype(int)
    ax.tick_params(labelbottom=True, length=1.8, width=0.5, pad=1.5)
    ax.set_xticks(ticks); ax.set_xticklabels([f"{t:,}" for t in ticks], fontsize=5.0)
    labs = ax.get_xticklabels(); labs[0].set_ha("left"); labs[-1].set_ha("right")   # keep edge labels inside the slot
    ax.set_xlabel(cfg["build"], fontsize=5.0, labelpad=1.5)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for letter, box in SLOTS.items():
        wpx, hpx = box[2] - box[0], box[3] - box[1]
        fig = plt.figure(figsize=(wpx / SLOT_DPI, hpx / SLOT_DPI))
        draw(fig, Panel(fig), CFG[letter], letter)
        stem = OUT / f"FigS8{letter}_NRF1_ChIP_{'mouse' if letter == 'G' else 'human'}"
        for ext in ("pdf", "svg"):
            fig.savefig(f"{stem}.{ext}")
        fig.savefig(f"{stem}_600dpi.png", dpi=600)
        plt.close(fig)
        print("wrote", stem)


if __name__ == "__main__":
    main()
