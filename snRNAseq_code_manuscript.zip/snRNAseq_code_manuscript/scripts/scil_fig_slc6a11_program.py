#!/usr/bin/env python3
"""Slc6a11 perisynaptic program — sham vs SNI in PFC astrocytes.

a  Aggregate program score (per-cell z over the 16-gene program) collapses in SNI.
b  Per-gene split violins (sham vs SNI), ordered by effect size; Slc6a11 leads. The
   two NMDA/AMPA subunits that do not move (Grin2b, Gria3) are kept to show specificity.

Program = {Slc6a11, Slc6a1, Atp1b1/a2/b2, Gria1-4, Grin2b/3a, Kcnj10, Slc4a4, Slc25a18/a5, Car10}.
Exploratory (n=1 library/condition); per-cell Mann-Whitney, **** p<1e-4.
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy import sparse
from scipy.stats import mannwhitneyu
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False})
OUT = Path("results/scil_reanalysis/figures/pub")
SHAM, SNI, RED, DK = "#4C72A8", "#B64342", "#B64342", "#3a3a3a"
PROG = ["Slc6a11", "Slc6a1", "Atp1b1", "Atp1a2", "Atp1b2", "Gria1", "Gria2", "Gria3",
        "Gria4", "Grin2b", "Grin3a", "Kcnj10", "Slc4a4", "Slc25a18", "Slc25a5", "Car10"]


def expr(a, g):
    v = a[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def stars(p):
    return "****" if p < 1e-4 else "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 0.05 else "ns"


def main():
    a = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    cond = a.obs["condition"].astype(str).values
    genes = [g for g in PROG if g in a.var_names]

    # per-gene stats
    st = []
    for g in genes:
        v = expr(a, g)
        sh, sn = v[cond == "sham"], v[cond == "sni"]
        l2 = float(np.log2((np.expm1(sn.mean()) + 1e-9) / (np.expm1(sh.mean()) + 1e-9)))
        st.append({"gene": g, "log2FC": l2, "p": mannwhitneyu(sh, sn).pvalue})
    st = pd.DataFrame(st).sort_values("log2FC")  # most down first
    order = st.gene.tolist()

    # aggregate program score
    sc.tl.score_genes(a, genes, score_name="prog", ctrl_size=50, use_raw=False)
    sc_sh = a.obs.loc[cond == "sham", "prog"].values
    sc_sn = a.obs.loc[cond == "sni", "prog"].values
    p_score = mannwhitneyu(sc_sh, sc_sn).pvalue

    # long frame for per-gene violins
    rows = []
    for g in order:
        v = expr(a, g)
        for val, cc in zip(v, cond):
            rows.append({"gene": g, "expr": val, "cond": "SNI" if cc == "sni" else "Sham"})
    long = pd.DataFrame(rows)

    fig = plt.figure(figsize=(8.6, 6.4))
    gs = fig.add_gridspec(1, 2, width_ratios=[0.26, 1.0], wspace=0.22,
                          left=0.09, right=0.86, top=0.85, bottom=0.10)

    # ---------- a  program score
    axa = fig.add_subplot(gs[0, 0])
    sdf = pd.DataFrame({"score": np.r_[sc_sh, sc_sn],
                        "cond": ["Sham"] * len(sc_sh) + ["SNI"] * len(sc_sn)})
    sns.violinplot(data=sdf, x="cond", y="score", hue="cond", order=["Sham", "SNI"],
                   palette={"Sham": SHAM, "SNI": SNI}, cut=0, inner=None, linewidth=0,
                   legend=False, ax=axa)
    for coll in axa.collections:
        coll.set_alpha(0.55)
    for i, (gp, col) in enumerate([(sc_sh, SHAM), (sc_sn, SNI)]):
        q1, md, q3 = np.percentile(gp, [25, 50, 75])
        axa.plot([i, i], [q1, q3], color=col, lw=3.2, solid_capstyle="round", zorder=4)
        axa.scatter([i], [md], color="white", edgecolor=col, s=14, lw=0.8, zorder=5)
    ytop = max(sc_sh.max(), sc_sn.max())
    axa.plot([0, 0, 1, 1], [ytop + 0.04, ytop + 0.07, ytop + 0.07, ytop + 0.04], color=DK, lw=0.8)
    axa.text(0.5, ytop + 0.085, stars(p_score), ha="center", fontsize=8, fontweight="bold")
    axa.set_ylabel("Program score (per-cell)", fontsize=7)
    axa.set_xlabel(""); axa.set_title("Aggregate", fontsize=7.5, pad=5)
    axa.axhline(0, color="0.8", lw=0.6, ls="--", zorder=0)

    # ---------- b  per-gene split violins (horizontal)
    axb = fig.add_subplot(gs[0, 1])
    sns.violinplot(data=long, y="gene", x="expr", hue="cond", order=order,
                   hue_order=["Sham", "SNI"], split=True, cut=0, inner=None,
                   density_norm="width", gap=0.06, linewidth=0.4, bw_adjust=1.3,
                   palette={"Sham": SHAM, "SNI": SNI}, ax=axb)
    for coll in axb.collections:
        coll.set_alpha(0.85)
    # overlay per-half mean dots so the sham->SNI shift is directly visible
    for i, g in enumerate(order):
        v = expr(a, g)
        msh, msn = v[cond == "sham"].mean(), v[cond == "sni"].mean()
        axb.scatter([msh], [i - 0.17], color="white", edgecolor=SHAM, s=12, lw=0.8, zorder=6)
        axb.scatter([msn], [i + 0.17], color="white", edgecolor=SNI, s=12, lw=0.8, zorder=6)
    axb.set_xlabel("log-normalized expression", fontsize=7)
    axb.set_ylabel("")
    axb.set_xlim(left=-0.15)
    axb.legend(loc="lower right", frameon=False, fontsize=7, handlelength=1.0, title=None)

    # highlight Slc6a11 row + italic gene labels; right-margin log2FC + stars
    xr = axb.get_xlim()[1]
    for i, g in enumerate(order):
        r = st[st.gene == g].iloc[0]
        if g == "Slc6a11":
            axb.axhspan(i - 0.5, i + 0.5, color="#FBE9D0", zorder=0)
        axb.text(xr * 1.03, i, f"{r.log2FC:+.2f}", va="center", ha="left", fontsize=6.0,
                 color=RED if r.log2FC < -0.15 else "0.5",
                 fontweight="bold" if g == "Slc6a11" else "normal")
        axb.text(xr * 1.14, i, stars(r.p), va="center", ha="left", fontsize=6.0, color="0.4")
    axb.set_ylim(len(order) - 0.4, -0.95)
    axb.text(xr * 1.03, -0.75, "log2FC", fontsize=5.8, color="0.4", style="italic")
    for lab in axb.get_yticklabels():
        lab.set_style("italic"); lab.set_fontsize(7)
        if lab.get_text() == "Slc6a11":
            lab.set_color(RED); lab.set_fontweight("bold")
    axb.set_title("Perisynaptic ion/transmitter program coordinately declines in SNI",
                  fontsize=8, pad=6)

    axa.text(-0.55, 1.05, "a", transform=axa.transAxes, fontsize=11, fontweight="bold", va="bottom")
    axb.text(-0.02, 1.05, "b", transform=axb.transAxes, fontsize=11, fontweight="bold", va="bottom")
    fig.text(0.5, 0.015, "PFC astrocytes (783 sham / 1038 SNI cells); per-cell Mann-Whitney "
             "(**** p<1e-4); exploratory, n=1 library/condition.", ha="center", fontsize=5.2, color="0.5")

    stem = OUT / "fig_slc6a11_program"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
