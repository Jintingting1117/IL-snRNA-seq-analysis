#!/usr/bin/env python3
"""Best motif match of each candidate regulator in the Slc6a11 promoter-proximal region (Fig. 5E).

Same region and scoring as scil_slc6a11_regulators.py: -2,500 to +500 bp around the Slc6a11 TSS
(Ensembl REST, + strand), JASPAR 2022 CORE vertebrate non-redundant PFMs (pseudocount 0.5), both
strands. Position = motif centre relative to the TSS.
Inputs: tables/slc6a11_candidate_regulators.csv (JASPAR IDs). Needs internet access.
Output: tables/slc6a11_tf_site_positions.csv
"""
from __future__ import annotations
import io, re, time
from pathlib import Path
import numpy as np
import pandas as pd
import requests
from Bio import motifs
from Bio.Seq import Seq

TAB = Path("results/scil_reanalysis/tables")
ENS = "https://rest.ensembl.org"; HDRJ = {"Content-Type": "application/json"}
UP, DOWN = 2500, 500
CANDS = ["Nrf1", "Klf9", "Srebf1", "Srebf2", "Esrrg", "Tcf12"]
JASPAR_URLS = [
    "https://jaspar.genereg.net/download/data/2022/CORE/JASPAR2022_CORE_vertebrates_non-redundant_pfms_jaspar.txt",
    "https://jaspar.elixir.no/download/data/2022/CORE/JASPAR2022_CORE_vertebrates_non-redundant_pfms_jaspar.txt",
]


def get(url, headers=None, timeout=60, tries=8):
    """requests.get with retries (Ensembl REST / JASPAR occasionally return transient errors)."""
    for i in range(tries):
        try:
            r = requests.get(url, headers=headers, timeout=max(timeout, 60))
            if r.status_code == 200:
                return r
        except requests.RequestException:
            pass
        time.sleep(2 ** i)
    raise RuntimeError(f"request failed after {tries} attempts: {url}")


def main():
    ids = pd.read_csv(TAB / "slc6a11_candidate_regulators.csv").set_index("TF")["jaspar"]
    txt = None
    for u in JASPAR_URLS:
        try:
            txt = get(u, timeout=60).text; break
        except Exception:
            continue
    mats = {m.matrix_id: m for m in motifs.parse(io.StringIO(txt), "jaspar")}

    info = get(f"{ENS}/lookup/symbol/mus_musculus/Slc6a11", headers=HDRJ, timeout=30).json()
    tss = info["start"] if info["strand"] == 1 else info["end"]
    seq = get(f"{ENS}/sequence/region/mus_musculus/{info['seq_region_name']}:{tss-UP}..{tss+DOWN}:1",
                       headers={"Content-Type": "text/plain"}, timeout=30).text.strip().upper()
    s = Seq(re.sub("[^ACGT]", "A", seq)); rc = s.reverse_complement(); L = len(s)

    rows = []
    for tf in CANDS:
        m = mats[ids[tf]]; m.pseudocounts = 0.5; pssm = m.pssm; w = len(m)
        fwd, rev = np.asarray(pssm.calculate(s)), np.asarray(pssm.calculate(rc))
        if fwd.max() >= rev.max():
            i = int(fwd.argmax()); pos, strand, score = i + w // 2 - UP, "+", fwd.max()
        else:
            i = int(rev.argmax()); pos, strand, score = (L - w - i) + w // 2 - UP, "-", rev.max()
        rows.append({"TF": tf, "best_pos": pos, "best_score": round(float(score), 1),
                     "frac_max": round(float(score / pssm.max), 2), "strand": strand})
    out = pd.DataFrame(rows)
    out.to_csv(TAB / "slc6a11_tf_site_positions.csv", index=False)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
