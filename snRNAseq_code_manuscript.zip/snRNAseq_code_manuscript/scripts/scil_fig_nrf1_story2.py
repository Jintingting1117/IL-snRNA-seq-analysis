#!/usr/bin/env python3
"""NRF1 story figure v2: promoter scan -> evidence-based TF comparison -> NRF1 -> promoter structure
-> PGC-1a axis.

a  Promoter-motif scan landscape (candidates highlighted; no Hif1a).
b  Parallel TF comparison MATRIX (evidence: motif, own expression, activity, target co-regulation,
   Slc6a11-module membership) -> Nrf1 & Klf9 pass; SREBP/Esrrg are passengers.
c  Classic Slc6a11 promoter structure with the single high-confidence NRF1 site (+412) and the
   NRF1 motif logo.
d  PGC-1a -> NRF1 -> {Na/K-ATPase, OXPHOS, Slc6a11} axis with druggable entry points.
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse
import logomaker
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False})
TAB = Path("results/scil_reanalysis/tables"); OUT = Path("results/scil_reanalysis/figures/pub")
TEAL, RED, BLUE, GREEN, DK, GREY = "#2E8B8B", "#B64342", "#0F4D92", "#2e8b57", "#3a3a3a", "#9AA0A6"
# panel b: Purples truncated at #9E9AC8 (drop the four darkest ColorBrewer steps)
PURPLES = LinearSegmentedColormap.from_list("purples_lite", plt.cm.Purples(np.linspace(0, 0.5, 256)))


def lfc(a, g):
    if g not in a.var_names:
        return np.nan
    v = a[:, g].X; v = np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()
    c = a.obs["condition"].astype(str).values
    return float(np.log2((np.expm1(v[c == "sni"].mean()) + 1e-9) / (np.expm1(v[c == "sham"].mean()) + 1e-9)))


def downcol(v):
    return plt.cm.Blues(0.32 + 0.5 * min(1.0, abs(v) / 2.0))


# ---------- a
def panel_scan(ax, d):
    d = d.copy(); d["y"] = -d["log2FC_sni"]
    cand = (d.frac_of_max >= 0.7) & (d.motif_z_vs_bg >= 1.5) & (d.log2FC_sni < -0.15)
    ax.scatter(d.loc[~cand, "motif_z_vs_bg"], d.loc[~cand, "y"], s=7 + d.loc[~cand, "frac_of_max"] * 24,
               c=GREY, linewidths=0, alpha=0.5, zorder=1)
    ax.scatter(d.loc[cand, "motif_z_vs_bg"], d.loc[cand, "y"], s=10 + d.loc[cand, "frac_of_max"] * 42,
               c=TEAL, edgecolor="white", linewidth=0.4, zorder=3)
    nf = d[d.TF == "Nrf1"]
    ax.scatter(nf.motif_z_vs_bg, nf.y, s=150, marker="*", c=RED, edgecolor="white", linewidth=0.6, zorder=5)
    for _, r in d[d.TF.isin(["Nrf1", "Klf9", "Srebf1", "Srebf2", "Esrrg", "Tcf12"])].iterrows():
        ax.annotate(r.TF, (r.motif_z_vs_bg, r.y), xytext=(4, 0), textcoords="offset points", fontsize=6,
                    style="italic", color=RED if r.TF == "Nrf1" else "#178f8f",
                    fontweight="bold" if r.TF == "Nrf1" else "normal", va="center")
    ax.axvline(1.5, color="0.65", ls="--", lw=0.7); ax.axhline(0.15, color="0.65", ls="--", lw=0.7)
    ax.set_xlabel("promoter-motif specificity (z vs background)")
    ax.set_ylabel("Slc6a11-concordant\n(−log2FC; ↑ = TF down in SNI)")
    ax.set_title("Unbiased Slc6a11 promoter scan", fontsize=8, pad=3)


# ---------- b
def panel_compare(ax, comp):
    cols = [("motif_z", "Motif\nspecificity"),
            ("motif_frac", "Direct site\n(motif str.)"),
            ("own_log2FC", "Own\nexpr ↓"),
            ("activity_delta", "Activity\nΔ ↓"),
            ("target_mean_log2FC", "Targets\nco-↓"),
            ("n_program_targets", "Targets =\nSlc6a11\nprogram")]
    order = ["Nrf1"] + comp.sort_values("target_mean_log2FC").TF.tolist()
    comp = comp.set_index("TF").loc[list(dict.fromkeys(order))].reset_index()
    sup = np.zeros((len(comp), len(cols))); raw = np.zeros_like(sup)
    for j, (key, _) in enumerate(cols):
        v = (-comp[key] if key in ("own_log2FC", "activity_delta", "target_mean_log2FC") else comp[key]).to_numpy()
        raw[:, j] = comp[key].to_numpy()
        sup[:, j] = (v - v.min()) / (np.ptp(v) + 1e-9)
    ax.imshow(sup, aspect="auto", cmap=PURPLES, vmin=0, vmax=1)
    ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[1] for c in cols], fontsize=5.2)
    ax.set_yticks(range(len(comp))); ax.set_yticklabels(comp["TF"], fontsize=6.6, style="italic")
    for i, tf in enumerate(comp["TF"]):
        if tf == "Nrf1":
            ax.get_yticklabels()[i].set_color(RED); ax.get_yticklabels()[i].set_fontweight("bold")
    for i in range(len(comp)):
        for j, (key, _) in enumerate(cols):
            val = raw[i, j]
            txt = f"{int(val)}" if key == "n_program_targets" else f"{val:+.2f}"
            r_, g_, b_, _ = PURPLES(sup[i, j])  # white text only where the cell is actually dark
            ax.text(j, i, txt, ha="center", va="center", fontsize=5.2,
                    color="white" if 0.299 * r_ + 0.587 * g_ + 0.114 * b_ < 0.55 else "0.25")
    for i, r in comp.iterrows():
        if r["n_program_targets"] >= 1:
            v, c = "✓ direct regulator", GREEN
        elif r["target_mean_log2FC"] < -0.1:
            v, c = "co-marker\n(no program targets)", "#B8860B"
        else:
            v, c = "✗ passenger", RED
        ax.text(len(cols) - 0.4, i, v, fontsize=5.2, va="center", color=c,
                fontweight="bold" if c == GREEN else "normal")
    ax.set_xlim(-0.5, len(cols) + 1.3)
    ax.set_title("Parallel evidence → NRF1 is the candidate direct regulator", fontsize=7.6, pad=3)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)


# ---------- c  classic promoter structure + motif logo + other-TF best sites
def panel_promoter(ax, sites, pfm, pos):
    ax.set_xlim(-2150, 560); ax.set_ylim(0, 1); ax.set_yticks([])
    for sp in ["left", "right", "top"]:
        ax.spines[sp].set_visible(False)
    yd = 0.46
    EXON1 = 279
    # proximal promoter (upstream)
    ax.add_patch(Rectangle((-2100, yd - 0.016), 2100, 0.032, color="#E7ECF2", zorder=0))
    ax.plot([-2100, 0], [yd, yd], color=DK, lw=1.3, zorder=1)
    ax.text(-1050, yd + 0.085, "proximal promoter (−2.5 kb)", ha="center", fontsize=5.4,
            color="0.5", style="italic")
    # exon 1 (start codon at +36)
    ax.add_patch(FancyBboxPatch((0, yd - 0.05), EXON1, 0.10, boxstyle="round,pad=0,rounding_size=6",
                                facecolor="#C9D6E5", edgecolor=BLUE, lw=0.8, zorder=2))
    ax.text(EXON1 / 2, yd, "exon 1", ha="center", va="center", fontsize=5.0, color=BLUE)
    # intron 1
    ax.plot([EXON1, 540], [yd, yd], color="0.55", lw=1.3, zorder=1)
    ax.text(440, yd + 0.075, "intron 1", ha="center", fontsize=5.4, color="0.45", style="italic")
    # TSS bent arrow
    ax.annotate("", xy=(200, yd + 0.20), xytext=(0, yd + 0.20), arrowprops=dict(arrowstyle="-|>", color=DK, lw=1.3))
    ax.plot([0, 0], [yd, yd + 0.20], color=DK, lw=1.3)
    ax.text(0, yd + 0.25, "TSS (+1)", ha="center", fontsize=6, fontweight="bold")
    # other candidate-TF best sites = grey lollipops BELOW the track (no motif logo)
    others = pos[pos.TF != "Nrf1"].copy()
    grp = (others.groupby("best_pos")
                  .agg(TF=("TF", lambda s: "/".join(sorted(set(s))).replace("Srebf1/Srebf2", "Srebf1/2")),
                       frac=("frac_max", "max")).reset_index())
    stagger = {327: 0.0, 462: 0.075}  # near-TSS pair: drop Tcf12 a notch to avoid label clash
    for _, r in grp.iterrows():
        dy = stagger.get(int(r.best_pos), 0.0)
        ax.plot([r.best_pos, r.best_pos], [yd - 0.05, yd - 0.135 - dy], color=GREY, lw=0.8, zorder=2)
        ax.add_patch(Rectangle((r.best_pos - 11, yd - 0.05), 22, 0.10, facecolor="#D7DBE0",
                               edgecolor=GREY, lw=0.5, zorder=2))
        ax.scatter([r.best_pos], [yd - 0.135 - dy], s=10, color=GREY, zorder=3)
        ax.text(r.best_pos, yd - 0.175 - dy, r.TF, ha="center", va="top", fontsize=5.2,
                color="0.4", style="italic")
    ax.text(-2100, yd - 0.30, "grey = best site of other candidate TFs (motif not shown)",
            ha="left", fontsize=5.0, color="0.55", style="italic")
    # NRF1 site at +412 (intron 1) — the validated one, ABOVE the track + logo
    best = sites.sort_values("score", ascending=False).iloc[0]
    ax.add_patch(Rectangle((best.dist_tss - 14, yd - 0.05), 28, 0.10, color=RED, zorder=4))
    ax.plot([best.dist_tss, best.dist_tss], [yd + 0.05, yd + 0.165], color=RED, lw=0.9, zorder=4)
    ax.text(best.dist_tss, yd + 0.255, "NRF1 site", ha="center", fontsize=6.2, color=RED, fontweight="bold")
    ax.text(best.dist_tss, yd + 0.185, f"{best.dist_tss:+d} bp · intron 1 · score {best.score:.1f}\n5′-{best.seq}-3′",
            ha="center", fontsize=5.0, color=RED, va="center")
    ax.set_xticks([-2000, -1500, -1000, -500, 0, 500])
    ax.set_xticklabels(["−2000", "−1500", "−1000", "−500", "0", "+500"], fontsize=5.6)
    ax.set_xlabel("distance from TSS (bp)", fontsize=6.5)
    ax.set_title("Slc6a11 promoter: many TF motifs, but only NRF1 has convergent evidence (intron-1 site)",
                 fontsize=7.6, pad=3)
    # motif logo inset (top-left, over the empty upstream area)
    lax = ax.inset_axes([0.015, 0.60, 0.22, 0.34])
    ic = logomaker.transform_matrix(pfm, from_type="counts", to_type="information")
    logomaker.Logo(ic, ax=lax, color_scheme="classic", show_spines=False)
    lax.set_xticks([]); lax.set_yticks([])
    lax.set_title("NRF1 motif (MA0506.2)", fontsize=5.2, pad=1)


# ---------- d  axis
def box(ax, x, y, w, h, t, fc, fontcolor="white", fs=6.0):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.01,rounding_size=0.02",
                                facecolor=fc, edgecolor="none", zorder=3))
    ax.text(x, y, t, ha="center", va="center", fontsize=fs, color=fontcolor, zorder=4)


def arr(ax, x0, y0, x1, y1, color="0.35", lw=1.1):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=9, color=color, lw=lw, zorder=2))


def panel_axis(ax, vals):
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    box(ax, 0.11, 0.5, 0.20, 0.30, f"PGC-1α\n(Ppargc1a)\n{vals['Ppargc1a']:+.2f}", downcol(vals["Ppargc1a"]), fs=5.8)
    arr(ax, 0.21, 0.5, 0.30, 0.5, color=DK)
    box(ax, 0.40, 0.5, 0.17, 0.26, f"NRF1\n{vals['Nrf1']:+.2f}", RED, fs=7.0)
    tg = [("Na⁺/K⁺-ATPase (Atp1b1)", vals["Atp1b1"], 0.80), ("Mitochondria / OXPHOS", vals["OXPHOS"], 0.5),
          ("Slc6a11 (GAT-3)", vals["Slc6a11"], 0.20)]
    for lab, v, y in tg:
        arr(ax, 0.49, 0.5, 0.60, y, color=DK)
        box(ax, 0.745, y, 0.30, 0.165, f"{lab}  {v:+.2f}", downcol(v), fs=5.4)
    box(ax, 0.945, 0.5, 0.10, 0.5, "↓ GABA\nclearance", "#5B6B7A", fs=5.4)
    for _, _, y in tg:
        arr(ax, 0.895, y, 0.905, 0.5 + (y - 0.5) * 0.2, color="0.6", lw=0.8)
    ax.text(0.11, 0.84, "↑ rescue: AMPK/SIRT1 activators\n(AICAR · metformin · NMN/NR)", ha="center",
            fontsize=4.8, color=GREEN, style="italic")
    ax.text(0.40, 0.78, "siRNA/OE · ChIP-qPCR · reporter", ha="center", fontsize=4.8, color=RED, style="italic")
    ax.set_title("NRF1 axis & validation entry points", fontsize=8, pad=2)


def main():
    a = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    d = pd.read_csv(TAB / "slc6a11_candidate_regulators.csv")
    comp = pd.read_csv(TAB / "slc6a11_tf_comparison.csv")
    sites = pd.read_csv(TAB / "slc6a11_nrf1_sites.csv")
    pos = pd.read_csv(TAB / "slc6a11_tf_site_positions.csv")
    pfm = pd.read_csv(TAB / "nrf1_pfm.csv")
    OXP = np.nanmean([lfc(a, g) for g in ["Ndufa4", "Ndufs1", "Sdha", "Cox5a", "Atp5f1b", "Cox4i1", "Ndufv1", "Cs", "Idh3a", "Aco2"]])
    vals = {"Ppargc1a": lfc(a, "Ppargc1a"), "Nrf1": lfc(a, "Nrf1"), "Atp1b1": lfc(a, "Atp1b1"),
            "OXPHOS": OXP, "Slc6a11": lfc(a, "Slc6a11")}

    fig = plt.figure(figsize=(9.0, 7.6))
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 0.78, 0.6], width_ratios=[1.0, 1.12],
                          hspace=0.6, wspace=0.4, left=0.08, right=0.97, top=0.94, bottom=0.06)
    ax_a = fig.add_subplot(gs[0, 0]); panel_scan(ax_a, d)
    ax_b = fig.add_subplot(gs[0, 1]); panel_compare(ax_b, comp)
    ax_c = fig.add_subplot(gs[1, :]); panel_promoter(ax_c, sites, pfm, pos)
    ax_d = fig.add_subplot(gs[2, :]); panel_axis(ax_d, vals)
    for ax, lab in [(ax_a, "a"), (ax_b, "b"), (ax_c, "c"), (ax_d, "d")]:
        ax.text(-0.02, 1.06, lab, transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
    fig.text(0.5, 0.012, "PFC astrocytes; log2FC = SNI vs sham (exploratory, n=1/condition). "
             "Motif scan: JASPAR vertebrate PWMs vs background astrocyte-gene promoters.",
             ha="center", fontsize=5.0, color="0.5")
    stem = OUT / "fig_nrf1_story2"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=170, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
