#!/usr/bin/env python3
"""Figure 3 (assembled): PFC astrocytes reorganize neurotransmitter transport after SNI.

a  UMAP of astrocyte substates.
b  De-novo marker dotplot (names the states) + transporter block (transporters concentrate
   in the synapse-associated state).
c  Substate composition sham vs SNI (synapse-associated depleted, reactive gained).
d  Inhibitory- vs excitatory-transmitter transporter DE (Slc6a9/Slc6a11/Slc6a1 down; Slc1a2 up).
e  Pathways down-regulated in SNI astrocytes (Enrichr).

The leave-out specificity control is a separate supplement (scil_fig_astrocyte_control.py).
Backend: Python/matplotlib (nature-figure). Editable SVG/PDF + PNG + TIFF. n=1/condition (exploratory).
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import pandas as pd
import anndata as ad
import warnings
from scipy import sparse

warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False, "legend.frameon": False})

P = {"blue": "#0F4D92", "blue2": "#3775BA", "red": "#B64342", "teal": "#2E8B8B",
     "gold": "#C8961E", "grey_l": "#D9D9D9", "grey_m": "#767676", "grey_d": "#4D4D4D"}
OBJ = Path("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
TAB = Path("results/scil_reanalysis/tables")
OUT = Path("results/scil_reanalysis/figures/pub")

SUB_COLORS = {"Homeostatic": P["blue2"], "Synapse-associated": P["teal"],
              "Reactive": P["red"], "Low-quality": P["grey_l"]}
MAIN = ["Homeostatic", "Synapse-associated", "Reactive"]
MARKER_GROUPS = {
    "Homeostatic": ["Slco1c1", "Pde10a", "Grm3"],
    "Synapse-assoc.": ["Slc4a4", "Gria1", "Car10"],
    "Reactive": ["Gfap", "Apoe", "Sparcl1"],
    "Transporters": ["Slc6a11", "Slc6a1", "Slc6a9"],
}
GROUP_COLOR = {"Homeostatic": P["blue2"], "Synapse-assoc.": P["teal"],
               "Reactive": P["red"], "Transporters": P["gold"]}


def gv(a, g):
    v = a[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def panel_umap(ax, a):
    xy = a.obsm["X_umap"]
    states = [s for s in a.obs["substate"].cat.categories if s in SUB_COLORS]
    # 1,821 nuclei -> keep points as TRUE VECTORS (rasterized=False) with solid colours.
    # Rasterizing + per-point alpha made the old panel embed a low-res raster + soft-mask
    # that Adobe Illustrator flattened to a grey block.
    for s in [x for x in states if x == "Low-quality"] + [x for x in states if x != "Low-quality"]:
        m = (a.obs["substate"] == s).to_numpy()
        ax.scatter(xy[m, 0], xy[m, 1], s=5, c=SUB_COLORS[s], linewidths=0, rasterized=False,
                   label=s)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    ax.set_title("Astrocyte substates", fontsize=8, pad=3)
    ax.legend(loc="upper left", fontsize=5.2, markerscale=2.0, handletextpad=0.2, labelspacing=0.22)


def panel_markers(ax, a):
    genes, grp_of = [], []
    for grp, gs in MARKER_GROUPS.items():
        for g in gs:
            if g in a.var_names:
                genes.append(g); grp_of.append(grp)
    sub = a.obs["substate"].astype(str).values
    nS, nG = len(MAIN), len(genes)
    pct = np.zeros((nS, nG)); meanx = np.zeros((nS, nG))
    for i, s in enumerate(MAIN):
        m = (sub == s)
        for j, g in enumerate(genes):
            v = gv(a, g)[m]; pct[i, j] = 100 * (v > 0).mean(); meanx[i, j] = v.mean()
    scaled = (meanx - meanx.min(0)) / (np.ptp(meanx, axis=0) + 1e-9)
    cmap = plt.cm.Reds
    for i in range(nS):
        for j in range(nG):
            ax.scatter(j, i, s=8 + pct[i, j] * 1.7, c=[cmap(0.15 + 0.85 * scaled[i, j])],
                       edgecolor="0.35", linewidth=0.3, zorder=3)
    ax.set_xticks(range(nG)); ax.set_xticklabels(genes, rotation=45, ha="right", fontsize=6.0, style="italic")
    ax.set_yticks(range(nS)); ax.set_yticklabels(MAIN, fontsize=6.6)
    ax.set_ylim(-0.6, nS - 0.4); ax.set_xlim(-0.6, nG - 0.4); ax.invert_yaxis()
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)
    j = 0
    for grp, gs in MARKER_GROUPS.items():
        pres = [g for g in gs if g in genes]
        if not pres:
            continue
        c0, c1 = j, j + len(pres) - 1
        ax.plot([c0 - 0.3, c1 + 0.3], [-0.72, -0.72], color=GROUP_COLOR[grp], lw=2.0, clip_on=False)
        ax.text((c0 + c1) / 2, -0.95, grp, ha="center", va="bottom", fontsize=5.8,
                color=GROUP_COLOR[grp], fontweight="bold")
        j += len(pres)
    # compact size legend (right inset) + colorbar, clearly separated
    ax.text(nG + 0.4, -0.35, "% cells", fontsize=5.2, ha="left", clip_on=False)
    for k, p in enumerate([25, 60, 100]):
        ax.scatter(nG + 0.5, 0.25 + k * 0.7, s=8 + p * 1.7, c="0.6", edgecolor="0.35",
                   linewidth=0.3, clip_on=False)
        ax.text(nG + 1.0, 0.25 + k * 0.7, f"{p}%", va="center", fontsize=5.2, clip_on=False)
    cax = ax.inset_axes([1.22, 0.12, 0.02, 0.55])
    mpl.colorbar.ColorbarBase(cax, cmap=cmap, norm=mpl.colors.Normalize(0, 1))
    cax.set_title("scaled\nmean", fontsize=5.0, pad=2); cax.tick_params(labelsize=4.8)


def panel_proportions(ax, a):
    comp = pd.crosstab(a.obs["substate"], a.obs["condition"])
    pct = comp.div(comp.sum(0), axis=1) * 100
    states = [s for s in MAIN if s in pct.index]
    x = np.arange(len(states)); w = 0.38
    sham = [pct.loc[s, "sham"] for s in states]; sni = [pct.loc[s, "sni"] for s in states]
    ax.bar(x - w / 2, sham, w, color=P["blue"], label="sham", edgecolor="white", linewidth=0.5)
    ax.bar(x + w / 2, sni, w, color=P["red"], label="SNI", edgecolor="white", linewidth=0.5)
    for xi, (s0, s1) in enumerate(zip(sham, sni)):
        ax.text(xi - w / 2, s0 + 0.8, f"{s0:.0f}", ha="center", fontsize=5.6, color=P["blue"])
        ax.text(xi + w / 2, s1 + 0.8, f"{s1:.0f}", ha="center", fontsize=5.6, color=P["red"])
    ax.set_xticks(x); ax.set_xticklabels(["Homeo-\nstatic", "Synapse-\nassoc.", "Reactive"], fontsize=6.2)
    ax.set_ylabel("% of astrocytes (within condition)")
    ax.set_title("Substate composition", fontsize=8, pad=3); ax.legend(loc="upper right", fontsize=6.2)


def panel_transport(ax, df):
    order = ["Slc6a9", "Slc6a11", "Slc6a1", "Slc1a3", "Slc6a13", "Slc1a2"]
    lab = {"Slc6a9": "Slc6a9 (GlyT1)", "Slc6a11": "Slc6a11 (GAT-3)", "Slc6a1": "Slc6a1 (GAT-1)",
           "Slc1a3": "Slc1a3 (GLAST)", "Slc6a13": "Slc6a13 (GAT-2)", "Slc1a2": "Slc1a2 (GLT-1)"}
    d = df.set_index("gene").reindex([g for g in order if g in df.gene.values])
    for i, (g, r) in enumerate(d.iterrows()):
        sig = r["pvals_adj"] < 0.05
        c = P["red"] if r["log2FC"] < 0 else P["blue"]
        ax.plot([0, r["log2FC"]], [i, i], color=c, lw=1.4, zorder=1)
        ax.scatter(r["log2FC"], i, s=26 if sig else 14, color=c, zorder=3, edgecolor="white", linewidth=0.5)
        if sig:
            ax.text(r["log2FC"] + (-0.13 if r["log2FC"] < 0 else 0.13), i, "*", ha="center", va="center",
                    fontsize=9, color=c)
    ax.axvline(0, color=P["grey_d"], lw=0.8)
    ax.set_yticks(range(len(d))); ax.set_yticklabels([lab[g] for g in d.index], fontsize=6.0)
    ax.set_xlabel("log2FC astrocytes (SNI vs sham)")
    ax.set_title("Neurotransmitter transporters", fontsize=8, pad=3)
    ax.text(0.97, 0.06, "inhibitory ↓\nglutamate ↑", transform=ax.transAxes, fontsize=5.6,
            style="italic", color=P["grey_d"], ha="right", va="bottom")


def panel_enrichment(ax, enr):
    enr = enr.copy()
    enr["nlp"] = -np.log10(enr["Adjusted P-value"].clip(lower=1e-300))
    enr["short"] = (enr["Term"].str.replace(r"\s*\(GO:\d+\)", "", regex=True)
                    .str.replace(" signaling pathway", " signaling", regex=False)
                    .str.replace(" pathway", "", regex=False)
                    .str.replace("Fc gamma R-mediated phagocytosis", "FcR phagocytosis", regex=False)
                    .str.slice(0, 22))
    enr = enr.sort_values("Adjusted P-value").head(6).iloc[::-1]
    y = np.arange(len(enr))
    ax.barh(y, enr["nlp"], color=P["blue2"], height=0.66, edgecolor="white", linewidth=0.5)
    ax.set_yticks(y); ax.set_yticklabels(enr["short"], fontsize=5.8)
    ax.set_xlabel("-log10 adjusted P"); ax.set_title("Down-regulated in SNI", fontsize=8, pad=3)
    ax.axvline(-np.log10(0.05), color=P["grey_m"], ls="--", lw=0.8)


def main():
    a = ad.read_h5ad(OBJ)
    tdf = pd.read_csv(TAB / "astro_transport_axis_de.csv")
    enr = pd.read_csv(TAB / "astro_enrichr_down_in_sni.csv")

    fig = plt.figure(figsize=(7.5, 6.2))
    gs = fig.add_gridspec(2, 6, height_ratios=[1.0, 0.92], hspace=0.62, wspace=1.5,
                          left=0.08, right=0.9, top=0.9, bottom=0.1)
    ax_a = fig.add_subplot(gs[0, 0:2]); panel_umap(ax_a, a)
    ax_b = fig.add_subplot(gs[0, 2:6]); panel_markers(ax_b, a)
    ax_c = fig.add_subplot(gs[1, 0:2]); panel_proportions(ax_c, a)
    ax_d = fig.add_subplot(gs[1, 2:4]); panel_transport(ax_d, tdf)
    ax_e = fig.add_subplot(gs[1, 4:6]); panel_enrichment(ax_e, enr)

    for ax, lab, dx in [(ax_a, "a", -0.20), (ax_b, "b", -0.07), (ax_c, "c", -0.30),
                        (ax_d, "d", -0.34), (ax_e, "e", -0.40)]:
        ax.text(dx, 1.06, lab, transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom")
    fig.text(0.5, 0.015, "PFC astrocytes, snRNA-seq; 1,821 nuclei. n = 1 library per condition "
             "(exploratory; DE Wilcoxon, mt/ribo/ambient excluded). * adj P < 0.05.",
             ha="center", fontsize=5.2, color=P["grey_m"])

    stem = OUT / "fig3_astrocyte"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", dpi=600, bbox_inches="tight")  # dpi drives any residual raster (colourbar)
    fig.savefig(f"{stem}.png", dpi=400, bbox_inches="tight")
    fig.savefig(f"{stem}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem, "(.svg/.pdf/.png/.tiff)")


if __name__ == "__main__":
    main()
