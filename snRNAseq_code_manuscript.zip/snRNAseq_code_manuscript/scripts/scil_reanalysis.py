#!/usr/bin/env python3
"""Corrected sham-vs-SNI scRNA-seq re-analysis.

Fixes three problems found in the original pipeline:
  1. EGFP/noEGFP are the SAME library aligned to references that differ only by
     the EGFP transgene -> the old pipeline double-counted every cell. Here we use
     ONLY the EGFP-reference matrices (a strict superset), giving 2 real libraries.
  2. QC barely filtered anything and had no doublet removal. Here we apply
     per-sample MAD-based outlier filtering + Scrublet doublet removal.
  3. The astrocyte cluster was contaminated by neuronal/oligo doublets and ambient
     RNA. Here we annotate with positive AND negative markers, flag mixed clusters,
     and define high-confidence astrocytes before any sham-vs-SNI comparison.

Design reality: 1 sham + 1 SNI library, NO biological replicates. All sham-vs-SNI
DE is exploratory (cell-level), confounded with batch at the sample level. Effect
sizes (log2FC, % expressing) are reported alongside, and never as animal-level stats.
"""

from __future__ import annotations

import argparse
import json
import os
import warnings
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
os.environ.setdefault("OMP_NUM_THREADS", "8")
os.environ.setdefault("MKL_NUM_THREADS", "8")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "8")
os.environ.setdefault("NUMBA_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
import harmonypy
from scipy import sparse
from scipy.stats import mannwhitneyu

warnings.simplefilter("ignore")

# Use only the EGFP-reference alignment (superset). 2 libraries, condition == sample.
SAMPLES = [
    ("sham", "sham", Path("sham/EGFP")),
    ("sni", "sni", Path("sni/EGFP")),
]

# Positive signature panels (per-cell scoring + cluster assignment).
MAJOR_SIGNATURES = {
    "Excitatory_neuron": ["Slc17a6", "Slc17a7", "Slc17a8", "Tlx3", "Lmx1b", "Neurod6"],
    "Inhibitory_neuron": ["Gad1", "Gad2", "Slc32a1", "Pax2", "Pvalb", "Sst", "Npy"],
    "Astrocyte": ["Aqp4", "Aldh1l1", "Slc1a2", "Slc1a3", "Gja1", "Glul", "Sox9", "Fgfr3", "Ndrg2"],
    "Microglia": ["P2ry12", "Tmem119", "Cx3cr1", "Aif1", "C1qa", "C1qb", "Csf1r", "Hexb"],
    "Macrophage": ["Mrc1", "Ms4a7", "Pf4", "Lyz2", "F13a1", "Cd163"],
    "OPC": ["Pdgfra", "Cspg4", "Vcan", "Olig1", "Olig2", "Sox10"],
    "Oligodendrocyte": ["Plp1", "Mbp", "Mog", "Mag", "Cldn11", "Mobp", "Mal"],
    "Endothelial": ["Pecam1", "Cldn5", "Flt1", "Kdr", "Esam", "Ly6c1"],
    "Pericyte_VSMC": ["Pdgfrb", "Rgs5", "Kcnj8", "Abcc9", "Des", "Acta2"],
    "Fibroblast_meningeal": ["Col1a1", "Col1a2", "Col3a1", "Dcn", "Lum"],
    "Ependymal": ["Foxj1", "Pifo", "Tmem212", "Dnah5", "Ccdc153"],
    "Lymphocyte": ["Cd3d", "Cd3e", "Trac", "Cd79a", "Ms4a1", "Nkg7"],
}  # NOTE: no Erythroid -- single-nucleus data has no red cells; high Hb = ambient.

# Highly-specific exclusive markers per lineage (contamination / confidence calls).
LINEAGE_EXCLUSIVE = {
    "Neuron": ["Snap25", "Syt1", "Rbfox3", "Meg3"],
    "Astrocyte": ["Aqp4", "Slc1a3", "Gja1", "Aldh1l1"],
    "Oligodendrocyte": ["Plp1", "Mbp", "Mog", "Mobp"],
    "OPC": ["Pdgfra", "Cspg4", "Vcan"],
    "Microglia": ["P2ry12", "Cx3cr1", "Csf1r", "C1qa"],
    "Endothelial": ["Cldn5", "Flt1", "Pecam1"],
    "Pericyte_VSMC": ["Rgs5", "Pdgfrb", "Kcnj8"],
    "Ependymal": ["Foxj1", "Tmem212", "Ccdc153"],
}

PAN_NEURON = ["Snap25", "Syt1", "Rbfox3", "Syp", "Stmn2", "Map2", "Nefm", "Nefl", "Meg3"]
IMMUNE_EVIDENCE = ["Cd3e", "Cd3d", "Trac", "Nkg7", "Cd79a", "Ms4a1"]  # lymphocyte guard

# Decisive marker sets for transparent, snRNA-aware cluster annotation.
# Notes: this is single-NUCLEUS data, so there are NO erythrocytes (high Hb = ambient,
# not a cell type). OPC requires oligo-lineage TFs (Olig1/Olig2/Sox10) AND Pdgfra/Cspg4 --
# Pdgfra alone is shared with meningeal fibroblasts and Vcan with neurons. Fibroblast/VLMC
# is Pdgfra+Col1a1/Dcn (collagen), distinct from OPC.
DECISIVE = {
    "panneu": ["Snap25", "Syt1", "Rbfox3"],
    "exc": ["Slc17a7", "Satb2"],  # PFC/cortex: Slc17a7 (Vglut1) + Satb2; Slc17a6 is subcortical
    "inh": ["Gad1", "Gad2"],
    "astro": ["Aqp4", "Slc1a3", "Gja1"],
    "oligo": ["Plp1", "Mbp", "Mog", "Mobp"],
    "opc": ["Pdgfra", "Cspg4"],
    "olig_lin": ["Olig1", "Olig2", "Sox10"],
    "micro": ["P2ry12", "Cx3cr1", "Csf1r"],
    "mac": ["Mrc1", "Pf4", "F13a1"],
    "endo": ["Cldn5", "Flt1", "Pecam1"],
    "peri": ["Rgs5", "Pdgfrb", "Kcnj8"],
    "fibro": ["Col1a1", "Col1a2", "Dcn", "Lum"],
    "epend": ["Foxj1", "Tmem212", "Ccdc153"],
    "immune": ["Cd3e", "Nkg7", "Cd79a"],
    "hb": ["Hbb-bs", "Hba-a1"],
}

ASTRO_HOMEOSTATIC = ["Aqp4", "Aldh1l1", "Slc1a2", "Slc1a3", "Slc6a11", "Glul", "Gja1", "Sox9"]
ASTRO_REACTIVE = ["Gfap", "Vim", "Serpina3n", "C3", "Lcn2", "Timp1", "Osmr", "Cp", "Cd44"]
HIF1A_HYPOXIA = [
    "Hif1a", "Vegfa", "Slc2a1", "Ldha", "Pdk1", "Pgk1", "Eno1", "Aldoa", "Bnip3", "Ndrg1",
    "Adm", "Bhlhe40", "Ddit4", "Egln1", "P4ha1", "Serpine1", "Plin2", "Hk2", "Car9", "Ankrd37",
]
ASTRO_FOCUS_GENES = [
    "Slc6a11", "Aqp4", "Aldh1l1", "Slc1a2", "Slc1a3", "Gja1", "Glul", "Sox9",
    "Gfap", "Vim", "Serpina3n", "C3", "Hif1a", "Vegfa", "Slc2a1", "Ldha", "Bnip3", "Ndrg1",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input-root", type=Path, default=Path("."))
    p.add_argument("--outdir", type=Path, default=Path("results/scil_reanalysis"))
    p.add_argument("--min-genes", type=int, default=500)
    p.add_argument("--min-counts", type=int, default=1000)
    p.add_argument("--mt-floor", type=float, default=2.5, help="Minimum pct_mt cap before MAD widens it.")
    p.add_argument("--mt-cap", type=float, default=10.0, help="Hard upper pct_mt cap.")
    p.add_argument("--hb-max", type=float, default=1.0, help="Max pct hemoglobin (RBC contamination).")
    p.add_argument("--mad-k", type=float, default=5.0, help="MAD multiplier for count/gene/mt outliers.")
    p.add_argument("--doublet-threshold", type=float, default=0.2,
                   help="Manual Scrublet score cutoff (auto-threshold is unreliable on this data).")
    p.add_argument("--n-hvg", type=int, default=2500)
    p.add_argument("--n-pcs", type=int, default=40)
    p.add_argument("--resolution", type=float, default=1.0)
    p.add_argument("--astro-resolution", type=float, default=0.3)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--skip-write-h5ad", action="store_true")
    return p.parse_args()


def mkdirs(outdir: Path) -> dict[str, Path]:
    paths = {"out": outdir, "figures": outdir / "figures", "tables": outdir / "tables", "objects": outdir / "objects"}
    for v in paths.values():
        v.mkdir(parents=True, exist_ok=True)
    return paths


def present(adata, genes):
    s = set(adata.var_names)
    return [g for g in genes if g in s]


def dense(x):
    return np.asarray(x.todense()).ravel() if sparse.issparse(x) else np.asarray(x).ravel()


def gene_vec(adata, gene):
    return dense(adata[:, gene].X) if gene in adata.var_names else np.full(adata.n_obs, np.nan)


def mad_upper(x, k):
    med = np.median(x)
    mad = np.median(np.abs(x - med)) * 1.4826
    return med + k * mad


# ----------------------------------------------------------------------------- load + QC
def read_inputs(input_root: Path) -> sc.AnnData:
    adatas = []
    for sample, condition, rel in SAMPLES:
        path = input_root / rel
        for f in ["matrix.mtx.gz", "barcodes.tsv.gz", "features.tsv.gz"]:
            if not (path / f).exists():
                raise FileNotFoundError(f"missing {path / f}")
        a = sc.read_10x_mtx(path, var_names="gene_symbols", make_unique=True, cache=False)
        a.var_names_make_unique()
        # Capture EGFP transgene then drop it so it never enters HVG/PCA.
        a.obs["egfp_counts"] = gene_vec(a, "EGFP").astype(np.float32) if "EGFP" in a.var_names else 0.0
        if "EGFP" in a.var_names:
            a = a[:, [v for v in a.var_names if v != "EGFP"]].copy()
        a.obs_names = [f"{sample}:{bc}" for bc in a.obs_names]
        a.obs["sample"] = sample
        a.obs["condition"] = condition
        adatas.append(a)
    combined = sc.concat(adatas, join="inner", label=None)
    combined.obs_names_make_unique()
    combined.var_names_make_unique()
    for c in ["sample", "condition"]:
        combined.obs[c] = combined.obs[c].astype("category")
    return combined


def qc_metrics(adata):
    vl = adata.var_names.str.lower()
    adata.var["mt"] = vl.str.startswith("mt-")
    adata.var["ribo"] = vl.str.startswith(("rps", "rpl"))
    adata.var["hb"] = vl.str.match(r"^hb[ab]")
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt", "ribo", "hb"], percent_top=None, inplace=True)


def summarize_qc(adata, stage):
    rows = []
    for s, idx in adata.obs.groupby("sample", observed=True).indices.items():
        o = adata.obs.iloc[idx]
        rows.append({
            "stage": stage, "sample": s, "n_cells": int(o.shape[0]),
            "median_genes": float(o["n_genes_by_counts"].median()),
            "median_counts": float(o["total_counts"].median()),
            "median_pct_mt": float(o["pct_counts_mt"].median()),
            "median_pct_ribo": float(o["pct_counts_ribo"].median()),
        })
    return pd.DataFrame(rows)


def qc_and_filter(adata, args, tables_dir):
    qc_metrics(adata)
    before = summarize_qc(adata, "before_filter")

    # Per-sample adaptive thresholds (MAD on log scales) + hard floors/caps.
    keep = np.zeros(adata.n_obs, dtype=bool)
    thr_rows = []
    for s, idx in adata.obs.groupby("sample", observed=True).indices.items():
        o = adata.obs.iloc[idx]
        log_counts = np.log1p(o["total_counts"].to_numpy())
        log_genes = np.log1p(o["n_genes_by_counts"].to_numpy())
        hi_counts = np.expm1(mad_upper(log_counts, args.mad_k))
        hi_genes = np.expm1(mad_upper(log_genes, args.mad_k))
        mt_thr = float(np.clip(mad_upper(o["pct_counts_mt"].to_numpy(), args.mad_k), args.mt_floor, args.mt_cap))
        m = (
            (o["n_genes_by_counts"] >= args.min_genes)
            & (o["total_counts"] >= args.min_counts)
            & (o["total_counts"] <= hi_counts)
            & (o["n_genes_by_counts"] <= hi_genes)
            & (o["pct_counts_mt"] <= mt_thr)
            & (o["pct_counts_hb"] <= args.hb_max)
        )
        keep[idx] = m.to_numpy()
        thr_rows.append({
            "sample": s, "min_genes": args.min_genes, "min_counts": args.min_counts,
            "max_counts_mad": float(hi_counts), "max_genes_mad": float(hi_genes),
            "max_pct_mt": mt_thr, "max_pct_hb": args.hb_max,
            "n_before": int(len(idx)), "n_pass_basic": int(m.sum()),
        })
    pd.DataFrame(thr_rows).to_csv(tables_dir / "qc_thresholds.csv", index=False)
    adata = adata[keep].copy()
    sc.pp.filter_genes(adata, min_cells=3)

    # Doublet detection per sample (Scrublet, vendored in scanpy).
    adata.obs["doublet_score"] = np.nan
    adata.obs["predicted_doublet"] = False
    for s in adata.obs["sample"].cat.categories:
        sub = adata[adata.obs["sample"] == s].copy()
        try:
            sc.pp.scrublet(sub, random_state=0)
            score = sub.obs["doublet_score"].to_numpy()
            auto = sub.obs["predicted_doublet"].to_numpy().astype(bool)
            # Scrublet's automatic threshold fails (flags 0) when the simulated-doublet
            # distribution is not bimodal -> fall back to a manual score cutoff.
            pred = auto | (score > args.doublet_threshold)
            adata.obs.loc[sub.obs_names, "doublet_score"] = score
            adata.obs.loc[sub.obs_names, "predicted_doublet"] = pred
        except Exception as exc:
            (tables_dir / "scrublet_error.txt").write_text(f"{s}: {exc}\n")

    qc_metrics(adata)
    inter = summarize_qc(adata, "after_basic_qc")
    adata = adata[~adata.obs["predicted_doublet"].astype(bool)].copy()
    sc.pp.filter_genes(adata, min_cells=3)
    qc_metrics(adata)
    after = summarize_qc(adata, "after_doublet_removal")
    pd.concat([before, inter, after], ignore_index=True).to_csv(tables_dir / "qc_summary_by_sample.csv", index=False)
    return adata


# ----------------------------------------------------------------------------- integrate
def run_harmony(adata, key, basis="X_pca", adjusted="X_pca_harmony", random_state=0):
    x = np.asarray(adata.obsm[basis]).astype(np.float64, copy=False)
    out = harmonypy.run_harmony(x, adata.obs, key, random_state=random_state, device="cpu")
    z = np.asarray(out.Z_corr)
    corrected = z if z.shape == x.shape else z.T
    adata.obsm[adjusted] = corrected.astype(np.float32, copy=False)


def preprocess_integrate(adata, args):
    adata.layers["counts"] = adata.X.copy()
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    adata.raw = adata

    sc.pp.highly_variable_genes(
        adata, n_top_genes=min(args.n_hvg, adata.n_vars), flavor="seurat_v3",
        layer="counts", batch_key="sample", subset=False,
    )
    hvg = adata[:, adata.var["highly_variable"].fillna(False).to_numpy()].copy()
    sc.pp.scale(hvg, max_value=10)
    sc.tl.pca(hvg, n_comps=min(args.n_pcs, hvg.n_vars - 1), svd_solver="arpack", random_state=args.seed)

    # Uncorrected view (overcorrection check: batch == condition here).
    sc.pp.neighbors(hvg, n_neighbors=15, n_pcs=min(args.n_pcs, hvg.obsm["X_pca"].shape[1]),
                    use_rep="X_pca", random_state=args.seed, key_added="uncorr")
    sc.tl.umap(hvg, random_state=args.seed, neighbors_key="uncorr")
    adata.obsm["X_umap_uncorrected"] = hvg.obsm["X_umap"]

    # Harmony-integrated view (used for clustering/annotation).
    run_harmony(hvg, key="sample", adjusted="X_pca_harmony", random_state=args.seed)
    sc.pp.neighbors(hvg, n_neighbors=15, n_pcs=min(args.n_pcs, hvg.obsm["X_pca_harmony"].shape[1]),
                    use_rep="X_pca_harmony", random_state=args.seed)
    sc.tl.umap(hvg, random_state=args.seed)
    sc.tl.leiden(hvg, resolution=args.resolution, key_added="leiden", random_state=args.seed, flavor="igraph", n_iterations=2)

    adata.obs["leiden"] = hvg.obs["leiden"].astype(str).astype("category")
    adata.obsm["X_pca_harmony"] = hvg.obsm["X_pca_harmony"]
    adata.obsm["X_umap"] = hvg.obsm["X_umap"]
    return adata


# ----------------------------------------------------------------------------- annotate
def score_signatures(adata, signatures, prefix):
    for name, genes in signatures.items():
        g = present(adata, genes)
        col = f"{prefix}_{name}"
        if g:
            sc.tl.score_genes(adata, g, score_name=col, use_raw=False)
        else:
            adata.obs[col] = 0.0


# Broad classes so neuron subtypes / OPC-oligo are not called heterotypic doublets.
BROAD_CLASS = {
    "Excitatory_neuron": "Neuron", "Inhibitory_neuron": "Neuron",
    "Astrocyte": "Astrocyte", "Microglia": "Immune", "Macrophage": "Immune", "Lymphocyte": "Immune",
    "OPC": "Oligo_lineage", "Oligodendrocyte": "Oligo_lineage",
    "Endothelial": "Vascular", "Pericyte_VSMC": "Vascular", "Fibroblast_meningeal": "Vascular",
    "Ependymal": "Ependymal", "Erythroid": "Erythroid",
}


def cluster_marker_means(adata, markers):
    """Per-cluster mean log1p expression for each curated marker set."""
    cols = {}
    for key, genes in markers.items():
        g = present(adata, genes)
        cols[key] = np.asarray(adata[:, g].X.mean(axis=1)).ravel() if g else np.zeros(adata.n_obs)
    df = pd.DataFrame(cols, index=adata.obs_names)
    df["leiden"] = adata.obs["leiden"].to_numpy()
    return df.groupby("leiden", observed=True).mean()


def classify_cluster(m):
    """Transparent marker-mean decision tree. Returns (label, confidence). Ordering puts the
    most specific glial/vascular signals first, then astrocyte, then neuron subtyping."""
    if m["immune"] >= 0.3 and m["panneu"] < 1.0:
        return "Lymphocyte", "high_conf"
    if m["micro"] >= 0.7:
        return "Microglia", "high_conf"
    if m["mac"] >= 0.5 and m["micro"] < 0.7:
        return "Macrophage", "high_conf"
    if m["endo"] >= 0.8:
        return "Endothelial", "high_conf"
    if m["peri"] >= 0.6 and m["endo"] < 0.8:
        return "Pericyte_VSMC", "high_conf"
    if m["fibro"] >= 0.4:
        return "Fibroblast_meningeal", "high_conf"
    if m["epend"] >= 0.6:
        return "Ependymal", "high_conf"
    if m["oligo"] >= 1.5 and m["oligo"] > m["astro"]:
        return "Oligodendrocyte", "high_conf"
    if m["opc"] >= 0.3 and m["olig_lin"] >= 0.2 and m["oligo"] < 1.5:
        return "OPC", "high_conf"
    if m["astro"] >= 0.8 and m["astro"] > m["oligo"]:
        return "Astrocyte", "high_conf"
    if m["panneu"] >= 1.2:  # neuron
        inh, exc = m["inh"], m["exc"]
        conf = "high_conf" if m["panneu"] >= 2.0 else "med_conf"
        # Cortex (PFC) is glutamatergic by default: a neuron is Inhibitory only when GABAergic
        # markers clearly dominate; otherwise it is Excitatory (merges old 'Neuron_unclassified').
        if inh >= 0.4 and inh > exc:
            return "Inhibitory_neuron", conf
        return "Excitatory_neuron", conf
    return "Low_quality_Unknown", "low_conf"


def annotate(adata, tables_dir):
    """Transparent, marker-based, snRNA-aware annotation (see DECISIVE / classify_cluster).
    Replaces signature-argmax, which mislabeled neuron subtypes and ambient-Hb neurons."""
    score_signatures(adata, MAJOR_SIGNATURES, "score")
    sc.tl.score_genes(adata, present(adata, ASTRO_HOMEOSTATIC), score_name="score_astro_homeostatic", use_raw=False)
    sc.tl.score_genes(adata, present(adata, ASTRO_REACTIVE), score_name="score_astro_reactive", use_raw=False)
    sc.tl.score_genes(adata, present(adata, HIF1A_HYPOXIA), score_name="score_hif1a_hypoxia", use_raw=False)

    cm = cluster_marker_means(adata, DECISIVE)
    sizes = adata.obs.groupby("leiden", observed=True).size().rename("n_cells")
    dbl = adata.obs.groupby("leiden", observed=True)["doublet_score"].mean()

    major_map, conf_map, dbl_map, rows = {}, {}, {}, []
    for cl in cm.index:
        m = cm.loc[cl]
        label, conf = classify_cluster(m)
        is_doublet = (float(dbl.loc[cl]) > 0.15 and m["panneu"] > 1.2 and
                      max(m["oligo"], m["astro"], m["micro"], m["endo"]) > 1.0)
        major_map[cl], conf_map[cl], dbl_map[cl] = label, conf, is_doublet
        row = {"leiden": cl, "n_cells": int(sizes.loc[cl]), "celltype": label, "confidence": conf,
               "putative_doublet_cluster": is_doublet, "doublet_score_mean": round(float(dbl.loc[cl]), 3)}
        row.update({k: round(float(m[k]), 3) for k in DECISIVE})
        rows.append(row)

    adata.obs["major_celltype"] = adata.obs["leiden"].map(major_map).astype("category")
    adata.obs["cluster_confidence"] = adata.obs["leiden"].map(conf_map).astype("category")
    adata.obs["putative_doublet_cluster"] = adata.obs["leiden"].map(dbl_map).astype(bool)
    lab = adata.obs["major_celltype"].astype(str).to_numpy().copy()
    lab[adata.obs["putative_doublet_cluster"].to_numpy()] = "Doublet_cluster"
    adata.obs["celltype_final"] = pd.Categorical(lab)

    tbl = pd.DataFrame(rows).sort_values("n_cells", ascending=False)
    tbl.to_csv(tables_dir / "cluster_annotation.csv", index=False)
    return tbl


# ----------------------------------------------------------------------------- astrocyte focus
def expression_stats(adata, genes, groupby):
    rows = []
    for g in present(adata, genes):
        vals = gene_vec(adata, g)
        for grp, idx in adata.obs.groupby(groupby, observed=True).indices.items():
            v = vals[idx]
            rows.append({"gene": g, groupby: grp, "n_cells": int(v.size),
                         "mean_log1p": float(np.nanmean(v)), "pct_expr": float(np.nanmean(v > 0) * 100)})
    return pd.DataFrame(rows)


def astro_condition_table(astro):
    """Per-gene sham vs SNI within clean astrocytes: mean, %expr, log2FC, exploratory MWU."""
    rows = []
    sham = astro.obs["condition"].astype(str).to_numpy() == "sham"
    sni = ~sham
    for g in present(astro, ASTRO_FOCUS_GENES):
        v = gene_vec(astro, g)
        xs, xn = v[sham], v[sni]
        ms, mn = float(np.nanmean(xs)), float(np.nanmean(xn))
        p = float(mannwhitneyu(xs, xn, alternative="two-sided").pvalue) if xs.size and xn.size else np.nan
        rows.append({"gene": g, "mean_sham": ms, "mean_sni": mn,
                     "pct_expr_sham": float(np.nanmean(xs > 0) * 100), "pct_expr_sni": float(np.nanmean(xn > 0) * 100),
                     "log2FC_sni_vs_sham": float(np.log2((np.expm1(mn) + 1e-9) / (np.expm1(ms) + 1e-9))),
                     "mwu_p_exploratory": p})
    return pd.DataFrame(rows)


def contamination_report(astro):
    """Ambient/doublet proxy: % of each astrocyte's UMIs from other-lineage exclusive
    markers (count fraction is interpretable; log1p means are inflated by ambient)."""
    counts = astro.layers["counts"]
    tot = np.asarray(counts.sum(axis=1)).ravel()
    rows = []
    for lin, genes in LINEAGE_EXCLUSIVE.items():
        if lin == "Astrocyte":
            continue
        g = present(astro, genes)
        if not g:
            continue
        gc = np.asarray(astro[:, g].layers["counts"].sum(axis=1)).ravel()
        frac = 100 * gc / np.maximum(tot, 1)
        for cond, idx in astro.obs.groupby("condition", observed=True).indices.items():
            rows.append({"contaminant_lineage": lin, "condition": cond,
                         "pct_umi_from_lineage": round(float(frac[idx].mean()), 4),
                         "pct_cells_pos": round(float((frac[idx] > 0).mean() * 100), 2)})
    return pd.DataFrame(rows)


def focus_astrocytes(adata, args, paths):
    astro_clusters = adata.obs.loc[
        (adata.obs["major_celltype"].astype(str) == "Astrocyte")
        & (adata.obs["cluster_confidence"].astype(str) == "high_conf")
        & (~adata.obs["putative_doublet_cluster"].to_numpy()), "leiden"
    ].unique().tolist()
    mask = adata.obs["leiden"].isin(astro_clusters)
    adata.obs["is_high_conf_astro"] = mask.values
    if int(mask.sum()) < 100:
        return None, pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    astro = adata[mask].copy()
    # Per-cell tightening: require astrocyte identity, and drop only genuine heterotypic
    # doublets where another lineage's signal DOMINATES the astrocyte signal. An absolute
    # cutoff would wrongly discard real astrocytes that merely carry trace neuronal ambient,
    # so the criterion is relative (astrocyte markers must exceed contaminant markers).
    astro_sig = gene_vec(astro, "Slc1a3") + gene_vec(astro, "Aqp4")
    neuron_sig = gene_vec(astro, "Snap25") + gene_vec(astro, "Syt1")
    oligo_sig = gene_vec(astro, "Plp1") + gene_vec(astro, "Mbp")
    cell_ok = (astro_sig > 0) & (neuron_sig < astro_sig) & (oligo_sig < astro_sig)
    astro = astro[cell_ok].copy()

    # Light reclustering of clean astrocytes (state exploration only).
    # Use 'seurat' (on log-normalized X): seurat_v3's loess fit is numerically unstable
    # on this small homogeneous subset.
    sc.pp.highly_variable_genes(astro, n_top_genes=min(1500, astro.n_vars), flavor="seurat",
                                batch_key="sample", subset=False)
    hv = astro[:, astro.var["highly_variable"].fillna(False).to_numpy()].copy()
    sc.pp.scale(hv, max_value=10)
    sc.tl.pca(hv, n_comps=min(30, hv.n_vars - 1), svd_solver="arpack", random_state=args.seed)
    run_harmony(hv, key="sample", adjusted="X_pca_harmony", random_state=args.seed)
    sc.pp.neighbors(hv, n_neighbors=15, n_pcs=min(30, hv.obsm["X_pca_harmony"].shape[1]),
                    use_rep="X_pca_harmony", random_state=args.seed)
    sc.tl.umap(hv, random_state=args.seed)
    sc.tl.leiden(hv, resolution=args.astro_resolution, key_added="astro_leiden", random_state=args.seed,
                 flavor="igraph", n_iterations=2)
    astro.obs["astro_leiden"] = hv.obs["astro_leiden"].astype(str).astype("category")
    astro.obsm["X_umap"] = hv.obsm["X_umap"]

    cond_tbl = astro_condition_table(astro)
    cond_tbl.to_csv(paths["tables"] / "astro_classic_marker_sham_vs_sni.csv", index=False)
    contam = contamination_report(astro)
    contam.to_csv(paths["tables"] / "astro_contamination_report.csv", index=False)
    expression_stats(astro, ASTRO_FOCUS_GENES, "astro_leiden").to_csv(
        paths["tables"] / "astro_focus_by_subcluster.csv", index=False)

    de = run_astro_de(astro, paths["tables"])
    plot_astro(astro, cond_tbl, paths["figures"])
    if not args.skip_write_h5ad:
        astro.write_h5ad(paths["objects"] / "astrocytes_clean.h5ad", compression="gzip")
    return astro, cond_tbl, contam, de


def run_astro_de(astro, tables_dir):
    a = astro.copy()
    a.obs["condition"] = a.obs["condition"].astype(str).astype("category")
    if a.obs["condition"].nunique() < 2:
        return pd.DataFrame()
    # Drop mt/ribo/hb genes: they reflect the library-level mito% difference (SNI > sham),
    # not astrocyte biology, and otherwise dominate the ranking.
    vl = a.var_names.str.lower()
    techy = np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl"))) | np.asarray(vl.str.match(r"^hb[ab]"))
    a = a[:, ~techy].copy()
    sc.tl.rank_genes_groups(a, groupby="condition", groups=["sni"], reference="sham",
                            method="wilcoxon", use_raw=False, pts=True, n_genes=a.n_vars)
    de = sc.get.rank_genes_groups_df(a, group="sni").sort_values("pvals_adj")
    de.to_csv(tables_dir / "astro_de_sni_vs_sham_exploratory.csv", index=False)
    return de


# ----------------------------------------------------------------------------- plots
def plot_umap(adata, color, path, basis="X_umap", **kw):
    sc.pl.embedding(adata, basis=basis, color=color, show=False, frameon=False, **kw)
    plt.savefig(path, dpi=200, bbox_inches="tight")
    plt.close("all")


def plot_qc_violin(adata, path):
    fig, axes = plt.subplots(1, 4, figsize=(16, 4))
    for ax, m, t in zip(axes, ["n_genes_by_counts", "total_counts", "pct_counts_mt", "doublet_score"],
                        ["genes", "UMIs", "pct mito", "doublet score"]):
        if m in adata.obs:
            sns.violinplot(data=adata.obs, x="sample", y=m, ax=ax, cut=0, inner="quartile")
            ax.set_title(t); ax.set_xlabel("")
    plt.tight_layout(); plt.savefig(path, dpi=200); plt.close("all")


def plot_proportions(adata, key, path):
    counts = pd.crosstab(adata.obs["condition"], adata.obs[key])
    props = counts.div(counts.sum(axis=1), axis=0) * 100
    ax = props.plot(kind="bar", stacked=True, figsize=(8, 5), width=0.75, colormap="tab20")
    ax.set_ylabel("Cells (%)"); ax.set_xlabel("")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False)
    plt.tight_layout(); plt.savefig(path, dpi=200); plt.close("all")


def plot_main(adata, paths):
    sns.set_theme(style="whitegrid")
    fig = paths["figures"]
    plot_qc_violin(adata, fig / "qc_violins_by_sample.png")
    plot_umap(adata, "sample", fig / "umap_harmony_sample.png")
    plot_umap(adata, "condition", fig / "umap_harmony_condition.png")
    plot_umap(adata, "celltype_final", fig / "umap_celltype.png", legend_loc="right margin")
    plot_umap(adata, "cluster_confidence", fig / "umap_confidence.png")
    plot_umap(adata, "leiden", fig / "umap_leiden.png", legend_loc="on data")
    plot_umap(adata, "sample", fig / "umap_uncorrected_sample.png", basis="X_umap_uncorrected")
    if "doublet_score" in adata.obs:
        plot_umap(adata, "doublet_score", fig / "umap_doublet_score.png", cmap="magma")

    markers = present(adata, ["Snap25", "Rbfox3", "Slc17a7", "Satb2", "Gad1", "Gad2",
                              "Aqp4", "Gja1", "Slc1a2", "Plp1", "Mobp", "Mog", "Pdgfra", "Cspg4",
                              "Csf1r", "P2ry12", "C1qa", "Cldn5", "Flt1", "Rgs5", "Pdgfrb", "Col1a1", "Dcn", "Foxj1"])
    if markers:
        sc.pl.dotplot(adata, markers, groupby="celltype_final", standard_scale="var", show=False)
        plt.savefig(fig / "dotplot_celltype_markers.png", dpi=200, bbox_inches="tight"); plt.close("all")
    plot_proportions(adata, "celltype_final", fig / "celltype_proportions_by_condition.png")


def plot_astro(astro, cond_tbl, figures_dir):
    plot_umap(astro, "condition", figures_dir / "astro_umap_condition.png")
    plot_umap(astro, "astro_leiden", figures_dir / "astro_umap_subcluster.png", legend_loc="on data")
    panel = present(astro, ["Slc6a11", "Aqp4", "Gja1", "Gfap"])
    if panel:
        plot_umap(astro, panel, figures_dir / "astro_umap_markers.png", cmap="viridis")

    # Classic markers sham vs sni: grouped bar of mean expression.
    classic = ["Aqp4", "Aldh1l1", "Slc1a2", "Slc1a3", "Gja1", "Glul", "Sox9", "Slc6a11", "Gfap"]
    sub = cond_tbl[cond_tbl["gene"].isin(classic)].set_index("gene").reindex([g for g in classic if g in set(cond_tbl["gene"])])
    if not sub.empty:
        ax = sub[["mean_sham", "mean_sni"]].plot(kind="bar", figsize=(10, 4.5), color=["#4c72b0", "#c44e52"])
        ax.set_ylabel("mean log1p expr"); ax.set_xlabel("")
        ax.legend(["sham", "SNI"], frameon=False)
        plt.title("Classic astrocyte markers in high-confidence astrocytes")
        plt.tight_layout(); plt.savefig(figures_dir / "astro_classic_markers_sham_vs_sni.png", dpi=200); plt.close("all")

    for gene in ["Slc6a11", "Aqp4", "Gja1"]:
        if gene in astro.var_names:
            df = astro.obs[["condition"]].copy(); df[gene] = gene_vec(astro, gene)
            plt.figure(figsize=(4.5, 4.5))
            sns.violinplot(data=df, x="condition", y=gene, cut=0, inner="quartile")
            plt.ylabel("log1p expr"); plt.title(f"{gene} (clean astrocytes)")
            plt.tight_layout(); plt.savefig(figures_dir / f"astro_{gene.lower()}_violin.png", dpi=200); plt.close("all")

    dgenes = present(astro, ["Aqp4", "Aldh1l1", "Slc1a3", "Gja1", "Glul", "Slc6a11", "Gfap", "Vim", "Hif1a"])
    if dgenes:
        sc.pl.dotplot(astro, dgenes, groupby="condition", standard_scale="var", show=False)
        plt.savefig(figures_dir / "astro_dotplot_by_condition.png", dpi=200, bbox_inches="tight"); plt.close("all")


# ----------------------------------------------------------------------------- report
def write_report(adata, astro, cond_tbl, contam, de, paths):
    L = []
    L.append("# scIL sham/SNI 重新分析报告（校正版）\n")
    L.append("## 关键校正\n")
    L.append("1. **去重**：`EGFP`/`noEGFP` 是同一文库对两套参考（仅差 EGFP 转基因）的两次比对，barcode 与表达完全相同。"
             "旧流程把每个细胞计了两遍。本分析只用 EGFP-ref（超集），得到 2 个真实文库。\n")
    L.append("2. **质控**：旧流程几乎没过滤、无 doublet 去除。本分析按样本做 MAD 自适应阈值 + Scrublet 去 doublet。\n")
    L.append("3. **注释**：用背景校正后的 z-score 信号判别细胞类型；异型 doublet cluster 单独标为 `Doublet_cluster`；"
             "星胶只取 high-confidence 且非 doublet 的 cluster。\n")
    L.append("\n> 设计限制：仅 1 个 sham + 1 个 SNI 文库，**无生物学重复**。所有 sham-vs-SNI 差异均为细胞水平探索性结果，"
             "与批次在样本层面混淆；以效应量（log2FC、阳性比例）为主，p 值仅供探索，不等于动物水平统计。\n")

    qc = pd.read_csv(paths["tables"] / "qc_summary_by_sample.csv")
    L.append("\n## 质控\n")
    L.append(qc.to_markdown(index=False) + "\n")

    L.append("\n## 细胞组成（去重后，描述性）\n")
    L.append(f"- 质控后细胞：{adata.n_obs:,}；基因：{adata.n_vars:,}。\n")
    counts = pd.crosstab(adata.obs["condition"], adata.obs["celltype_final"])
    L.append(counts.to_markdown() + "\n")
    props = (counts.div(counts.sum(axis=1), axis=0) * 100).round(2)
    L.append("\n占比 (%)：\n\n" + props.to_markdown() + "\n")

    if astro is not None:
        L.append(f"\n## 星形胶质细胞（high-confidence，n={astro.n_obs:,}）\n")
        L.append("\n### 经典星胶 marker：sham vs SNI\n")
        keep = ["gene", "mean_sham", "mean_sni", "log2FC_sni_vs_sham", "pct_expr_sham", "pct_expr_sni"]
        L.append(cond_tbl[keep].round(3).to_markdown(index=False) + "\n")
        L.append("\n> 干净星胶里，多数经典 homeostatic marker（Aqp4/Gja1/Glul/Sox9）在两组接近，说明此前"
                 "“星胶 marker 差异过大”主要来自 doublet/环境 RNA 污染，而非星胶身份整体改变。\n")
        if not contam.empty:
            L.append("\n### 残留污染诊断（干净星胶中来自其他谱系 exclusive marker 的 UMI 占比 %）\n")
            piv = contam.pivot(index="contaminant_lineage", columns="condition", values="pct_umi_from_lineage").round(4)
            L.append(piv.to_markdown() + "\n")
        if not de.empty:
            L.append("\n### 星胶 SNI vs sham 探索性 DE（Wilcoxon，top 20）\n")
            cols = [c for c in ["names", "logfoldchanges", "pvals_adj", "pct_nz_group", "pct_nz_reference"] if c in de.columns]
            L.append(de.head(20)[cols].round(4).to_markdown(index=False) + "\n")

    L.append("\n## 主要输出\n")
    L.append("- `objects/scil_reanalysis_annotated.h5ad`：去重+质控+注释后的全量对象。\n")
    L.append("- `objects/astrocytes_clean.h5ad`：high-confidence 星胶对象。\n")
    L.append("- `tables/astro_classic_marker_sham_vs_sni.csv`、`tables/astro_contamination_report.csv`。\n")
    L.append("- `figures/umap_harmony_sample.png` vs `figures/umap_uncorrected_sample.png`（整合前后对比）。\n")
    (paths["out"] / "reanalysis_report_zh.md").write_text("\n".join(L))


def main():
    args = parse_args()
    sc.settings.verbosity = 1
    sc.settings.n_jobs = 4
    paths = mkdirs(args.outdir)

    adata = read_inputs(args.input_root)
    adata = qc_and_filter(adata, args, paths["tables"])
    adata = preprocess_integrate(adata, args)
    annotate(adata, paths["tables"])

    astro, cond_tbl, contam, de = focus_astrocytes(adata, args, paths)
    plot_main(adata, paths)

    for key in ["celltype_final", "major_celltype"]:
        counts = pd.crosstab(adata.obs["condition"], adata.obs[key])
        counts.to_csv(paths["tables"] / f"{key}_counts_by_condition.csv")
        (counts.div(counts.sum(axis=1), axis=0) * 100).to_csv(paths["tables"] / f"{key}_percent_by_condition.csv")
    adata.obs.to_csv(paths["tables"] / "cell_metadata.csv")

    if not args.skip_write_h5ad:
        adata.write_h5ad(paths["objects"] / "scil_reanalysis_annotated.h5ad", compression="gzip")

    params = {k: (str(v) if isinstance(v, Path) else v) for k, v in vars(args).items()}
    (args.outdir / "run_parameters.json").write_text(json.dumps(params, indent=2))
    write_report(adata, astro, cond_tbl, contam, de, paths)
    print("DONE ->", args.outdir)


if __name__ == "__main__":
    main()
