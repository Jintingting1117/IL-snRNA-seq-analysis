#!/usr/bin/env python3
"""Statistical support for the PGC-1a -> NRF1 mitochondrial-biogenesis axis in SNI astrocytes.

Brings the cartoon axis to data: three independent statistical readouts, all pointing down in SNI.
 1. Regulon activity of the PGC-1a-coactivated respiratory TFs (decoupler ULM; already computed).
 2. Per-gene SNI-vs-sham ranking -> GSEA prerank against the axis gene sets (NES + FDR) — the
    competitive, genome-background-aware statistic (robust to the n=1 pseudoreplication problem).
 3. Per-cell signature scores (sc.tl.score_genes) sham vs SNI (Mann-Whitney) — effect-size view.

Nuclear-encoded OXPHOS only (mt- genes are confounded by the SNI mito% batch difference and are
reported separately as a flagged sanity row, not used for the claim).
"""
from __future__ import annotations
import os, re
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import numpy as np
import pandas as pd
import scanpy as sc
import decoupler as dc
import gseapy as gp
from scipy import sparse
from scipy.stats import mannwhitneyu
import warnings
warnings.simplefilter("ignore")

TAB = Path("results/scil_reanalysis/tables")
AD = "results/scil_reanalysis/objects/astrocytes_deepdive.h5ad"

# --- axis gene sets ---------------------------------------------------------
PGC1A_TFS = ["Ppargc1a", "Ppargc1b", "Nrf1", "Gabpa", "Gabpb1", "Esrra", "Esrrg",
             "Yy1", "Tfam", "Tfb1m", "Tfb2m", "Polrmt", "Nfe2l1"]
NAK_ATPASE = ["Atp1a1", "Atp1a2", "Atp1a3", "Atp1b1", "Atp1b2", "Atp1b3",
              "Fxyd1", "Fxyd6", "Fxyd7"]
MTDNA_MAINT = ["Tfam", "Tfb1m", "Tfb2m", "Polrmt", "Polg", "Polg2", "Ssbp1",
               "Mterf1a", "Mterf2", "Mterf3", "Mterf4"]
SLC6A11_PROG = ["Slc6a11", "Slc6a1", "Atp1b1", "Atp1a2", "Atp1b2", "Gria1", "Gria2",
                "Gria3", "Gria4", "Grin2b", "Grin3a", "Kcnj10", "Slc4a4", "Slc25a18",
                "Slc25a5", "Car10"]
RESP_TFS = ["Nrf1", "Gabpa", "Esrra", "Esrrg", "Yy1"]  # PGC-1a-coactivated respiratory TFs w/ regulons


def vec(ad, g):
    v = ad[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def main():
    ad = sc.read_h5ad(AD)
    cond = ad.obs["condition"].astype(str).values
    vn = set(ad.var_names)

    # nuclear-encoded OXPHOS subunits, by complex (regex, exclude mt-)
    def match(pat):
        return [g for g in ad.var_names if re.match(pat, g) and not g.startswith("mt-")]
    oxphos_nuc = {
        "CI (Ndufx)": match(r"Nduf"),
        "CII (Sdhx)": [g for g in ["Sdha", "Sdhb", "Sdhc", "Sdhd"] if g in vn],
        "CIII (Uqcr/Cyc1)": match(r"Uqcr") + [g for g in ["Cyc1"] if g in vn],
        "CIV (Coxx)": match(r"Cox(4|5|6|7|8|10|11|15|17)"),
        "CV (Atp5x)": match(r"Atp5"),
    }
    nuc_oxphos = sorted({g for v in oxphos_nuc.values() for g in v})
    mt_oxphos = [g for g in ad.var_names if g.startswith("mt-")]

    GS = {"PGC1a/NRF1 respiratory TFs": [g for g in PGC1A_TFS if g in vn],
          "Nuclear OXPHOS": nuc_oxphos,
          "Na+/K+-ATPase": [g for g in NAK_ATPASE if g in vn],
          "mtDNA maintenance": [g for g in MTDNA_MAINT if g in vn],
          "Slc6a11 program": [g for g in SLC6A11_PROG if g in vn]}

    # NRF1 direct targets (CollecTRI), expressed
    net = dc.op.collectri(organism="mouse")
    nrf1_tg = sorted({g for g in net.loc[net.source == "Nrf1", "target"] if g in vn})
    GS["NRF1 targets (CollecTRI)"] = nrf1_tg

    # --- 1. per-gene SNI-vs-sham ranking (wilcoxon z) ---
    ad.obs["condition"] = pd.Categorical(ad.obs["condition"], ["sham", "sni"])
    sc.tl.rank_genes_groups(ad, "condition", groups=["sni"], reference="sham", method="wilcoxon")
    rg = sc.get.rank_genes_groups_df(ad, group="sni")[["names", "scores", "logfoldchanges"]]
    rg = rg.rename(columns={"names": "gene", "scores": "z", "logfoldchanges": "log2FC"})
    rnk = rg[["gene", "z"]].dropna().sort_values("z", ascending=False).reset_index(drop=True)
    lfc = rg.set_index("gene")["log2FC"].to_dict()

    # --- 2. GSEA prerank against the axis gene sets ---
    pre = gp.prerank(rnk=rnk, gene_sets={k: v for k, v in GS.items() if len(v) >= 5},
                     min_size=5, max_size=2000, permutation_num=2000, seed=7,
                     no_plot=True, outdir=None, threads=4)
    g2 = pre.res2d.copy()
    g2 = g2.rename(columns={"Term": "set", "NES": "nes", "FDR q-val": "fdr", "NOM p-val": "pval",
                            "Lead_genes": "leading"})
    g2["nes"] = g2["nes"].astype(float); g2["fdr"] = g2["fdr"].astype(float)

    # --- 3. per-cell signature scores + competitive background test ---
    allfc = pd.Series(lfc).dropna()
    rows = []
    for name, genes in GS.items():
        genes = [g for g in genes if g in vn]
        sc.tl.score_genes(ad, genes, score_name="_s", ctrl_size=50, use_raw=False)
        ssh, ssn = ad.obs.loc[cond == "sham", "_s"].values, ad.obs.loc[cond == "sni", "_s"].values
        p_sig = mannwhitneyu(ssh, ssn).pvalue
        setfc = allfc[allfc.index.isin(genes)].values
        p_bg = mannwhitneyu(setfc, allfc.values, alternative="less").pvalue  # set shifted DOWN vs genome
        gg = g2[g2["set"] == name]
        rows.append({"set": name, "n_genes": len(genes),
                     "mean_log2FC": round(float(np.mean(setfc)), 3),
                     "median_log2FC": round(float(np.median(setfc)), 3),
                     "score_sham": round(float(np.mean(ssh)), 4), "score_sni": round(float(np.mean(ssn)), 4),
                     "score_mwu_p": p_sig,
                     "bg_test_p": p_bg,
                     "gsea_nes": round(float(gg["nes"].iloc[0]), 2) if len(gg) else np.nan,
                     "gsea_fdr": float(gg["fdr"].iloc[0]) if len(gg) else np.nan})
    summary = pd.DataFrame(rows).sort_values("gsea_nes")
    summary.to_csv(TAB / "nrf1_axis_geneset_stats.csv", index=False)
    rnk.assign(log2FC=rnk.gene.map(lfc)).to_csv(TAB / "nrf1_axis_rank.csv", index=False)

    # running enrichment score (RES) for the two hero sets, for a GSEA plot
    hero = {}
    for term in ["Nuclear OXPHOS", "Slc6a11 program"]:
        try:
            r = pre.results[term]
            hero[f"{term}|RES"] = np.asarray(r["RES"], float)
            hero[f"{term}|hits"] = np.asarray(r.get("hits", r.get("hit_indices", [])), int)
            hero[f"{term}|nes"] = float(r["nes"]); hero[f"{term}|fdr"] = float(r["fdr"])
        except Exception as e:
            print("hero RES fail", term, e)
    hero["rank_z"] = rnk["z"].to_numpy(float)
    np.savez(TAB / "nrf1_axis_gsea_hero.npz", **hero)

    # OXPHOS by-complex log2FC (for a sub-panel) + mt sanity
    comp_rows = []
    for c, genes in oxphos_nuc.items():
        fc = allfc[allfc.index.isin(genes)]
        comp_rows.append({"complex": c, "n": len(genes), "mean_log2FC": round(float(fc.mean()), 3),
                          "frac_down": round(float((fc < 0).mean()), 2)})
    mtfc = allfc[allfc.index.isin(mt_oxphos)]
    comp_rows.append({"complex": "mtDNA-encoded (CONFOUNDED)", "n": len(mt_oxphos),
                      "mean_log2FC": round(float(mtfc.mean()), 3), "frac_down": round(float((mtfc < 0).mean()), 2)})
    pd.DataFrame(comp_rows).to_csv(TAB / "nrf1_axis_oxphos_by_complex.csv", index=False)
    # per-gene log2FC with complex label (for box/strip), nuclear only
    og = [{"gene": g, "complex": c, "log2FC": lfc.get(g, np.nan)}
          for c, gs2 in oxphos_nuc.items() for g in gs2]
    pd.DataFrame(og).dropna().to_csv(TAB / "nrf1_axis_oxphos_genes.csv", index=False)

    # respiratory-TF regulon activity (from existing decoupler ULM table)
    tf = pd.read_csv(TAB / "astro_tf_sham_vs_sni.csv").set_index("TF")
    tfrows = [{"TF": t, "activity_sham": round(tf.loc[t, "mean_sham"], 3),
               "activity_sni": round(tf.loc[t, "mean_sni"], 3),
               "delta": round(tf.loc[t, "delta_sni"], 3), "padj": tf.loc[t, "padj"]}
              for t in RESP_TFS if t in tf.index]
    pd.DataFrame(tfrows).to_csv(TAB / "nrf1_axis_resp_tf_activity.csv", index=False)
    # PGC-1a coactivator mRNA (no regulon; coactivator) — expression-level evidence
    co = []
    for g in ["Ppargc1a", "Ppargc1b"]:
        v = vec(ad, g)
        co.append({"gene": g, "log2FC": round(lfc.get(g, np.nan), 3),
                   "pct_sham": round(100 * (v[cond == "sham"] > 0).mean(), 1),
                   "pct_sni": round(100 * (v[cond == "sni"] > 0).mean(), 1),
                   "mwu_p": mannwhitneyu(v[cond == "sham"], v[cond == "sni"]).pvalue})
    pd.DataFrame(co).to_csv(TAB / "nrf1_axis_pgc1a_mrna.csv", index=False)

    pd.set_option("display.width", 200)
    print("== Gene-set statistics (GSEA prerank + per-cell score + genome-background test) ==")
    print(summary.to_string(index=False))
    print("\n== Nuclear OXPHOS by complex (+ mt sanity) ==")
    print(pd.DataFrame(comp_rows).to_string(index=False))
    print("\n== Respiratory-TF regulon activity (decoupler ULM) ==")
    print(pd.DataFrame(tfrows).to_string(index=False))
    print("\nNRF1 targets used:", nrf1_tg)


if __name__ == "__main__":
    main()
