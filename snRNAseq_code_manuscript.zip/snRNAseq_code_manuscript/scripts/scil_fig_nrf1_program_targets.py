#!/usr/bin/env python3
"""Fig. 5F: NRF1 and its CollecTRI targets inside the Slc6a11 program are all down in SNI astrocytes
(mRNA log2FC, per-cell Mann-Whitney).

Rows: Nrf1 (regulator) on top, then the four NRF1 targets that are members of the 16-gene
Slc6a11 program (Atp1b1, Gria2, Grin3a, Slc25a5; see slc6a11_tf_comparison.csv, n_program_targets).
log2FC is computed exactly as in scil_fig_slc6a11_program.py / scil_nrf1_axis_stats.py.
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse
from scipy.stats import mannwhitneyu
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False})
TAB = Path("results/scil_reanalysis/tables"); OUT = Path("results/scil_reanalysis/figures/pub")
# same palette as Fig. 5G (scil_fig_nrf1_axis.py)
PURPLE_DARK, PURPLE, PURPLE_MID = "#6A51A3", "#756BB1", "#9E9AC8"
DK = "#3a3a3a"

REGULATOR = "Nrf1"
TARGETS = {"Atp1b1": "Na⁺/K⁺-ATPase β1", "Gria2": "AMPA-R GluA2",
           "Grin3a": "NMDA-R GluN3A", "Slc25a5": "ADP/ATP carrier ANT2"}


def stars(p):
    return "****" if p < 1e-4 else "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 0.05 else "ns"


def gene_stats(ad, genes):
    cond = ad.obs["condition"].astype(str).values
    rows = []
    for g in genes:
        v = ad[:, g].X
        v = np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()
        sh, sn = v[cond == "sham"], v[cond == "sni"]
        rows.append({"gene": g,
                     "log2FC": float(np.log2((np.expm1(sn.mean()) + 1e-9) / (np.expm1(sh.mean()) + 1e-9))),
                     "pct_sham": round(100 * float((sh > 0).mean()), 1),
                     "pct_sni": round(100 * float((sn > 0).mean()), 1),
                     "mwu_p": float(mannwhitneyu(sh, sn).pvalue),
                     "n_sham": int(len(sh)), "n_sni": int(len(sn))})
    return pd.DataFrame(rows)


def panel_targets(ax, st):
    reg = st[st.gene == REGULATOR].iloc[0]
    tg = st[st.gene != REGULATOR].sort_values("log2FC", ascending=False)  # weakest at bottom
    items = [(r.gene, r.log2FC, r.mwu_p, "target") for _, r in tg.iterrows()]
    items.append((reg.gene, reg.log2FC, reg.mwu_p, "regulator"))
    y = np.arange(len(items))
    xmin = min(v for _, v, _, _ in items)
    for yi, (g, val, p, kind) in zip(y, items):
        col = PURPLE if kind == "regulator" else PURPLE_MID
        ax.barh(yi, val, height=0.6, color=col, edgecolor="white", lw=0.5, zorder=3)
        ax.text(val - 0.02, yi, stars(p), ha="right", va="center", fontsize=6.0, color="0.3")
        lab = "regulator" if kind == "regulator" else TARGETS[g]
        ax.text(-0.025, yi, lab, ha="right", va="center", fontsize=5.0, style="italic", zorder=4,
                color="white" if kind == "regulator" else DK)
    ax.axvline(0, color=DK, lw=0.8, zorder=2)
    ax.axhline(len(items) - 1.5, color="0.8", lw=0.6, ls="--", zorder=1)  # regulator vs targets divider
    ax.set_yticks(y)
    ax.set_yticklabels(["NRF1" if g == REGULATOR else g for g, *_ in items], fontsize=6.6, style="italic")
    for lab in ax.get_yticklabels():
        if lab.get_text() == "NRF1":
            lab.set_color(PURPLE); lab.set_fontweight("bold")
    ax.set_xlabel("SNI − sham mRNA log2FC", fontsize=6.2)
    ax.set_xlim(xmin * 1.22, 0.03); ax.set_ylim(-0.6, len(items) - 0.3)
    ax.set_title("NRF1 & its Slc6a11-program targets all ↓ in SNI", fontsize=7.6, pad=3)


def main():
    ad = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    st = gene_stats(ad, [REGULATOR] + list(TARGETS))
    st.to_csv(TAB / "nrf1_program_targets_mrna.csv", index=False)
    print(st.round(4).to_string(index=False))

    fig, ax = plt.subplots(figsize=(3.1, 2.1))
    panel_targets(ax, st)
    n_sh, n_sn = int(st.n_sham.iloc[0]), int(st.n_sni.iloc[0])
    fig.text(0.5, -0.08, f"PFC astrocytes ({n_sh} sham / {n_sn:,} SNI); NRF1 targets = CollecTRI targets in the "
             "16-gene Slc6a11 program;\nper-cell Mann–Whitney (**** p<1e-4). Exploratory, n=1 library/condition.",
             ha="center", va="top", fontsize=4.6, color="0.5")
    stem = OUT / "fig_nrf1_program_targets"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
