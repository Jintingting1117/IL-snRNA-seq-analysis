"""Place a figure panel inside a sub-rectangle of a larger matplotlib figure.

Panel coordinates are fractions (0-1) of the panel box; `rect`, `xy` and `text` map them to
figure fractions, so the same drawing code renders a standalone panel or a panel embedded at a
pixel box of a composite figure.
"""
from __future__ import annotations


class Panel:
    def __init__(self, fig, box_px=None, canvas_px=None):
        """box_px = (x0, y0, x1, y1) in composite pixels (y downwards); canvas_px = (W, H)."""
        self.fig = fig
        if box_px is None:
            self.x0, self.y0, self.w, self.h = 0.0, 0.0, 1.0, 1.0
        else:
            W, H = canvas_px
            x0, y0, x1, y1 = box_px
            self.x0, self.y0 = x0 / W, 1 - y1 / H
            self.w, self.h = (x1 - x0) / W, (y1 - y0) / H

    def rect(self, l, b, w, h):
        return [self.x0 + l * self.w, self.y0 + b * self.h, w * self.w, h * self.h]

    def xy(self, x, y):
        return self.x0 + x * self.w, self.y0 + y * self.h

    def fx(self, x):
        return self.x0 + x * self.w

    def text(self, x, y, s, **kw):
        return self.fig.text(*self.xy(x, y), s, **kw)

    def axes(self, l, b, w, h, **kw):
        return self.fig.add_axes(self.rect(l, b, w, h), **kw)
