#!/usr/bin/env python3
"""Augur-style cell-type prioritization (Skinnider et al., Nat Biotechnol 2021).

For each cell type, train a random-forest classifier to predict condition (sham vs SNI)
from gene expression, using balanced subsampling + cross-validated AUC. A higher mean AUC
means that cell type's transcriptome separates the conditions more strongly = ranks higher
as a "responder" to the perturbation. This naturally controls for composition (it works
WITHIN each cell type) and for cell-number differences (equal balanced subsamples per type).

Faithful re-implementation with scikit-learn (pertpy/Augur not installed). Includes a
label-permutation baseline: with only 1 library per condition, AUC cannot separate biology
from batch, so the permuted baseline shows what the real AUC must be read against.
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
os.environ.setdefault("OMP_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import warnings
from scipy import sparse
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score

warnings.simplefilter("ignore")

matplotlib.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42, "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans"], "font.size": 11, "axes.linewidth": 0.8,
})

OBJ = Path("results/scil_reanalysis/objects/scil_reanalysis_annotated.h5ad")
TAB = Path("results/scil_reanalysis/tables"); TAB.mkdir(parents=True, exist_ok=True)
FIG = Path("results/scil_reanalysis/figures/pub"); FIG.mkdir(parents=True, exist_ok=True)

MIN_PER_COND = 40        # require this many cells in BOTH conditions to assess a cell type
N_PER_COND = 40          # balanced subsample size per condition
N_SUBSAMPLES = 50        # repeated subsamples per cell type
N_TREES = 100
N_FOLDS = 3
N_HVG = 2000
SEED = 0


def get_features(adata):
    a = adata.copy()
    vl = a.var_names.str.lower()
    techy = (np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl")))
             | np.asarray(vl.str.match(r"^hb[ab]")))
    a = a[:, ~techy].copy()
    if "highly_variable" in a.var and a.var["highly_variable"].sum() >= 500:
        hv = a.var["highly_variable"].fillna(False).to_numpy()
    else:
        sc.pp.highly_variable_genes(a, n_top_genes=min(N_HVG, a.n_vars), flavor="seurat")
        hv = a.var["highly_variable"].to_numpy()
    a = a[:, hv].copy()
    X = a.X.toarray() if sparse.issparse(a.X) else np.asarray(a.X)
    return X.astype(np.float32), a.var_names.tolist()


def auc_for_subset(X, y, rng):
    """One balanced subsample -> cross-validated AUC."""
    idx0 = rng.choice(np.where(y == 0)[0], N_PER_COND, replace=False)
    idx1 = rng.choice(np.where(y == 1)[0], N_PER_COND, replace=False)
    idx = np.concatenate([idx0, idx1])
    Xs, ys = X[idx], y[idx]
    clf = RandomForestClassifier(n_estimators=N_TREES, n_jobs=4, random_state=int(rng.integers(1e6)))
    cv = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=int(rng.integers(1e6)))
    proba = cross_val_predict(clf, Xs, ys, cv=cv, method="predict_proba")[:, 1]
    return roc_auc_score(ys, proba)


def augur(X, cond, celltypes, permute=False, seed=SEED):
    rng = np.random.default_rng(seed + (777 if permute else 0))
    y_all = (cond == "sni").astype(int).to_numpy()
    if permute:
        y_all = rng.permutation(y_all)
    rows = []
    for ct in sorted(pd.unique(celltypes)):
        m = (celltypes == ct).to_numpy()
        yc = y_all[m]
        n0, n1 = int((yc == 0).sum()), int((yc == 1).sum())
        if n0 < MIN_PER_COND or n1 < MIN_PER_COND:
            continue
        Xc = X[m]
        aucs = [auc_for_subset(Xc, yc, rng) for _ in range(N_SUBSAMPLES)]
        rows.append({"celltype": ct, "n_sham": n0, "n_sni": n1,
                     "mean_auc": float(np.mean(aucs)), "std_auc": float(np.std(aucs)),
                     "auc_q25": float(np.quantile(aucs, .25)), "auc_q75": float(np.quantile(aucs, .75))})
    return pd.DataFrame(rows)


def plot(df, path_stem):
    d = df.sort_values("mean_auc")
    fig, ax = plt.subplots(figsize=(6.6, 0.45 * len(d) + 1.2))
    ax.barh(d["celltype"], d["mean_auc"] - 0.5, left=0.5, color="#4c78b8",
            xerr=d["std_auc"], error_kw=dict(elinewidth=0.8, ecolor="0.3"), height=0.62)
    if "mean_auc_perm" in d:
        ax.scatter(d["mean_auc_perm"], d["celltype"], color="0.45", s=22, zorder=5,
                   label="permuted (null)")
        ax.legend(frameon=False, fontsize=9, loc="lower right")
    ax.axvline(0.5, color="black", lw=0.8)
    ax.set_xlim(0.5, max(1.0, d["mean_auc"].max() + 0.05))
    ax.set_xlabel("Cell-type prioritization AUC (sham vs SNI)")
    ax.set_title("Augur: which cell types separate the conditions", fontsize=12)
    for i, (_, r) in enumerate(d.iterrows()):
        ax.text(r["mean_auc"] + r["std_auc"] + 0.005, i, f"{r['mean_auc']:.3f}",
                va="center", fontsize=8.5)
    fig.tight_layout()
    fig.savefig(path_stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(path_stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def main():
    adata = sc.read_h5ad(OBJ)
    # restrict to well-defined coarse cell types (drop doublet/low-quality buckets)
    keep = ~adata.obs["celltype_final"].astype(str).isin(["Doublet_cluster", "Low_quality_Unknown", "Unknown"])
    adata = adata[keep].copy()
    print("cells:", adata.n_obs)
    X, genes = get_features(adata)
    print("features:", len(genes))

    real = augur(X, adata.obs["condition"], adata.obs["celltype_final"], permute=False)
    perm = augur(X, adata.obs["condition"], adata.obs["celltype_final"], permute=True)
    perm = perm.rename(columns={"mean_auc": "mean_auc_perm"})[["celltype", "mean_auc_perm"]]
    out = real.merge(perm, on="celltype", how="left").sort_values("mean_auc", ascending=False)
    out.to_csv(TAB / "augur_celltype_auc.csv", index=False)
    print(out[["celltype", "n_sham", "n_sni", "mean_auc", "std_auc", "mean_auc_perm"]].round(3).to_string(index=False))
    plot(out, FIG / "augur_auc_barplot")
    print("\nWrote:", TAB / "augur_celltype_auc.csv", "and", FIG / "augur_auc_barplot.(png/pdf)")


if __name__ == "__main__":
    main()
