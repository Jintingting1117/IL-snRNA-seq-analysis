#!/usr/bin/env python3
"""Statistical support for the PGC-1a -> NRF1 mitochondrial-biogenesis axis (SNI astrocytes).

a  GSEA running-enrichment: the axis effector sets (Nuclear OXPHOS, Slc6a11 program) are
   depleted toward the down-in-SNI end of the genome-wide ranking (NES + FDR).
b  GSEA NES across all axis gene sets — honest: program / OXPHOS / Na-K-ATPase FDR-significant,
   NRF1-target & TF-mRNA sets only a trend, mtDNA-maintenance NS.
c  Regulator level: PGC-1a-coactivated respiratory-TF regulon activity (decoupler ULM) all down;
   PGC-1a (Ppargc1a) mRNA down.
d  Effector level: nuclear-encoded OXPHOS subunits down (complexes III-V); mtDNA-encoded genes
   excluded (up — driven by the SNI mito% batch confound, shown as a flagged sanity row).
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.gridspec import GridSpecFromSubplotSpec
import numpy as np
import pandas as pd
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False})
TAB = Path("results/scil_reanalysis/tables"); OUT = Path("results/scil_reanalysis/figures/pub")
# Match the light ColorBrewer Purples used in Fig. 07, panel b.
PURPLE_DARK, PURPLE, PURPLE_MID = "#6A51A3", "#756BB1", "#9E9AC8"
PURPLE_LIGHT, PURPLE_PALE = "#CBC9E2", "#F2F0F7"
DK, GREY = "#3a3a3a", "#9AA0A6"
SHAM, SNI = PURPLE, PURPLE_LIGHT


def stars(p):
    return "****" if p < 1e-4 else "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < 0.05 else "ns"


def fdr_txt(q):
    return "FDR<0.001" if q < 1e-3 else f"FDR={q:.3f}" if q < 0.05 else f"FDR={q:.2f} (ns)"


# ---------- a  classic 3-tier GSEA enrichment plot (standard Hallmark OXPHOS = NRF1 effector pathway)
def panel_gsea(fig, spec, npz):
    z = npz["rank_z"]; n = len(z)
    res = npz["RES"]; nes = float(npz["nes"]); fdr = float(npz["fdr"]); hits = npz["hits"]
    nhit = int(npz["nhit"])
    sub = GridSpecFromSubplotSpec(3, 1, subplot_spec=spec, height_ratios=[1.0, 0.10, 0.20], hspace=0.06)
    ax1 = fig.add_subplot(sub[0]); ax2 = fig.add_subplot(sub[1], sharex=ax1); ax3 = fig.add_subplot(sub[2], sharex=ax1)
    # RES curve
    ax1.plot(np.arange(n), res, color=PURPLE, lw=1.4, zorder=3)
    ax1.fill_between(np.arange(n), res, 0, color=PURPLE, alpha=0.12, zorder=2)
    ax1.axhline(0, color="0.7", lw=0.6)
    ei = int(np.argmin(res)); ax1.scatter([ei], [res[ei]], s=16, color=PURPLE, zorder=4)
    ax1.annotate(f"ES = {res[ei]:.2f}", (ei, res[ei]), xytext=(8, 6), textcoords="offset points", fontsize=5.6, color=PURPLE)
    ax1.text(0.03, 0.10, f"OXPHOS — KEGG (n={nhit})\nNES = {nes:.2f},  {fdr_txt(fdr)}",
             transform=ax1.transAxes, fontsize=6.4, va="bottom", color=DK,
             bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=PURPLE, lw=0.8))
    ax1.set_ylim(min(res) - 0.05, 0.06); ax1.set_ylabel("running ES", fontsize=6.8)
    ax1.tick_params(labelbottom=False); ax1.set_xlim(0, n)
    ax1.set_title("Zoom on OXPHOS (NRF1 effector): depletes at the down-in-SNI pole", fontsize=7.4, pad=3)
    # hit rug
    ax2.vlines(hits, 0, 1, color=DK, lw=0.4, alpha=0.85)
    ax2.set_yticks([]); ax2.set_ylabel("hits", fontsize=5.2, rotation=0, ha="right", va="center")
    ax2.tick_params(labelbottom=False)
    for s in ax2.spines.values():
        s.set_visible(False)
    # ranked metric signal
    ax3.fill_between(np.arange(n), z, 0, where=(z >= 0), color=SNI, lw=0, alpha=0.7)
    ax3.fill_between(np.arange(n), z, 0, where=(z < 0), color=SHAM, lw=0, alpha=0.7)
    ax3.axhline(0, color="0.7", lw=0.5); ax3.set_yticks([])
    ax3.set_ylabel("rank\nmetric", fontsize=5.2, rotation=0, ha="right", va="center")
    ax3.set_xticks([0, n]); ax3.set_xticklabels(["up in SNI", "down in SNI"], fontsize=6)
    for s in ["left", "right", "top"]:
        ax3.spines[s].set_visible(False)
    return ax1


# ---------- KEGG landscape: unbiased top SNI-down pathways (OXPHOS leads -> NRF1)
LAND = [("Proximal tubule bicarbonate reclamation", "Proximal-tubule HCO₃⁻ reclam.", "other"),
        ("Oxidative phosphorylation", "Oxidative phosphorylation", "oxphos"),
        ("Protein processing in endoplasmic reticulum", "Protein processing in ER", "other"),
        ("Parkinson disease", "Parkinson disease", "mito"),
        ("Phagosome", "Phagosome", "other"),
        ("Ubiquitin mediated proteolysis", "Ubiquitin-mediated proteolysis", "other"),
        ("Non-alcoholic fatty liver disease (NAFLD)", "NAFLD", "mito"),
        ("Citrate cycle (TCA cycle)", "Citrate cycle (TCA)", "mito")]
CAT = {"oxphos": PURPLE, "mito": PURPLE_MID, "other": GREY}


def panel_kegg(ax, kegg):
    k = kegg.set_index("term")
    items = sorted([(d, float(k.loc[t, "nes"]), float(k.loc[t, "fdr"]), c) for t, d, c in LAND],
                   key=lambda r: r[1])  # most-negative NES first
    y = np.arange(len(items))[::-1]
    for yi, (disp, nes, fdr, cat) in zip(y, items):
        sig = fdr < 0.05
        col = CAT[cat]
        ax.barh(yi, nes, height=0.66, color=col if sig else "white", edgecolor=col, lw=1.0,
                hatch=None if sig else "////", alpha=0.95 if sig else 0.9, zorder=3)
        ax.text(0.04, yi, fdr_txt(fdr), ha="left", va="center", fontsize=5.2,
                color="0.2" if sig else "0.55", fontweight="bold" if sig else "normal")
    ax.axvline(0, color=DK, lw=0.8)
    ax.set_yticks(y); ax.set_yticklabels([r[0] for r in items], fontsize=6.0)
    for lab in ax.get_yticklabels():
        if lab.get_text() == "Oxidative phosphorylation":
            lab.set_color(PURPLE); lab.set_fontweight("bold")
    oy = y[[r[0] for r in items].index("Oxidative phosphorylation")]
    ax.text(0.62, oy, "NRF1's effector ▶ b", fontsize=5.8, color=PURPLE, fontweight="bold", va="center")
    ax.set_xlabel("GSEA NES — KEGG (SNI vs sham)", fontsize=6.8)
    ax.set_xlim(-2.35, 1.55); ax.set_ylim(-0.7, len(items) - 0.3)
    handles = [plt.Rectangle((0, 0), 1, 1, fc=PURPLE, ec=PURPLE),
               plt.Rectangle((0, 0), 1, 1, fc=PURPLE_MID, ec=PURPLE_MID),
               plt.Rectangle((0, 0), 1, 1, fc="white", ec="0.4", hatch="////")]
    ax.legend(handles, ["OXPHOS (mito energy)", "shares ETC genes", "trend (FDR≥0.05)"],
              loc="lower right", frameon=False, fontsize=4.8, handlelength=1.0, handleheight=1.1,
              bbox_to_anchor=(1.0, -0.02))
    ax.set_title("Unbiased KEGG landscape: OXPHOS leads the SNI-down pathways", fontsize=7.4, pad=3)


# ---------- c  regulator level: PGC-1a mRNA + respiratory-TF regulon activity (Δ, comparable)
def panel_reg(ax, tf, pgc):
    tf = tf.sort_values("delta", ascending=True).reset_index(drop=True)  # NRF1 (most -) first
    pr = pgc[pgc.gene == "Ppargc1a"].iloc[0]
    # rows bottom->top: TFs (weakest at bottom) then PGC-1a on top
    items = [(t.TF, t.delta, t.padj, "act") for _, t in tf.iloc[::-1].iterrows()]
    items.append(("Ppargc1a", pr.log2FC, pr.mwu_p, "mrna"))
    nm = {"Nrf1": "NRF1", "Gabpa": "GABP(α)", "Esrra": "ERRα", "Esrrg": "ERRγ",
          "Yy1": "YY1", "Ppargc1a": "PGC-1α"}
    y = np.arange(len(items))
    for yi, (tfn, val, p, kind) in zip(y, items):
        col = PURPLE_DARK if kind == "mrna" else PURPLE if tfn == "Nrf1" else PURPLE_MID
        ax.barh(yi, val, height=0.6, color=col, edgecolor="white", lw=0.5, zorder=3)
        ax.text(val - 0.006, yi, stars(p), ha="right", va="center", fontsize=6.0, color="0.3")
    ax.axvline(0, color=DK, lw=0.8, zorder=2)
    ax.axhline(len(items) - 1.5, color="0.8", lw=0.6, ls="--", zorder=1)  # mRNA vs activity divider
    ax.set_yticks(y)
    yl = [nm[t] + ("  (mRNA)" if k == "mrna" else "") for (t, _, _, k) in items]
    ax.set_yticklabels(yl, fontsize=6.6, style="italic")
    for lab in ax.get_yticklabels():
        if lab.get_text() == "NRF1":
            lab.set_color(PURPLE); lab.set_fontweight("bold")
        if "PGC-1α" in lab.get_text():
            lab.set_color(PURPLE_DARK)
    ax.set_xlabel("SNI − sham change\n(TFs: Δ regulon activity, ULM   ·   PGC-1α: mRNA log2FC)", fontsize=6.2)
    ax.set_xlim(-0.42, 0.03); ax.set_ylim(-0.6, len(items) - 0.3)
    ax.text(-0.41, len(items) - 1, "coactivator", fontsize=5.0, color=PURPLE_DARK, style="italic", va="center")
    ax.set_title("Regulator: PGC-1α & its respiratory TFs all ↓ in SNI", fontsize=7.6, pad=3)


# ---------- d  effector level: nuclear OXPHOS by complex
def panel_oxphos(ax, og, comp):
    order = ["CI (Ndufx)", "CII (Sdhx)", "CIII (Uqcr/Cyc1)", "CIV (Coxx)", "CV (Atp5x)"]
    y = {c: i for i, c in enumerate(order[::-1])}
    rng = np.random.default_rng(0)
    for c in order:
        sub = og[og["complex"] == c]
        yy = y[c] + (rng.random(len(sub)) - 0.5) * 0.42
        ax.scatter(sub.log2FC, yy, s=7, color=PURPLE, alpha=0.55, linewidths=0, zorder=2)
        med = float(np.median(sub.log2FC))
        ax.plot([med, med], [y[c] - 0.32, y[c] + 0.32], color=DK, lw=1.6, zorder=3)
        ax.text(-2.35, y[c], c.split(" ")[0], ha="left", va="center", fontsize=6.4, fontweight="bold")
        ax.text(2.35, y[c], f"{med:+.2f}", ha="right", va="center", fontsize=5.6,
                color=PURPLE_DARK if med < -0.05 else "0.5")
    # mtDNA confounded row
    yc = len(order)
    mt = comp[comp["complex"].str.startswith("mtDNA")].iloc[0]
    ax.scatter([mt.mean_log2FC], [yc], s=22, marker="s", color=GREY, zorder=3)
    ax.text(-2.35, yc, "mtDNA", ha="left", va="center", fontsize=6.4, color="0.55", fontweight="bold")
    ax.text(2.35, yc, f"{mt.mean_log2FC:+.2f}", ha="right", va="center", fontsize=5.6, color="0.55")
    ax.text(mt.mean_log2FC, yc + 0.34, "excluded: mito% confound", ha="center", fontsize=5.0,
            color="0.55", style="italic")
    ax.axvline(0, color=DK, lw=0.8, zorder=1)
    ax.axvspan(-2.5, 0, color=PURPLE_PALE, zorder=0)
    ax.set_yticks([]); ax.set_ylim(-0.6, yc + 0.7); ax.set_xlim(-2.5, 2.5)
    ax.set_xlabel("per-gene log2FC (SNI vs sham)", fontsize=6.8)
    ax.set_title("Effector: nuclear OXPHOS subunits ↓ (CIII–CV); thick bar = median", fontsize=7.6, pad=3)


def main():
    kegg = pd.read_csv(TAB / "nrf1_axis_kegg_full.csv")
    tf = pd.read_csv(TAB / "nrf1_axis_resp_tf_activity.csv")
    pgc = pd.read_csv(TAB / "nrf1_axis_pgc1a_mrna.csv")
    og = pd.read_csv(TAB / "nrf1_axis_oxphos_genes.csv")
    comp = pd.read_csv(TAB / "nrf1_axis_oxphos_by_complex.csv")
    npz = np.load(TAB / "nrf1_axis_gsea_kegg.npz")

    fig = plt.figure(figsize=(9.0, 6.4))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.0], width_ratios=[1.0, 1.04],
                          hspace=0.5, wspace=0.52, left=0.12, right=0.975, top=0.92, bottom=0.09)
    ax_a = fig.add_subplot(gs[0, 0]); panel_kegg(ax_a, kegg)
    ax_b = panel_gsea(fig, gs[0, 1], npz)
    ax_c = fig.add_subplot(gs[1, 0]); panel_reg(ax_c, tf, pgc)
    ax_d = fig.add_subplot(gs[1, 1]); panel_oxphos(ax_d, og, comp)
    for ax, lab in [(ax_a, "a"), (ax_b, "b"), (ax_c, "c"), (ax_d, "d")]:
        ax.text(-0.16, 1.04, lab, transform=ax.transAxes, fontsize=11, fontweight="bold", va="bottom")
    fig.suptitle("The PGC-1α → NRF1 mitochondrial-biogenesis axis is coordinately suppressed in SNI astrocytes",
                 fontsize=9, y=0.985)
    fig.text(0.5, 0.012, "PFC astrocytes (783 sham / 1038 SNI); GSEA prerank (≥1000 perm) on wilcoxon SNI-vs-sham "
             "ranking, standard MSigDB/KEGG/GO/Reactome terms; TF activity = decoupler ULM (CollecTRI) padj. "
             "Exploratory, n=1 library/condition.", ha="center", fontsize=5.0, color="0.5")
    stem = OUT / "fig_nrf1_axis"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
