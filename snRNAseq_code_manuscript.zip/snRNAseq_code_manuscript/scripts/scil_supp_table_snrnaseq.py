#!/usr/bin/env python3
"""Supplementary data table for the snRNA-seq analyses of manuscript-1011 (Figs 3, 5, S7, S8).

Collects, in one Excel workbook, the data underlying every snRNA-seq panel and number in the
manuscript. Values are re-derived from the same objects / tables the figure scripts use, and key
manuscript numbers are asserted at the end so the workbook cannot silently drift from the text.

    python scripts/scil_supp_table_snrnaseq.py [out.xlsx]
"""
from __future__ import annotations
import os, re, sys, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import scanpy as sc
import gseapy as gp
from scipy import sparse
from scipy.stats import mannwhitneyu, pearsonr

warnings.simplefilter("ignore")
ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results/scil_reanalysis"
TAB, OBJ = RES / "tables", RES / "objects"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "社交manuscript-1011_TableS_snRNAseq.xlsx"
GMT = Path.home() / ".cache/gseapy/Enrichr.MSigDB_Hallmark_2020.gmt"
COND = {"sham": "Sham", "sni": "SNI"}

# ---------------------------------------------------------------- gene sets (as in figure scripts)
HOMEOSTATIC16 = ["Slc6a11", "Slc6a1", "Kcnj10", "Slc4a4", "Atp1a2", "Atp1b2", "Gja1", "Aqp4", "Glul",
                 "Slc1a2", "Slc1a3", "Kcnj16", "Clcn2", "Slc12a2", "S100b", "Gjb6"]
HOMEO_CAT = {"Slc6a11": "GABA transport", "Slc6a1": "GABA transport", "Kcnj10": "Potassium buffering",
             "Kcnj16": "Potassium buffering", "Slc4a4": "Acid–base regulation",
             "Atp1a2": "ATP-dependent ion transport (Na+/K+-ATPase)",
             "Atp1b2": "ATP-dependent ion transport (Na+/K+-ATPase)", "Gja1": "Gap-junction coupling",
             "Gjb6": "Gap-junction coupling", "Aqp4": "Water transport", "Slc1a2": "Glutamate uptake",
             "Slc1a3": "Glutamate uptake", "Glul": "Glutamate metabolism", "Clcn2": "Chloride homeostasis",
             "Slc12a2": "Chloride homeostasis", "S100b": "Astrocytic Ca2+-binding protein"}
PROG = ["Slc6a11", "Slc6a1", "Atp1b1", "Atp1a2", "Atp1b2", "Gria1", "Gria2", "Gria3", "Gria4",
        "Grin2b", "Grin3a", "Kcnj10", "Slc4a4", "Slc25a18", "Slc25a5", "Car10"]
SYN_MARKERS = ["Gria1", "Gria2", "Slc4a4", "Lrrc4c", "Car10", "Robo2", "Sema6d", "Shisa9", "Zfhx4"]
REACT_MARKERS = ["Gfap", "Apoe", "Sparcl1", "Vim", "Id3", "Myoc", "Serpina3n", "Nrp2"]
TRANSPORTERS_3H = ["Slc1a2", "Slc6a13", "Slc1a3", "Slc6a1", "Slc6a11", "Slc6a9"]
UBIQUITOUS = ["Malat1", "Xist", "Gm42418", "Gm26917", "AY036118", "Gm10754", "Gm26871", "Kcnq1ot1"]

CT_ORDER = ["Excitatory_neuron", "Inhibitory_neuron", "Astrocyte", "Oligodendrocyte", "OPC", "Microglia",
            "Endothelial", "Pericyte_VSMC", "Fibroblast_meningeal", "Ependymal"]
CT_DISP = {"Excitatory_neuron": "Excitatory neuron", "Inhibitory_neuron": "Inhibitory neuron",
           "Astrocyte": "Astrocyte", "Oligodendrocyte": "Oligodendrocyte", "OPC": "OPC",
           "Microglia": "Microglia", "Endothelial": "Endothelial", "Pericyte_VSMC": "Pericyte/VSMC",
           "Fibroblast_meningeal": "VLMC/Fibroblast", "Ependymal": "Ependymal",
           "Doublet_cluster": "Doublet-enriched cluster"}
CT_MARKERS = {"Excitatory neuron": ["Slc17a7", "Satb2"], "Inhibitory neuron": ["Gad1", "Gad2"],
              "Astrocyte": ["Aqp4", "Gja1", "Slc1a2"], "Oligodendrocyte": ["Plp1", "Mobp", "Mog"],
              "OPC": ["Pdgfra", "Cspg4"], "Microglia": ["Csf1r", "P2ry12", "C1qa"],
              "Endothelial": ["Cldn5", "Flt1"], "Pericyte/VSMC": ["Rgs5", "Pdgfrb"],
              "VLMC/Fibroblast": ["Col1a1", "Dcn"], "Ependymal": ["Foxj1", "Tmem212"]}
SUB_MAIN = ["Homeostatic", "Synapse-associated", "Reactive"]
SUB_DOT = {"Homeostatic": ["Slco1c1", "Pde10a", "Grm3"], "Synapse-associated": ["Slc4a4", "Gria1", "Car10"],
           "Reactive": ["Gfap", "Apoe", "Sparcl1"], "Transporters": ["Slc6a11", "Slc6a1", "Slc6a9"]}
EXN_LABELS = {"0": "L5/6 IT (Erbb4+)", "1": "L6 CT", "3": "L5/6 NP", "4": "L2/3 IT", "5": "L2/3 IT",
              "6": "L5 ET/PT", "7": "L6 IT", "8": "L4/5 IT (Rorb+)", "9": "L5 ET/PT", "10": "L5/6 deep (Trpm3+)"}
EXN_ORDER = ["L2/3 IT", "L4/5 IT (Rorb+)", "L5 ET/PT", "L5/6 NP", "L5/6 IT (Erbb4+)", "L6 IT", "L6 CT",
             "L5/6 deep (Trpm3+)"]
EXN_DOT = {"Pan-excitatory": ["Slc17a7", "Satb2"], "L2/3": ["Cux2", "Rasgrf2", "Calb1"], "L4/5 IT": ["Rorb"],
           "L5 ET/PT": ["Fezf2", "Bcl11b", "Pcp4"], "NP": ["Tshz2", "Slc17a6"], "L6 IT": ["Sulf1", "Oprk1"],
           "L6 CT": ["Foxp2", "Tle4", "Zfpm2", "Syt6"], "Local/atypical": ["Erbb4", "Trpm3"],
           "GABAergic (negative control)": ["Gad1", "Gad2"]}
KEGG_5A = ["Proximal tubule bicarbonate reclamation", "Oxidative phosphorylation",
           "Protein processing in endoplasmic reticulum", "Parkinson disease", "Phagosome",
           "Ubiquitin mediated proteolysis", "Non-alcoholic fatty liver disease (NAFLD)",
           "Citrate cycle (TCA cycle)"]
S7G_TERMS = [("regulation of cation channel activity", "Cation-channel regulation"),
             ("regulation of neurotransmitter receptor activity", "Neurotransmitter-receptor reg."),
             ("modulation of chemical synaptic", "Synaptic transmission modulation"),
             ("RHO GTPase Cycle", "Rho-GTPase cycle"),
             ("regulation of cell migration", "Cell-migration regulation"),
             ("Signaling By Receptor Tyrosine Kinases", "Receptor tyrosine-kinase sig."),
             ("ErbB signaling pathway", "ErbB signaling (Erbb4)")]
TF_5E = ["Nrf1", "Klf9", "Tcf12", "Srebf1", "Srebf2", "Esrrg"]
RESP_TF_5G = [("Nrf1", "NRF1"), ("Yy1", "YY1"), ("Esrrg", "ERRγ"), ("Esrra", "ERRα"), ("Gabpa", "GABPα")]


def col(a, g):
    v = a[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def mat(a, genes):
    v = a[:, genes].X
    return np.asarray(v.todense()) if sparse.issparse(v) else np.asarray(v)


def log2fc(sn, sh):  # same estimator as scanpy rank_genes_groups / figure scripts
    return float(np.log2((np.expm1(sn.mean()) + 1e-9) / (np.expm1(sh.mean()) + 1e-9)))


def describe(v):
    return dict(n=len(v), mean=v.mean(), sd=v.std(ddof=1), median=np.median(v),
                q1=np.percentile(v, 25), q3=np.percentile(v, 75))


def check(name, got, want, tol):
    ok = abs(got - want) <= tol
    print(f"[check] {name}: {got:.4f} (manuscript {want}) {'OK' if ok else 'MISMATCH'}")
    CHECKS.append((name, got, want, ok))


CHECKS: list = []
SHEETS: list = []   # (sheet, title, notes[list], blocks[list of (subtitle|None, df)])


def add(sheet, title, notes, *blocks):
    SHEETS.append((sheet, title, notes, [b if isinstance(b, tuple) else (None, b) for b in blocks]))


# ================================================================ whole dataset
print("loading whole-dataset object ...")
A = sc.read_h5ad(OBJ / "scil_reanalysis_annotated.h5ad")
A.obs["cond"] = A.obs["condition"].astype(str).map(COND)
n_lib = A.obs["cond"].value_counts()
check("total nuclei", A.n_obs, 23909, 0); check("Sham nuclei", n_lib["Sham"], 11731, 0)
check("SNI nuclei", n_lib["SNI"], 12178, 0)

# --- QC
qs = pd.read_csv(TAB / "qc_summary_by_sample.csv").set_index(["stage", "sample"])
qt = pd.read_csv(TAB / "qc_thresholds.csv").set_index("sample")
qc_rows = []
def qrow(metric, f):
    qc_rows.append({"Metric": metric, "Sham": f("sham"), "SNI": f("sni")})
qrow("Nuclei called by Cell Ranger", lambda s: int(qs.loc[("before_filter", s), "n_cells"]))
qrow("Nuclei passing count / gene / mitochondrial / hemoglobin filters", lambda s: int(qs.loc[("after_basic_qc", s), "n_cells"]))
qrow("Doublets removed (Scrublet)", lambda s: int(qs.loc[("after_basic_qc", s), "n_cells"] - qs.loc[("after_doublet_removal", s), "n_cells"]))
qrow("Nuclei retained for analysis", lambda s: int(qs.loc[("after_doublet_removal", s), "n_cells"]))
qrow("Median genes per nucleus (retained)", lambda s: qs.loc[("after_doublet_removal", s), "median_genes"])
qrow("Median UMIs per nucleus (retained)", lambda s: qs.loc[("after_doublet_removal", s), "median_counts"])
qrow("Median mitochondrial transcript fraction, % (retained)", lambda s: round(qs.loc[("after_doublet_removal", s), "median_pct_mt"], 3))
qrow("Threshold: minimum genes per nucleus", lambda s: int(qt.loc[s, "min_genes"]))
qrow("Threshold: minimum UMIs per nucleus", lambda s: int(qt.loc[s, "min_counts"]))
qrow("Threshold: maximum UMIs per nucleus (median + 5 MAD, log scale)", lambda s: round(qt.loc[s, "max_counts_mad"]))
qrow("Threshold: maximum genes per nucleus (median + 5 MAD, log scale)", lambda s: round(qt.loc[s, "max_genes_mad"]))
qrow("Threshold: maximum mitochondrial fraction, % (median + 5 MAD, bounded 2.5–10%)", lambda s: round(qt.loc[s, "max_pct_mt"], 3))
qrow("Threshold: maximum hemoglobin fraction, %", lambda s: qt.loc[s, "max_pct_hb"])
qrow("Threshold: Scrublet doublet score", lambda s: 0.2)

# --- per-nucleus metadata
umap = A.obsm["X_umap"]
nuc = pd.DataFrame({
    "Barcode": A.obs_names, "Group": A.obs["cond"].values,
    "Cell type": A.obs["celltype_final"].astype(str).map(CT_DISP).values,
    "Leiden cluster": A.obs["leiden"].astype(str).values,
    "UMAP_1": umap[:, 0].round(4), "UMAP_2": umap[:, 1].round(4),
    "Genes detected": A.obs["n_genes_by_counts"].astype(int).values,
    "UMIs": A.obs["total_counts"].astype(int).values,
    "Mitochondrial fraction (%)": A.obs["pct_counts_mt"].astype(float).round(4).values,
    "Scrublet doublet score": A.obs["doublet_score"].astype(float).round(4).values})

# --- cell-type composition (Fig. 3A)
ct = A.obs["celltype_final"].astype(str)
cnt = pd.crosstab(ct, A.obs["cond"]).reindex(CT_ORDER + ["Doublet_cluster"]).fillna(0).astype(int)
comp = pd.DataFrame({"Cell type": [CT_DISP[c] for c in cnt.index],
                     "Sham (n)": cnt["Sham"].values, "SNI (n)": cnt["SNI"].values,
                     "Total (n)": cnt.sum(1).values,
                     "Sham (% of nuclei)": (100 * cnt["Sham"] / n_lib["Sham"]).round(2).values,
                     "SNI (% of nuclei)": (100 * cnt["SNI"] / n_lib["SNI"]).round(2).values})
comp.loc[len(comp)] = ["Total", n_lib["Sham"], n_lib["SNI"], A.n_obs, 100.0, 100.0]

# --- marker dot plot (Fig. 3B)
keep = A[ct.isin(CT_ORDER).values]
kct = keep.obs["celltype_final"].astype(str).map(CT_DISP).values
genes = [g for gs in CT_MARKERS.values() for g in gs]
M = mat(keep, genes)
dot = []
means = np.vstack([M[kct == CT_DISP[c]].mean(0) for c in CT_ORDER])
scaled = (means - means.min(0)) / (means.max(0) - means.min(0))
for i, c in enumerate(CT_ORDER):
    m = kct == CT_DISP[c]
    for grp, gs in CT_MARKERS.items():
        for g in gs:
            j = genes.index(g)
            dot.append({"Cell type": CT_DISP[c], "Marker for": grp, "Gene": g,
                        "% nuclei expressing": round(100 * (M[m, j] > 0).mean(), 2),
                        "Mean expression (log-normalized)": round(means[i, j], 4),
                        "Scaled mean (0–1 across cell types)": round(scaled[i, j], 4)})
dot = pd.DataFrame(dot)

# --- excitatory subtypes (Fig. S7A–C)
E = sc.read_h5ad(OBJ / "excitatory_subset.h5ad")
E = E[E.obs["sub"].astype(str).isin(EXN_LABELS)].copy()
E.obs["subtype"] = E.obs["sub"].astype(str).map(EXN_LABELS)
check("excitatory nuclei in S7A", E.n_obs, 7291, 0)
nuc["Excitatory subtype (Fig. S7A)"] = nuc["Barcode"].map(E.obs["subtype"]).fillna("")
ec = pd.crosstab(E.obs["subtype"], E.obs["condition"].astype(str).map(COND)).reindex(EXN_ORDER)
exn_counts = pd.DataFrame({"Excitatory subtype": EXN_ORDER, "Sham (n)": ec["Sham"].values,
                           "SNI (n)": ec["SNI"].values, "Total (n)": ec.sum(1).values,
                           "Sham (% of excitatory)": (100 * ec["Sham"] / ec["Sham"].sum()).round(2).values,
                           "SNI (% of excitatory)": (100 * ec["SNI"] / ec["SNI"].sum()).round(2).values})
eg = [g for gs in EXN_DOT.values() for g in gs]
EM = mat(E, eg); est = E.obs["subtype"].values
emean = np.vstack([EM[est == s].mean(0) for s in EXN_ORDER])
ez = (emean - emean.mean(0)) / (emean.std(0) + 1e-9)
exn_dot = []
for i, s in enumerate(EXN_ORDER):
    m = est == s
    for grp, gs in EXN_DOT.items():
        for g in gs:
            j = eg.index(g)
            exn_dot.append({"Excitatory subtype": s, "Marker class": grp, "Gene": g,
                            "% nuclei expressing": round(100 * (EM[m, j] > 0).mean(), 2),
                            "Mean expression (log-normalized)": round(emean[i, j], 4),
                            "Z-scored mean (across subtypes)": round(ez[i, j], 4)})
exn_dot = pd.DataFrame(exn_dot)
del E, EM, keep, M

# ================================================================ astrocytes
print("loading astrocyte object ...")
a = sc.read_h5ad(OBJ / "astrocytes_deepdive.h5ad")
cond = a.obs["condition"].astype(str).values
sh, sn = cond == "sham", cond == "sni"
sub = a.obs["substate"].astype(str).values
check("astrocytic nuclei", a.n_obs, 1821, 0)
cnts = a.layers["counts"]
neu = np.asarray(cnts[:, [a.var_names.get_loc(g) for g in ["Snap25", "Syt1", "Rbfox3"]]].sum(1)).ravel()
tot = np.asarray(cnts.sum(1)).ravel()
neu_frac = 100 * float(np.mean(neu / tot))
check("neuron-restricted UMI % in astrocytes", neu_frac, 0.15, 0.005)
qc_rows.append({"Metric": "High-confidence astrocytic nuclei", "Sham": int(sh.sum()), "SNI": int(sn.sum())})
qc_rows.append({"Metric": "Astrocytic nuclei: neuron-restricted transcripts (Snap25, Syt1, Rbfox3), mean % of UMIs",
                "Sham": round(100 * float(np.mean((neu / tot)[sh])), 3), "SNI": round(100 * float(np.mean((neu / tot)[sn])), 3)})
qc = pd.DataFrame(qc_rows)

# --- substate composition (Fig. 3E–G, S8A–B)
sc_ = pd.crosstab(a.obs["substate"].astype(str), cond).reindex(SUB_MAIN + ["Low-quality"])
subcomp = pd.DataFrame({"Astrocyte state": sc_.index, "Sham (n)": sc_["sham"].values, "SNI (n)": sc_["sni"].values,
                        "Total (n)": sc_.sum(1).values,
                        "Sham (% of astrocytes)": (100 * sc_["sham"] / sh.sum()).round(2).values,
                        "SNI (% of astrocytes)": (100 * sc_["sni"] / sn.sum()).round(2).values})
subcomp.loc[len(subcomp)] = ["Total", int(sh.sum()), int(sn.sum()), a.n_obs, 100.0, 100.0]
pct = subcomp.set_index("Astrocyte state")
check("synapse-associated % Sham", pct.loc["Synapse-associated", "Sham (% of astrocytes)"], 25.93, 0.005)
check("synapse-associated % SNI", pct.loc["Synapse-associated", "SNI (% of astrocytes)"], 7.32, 0.005)
check("reactive-like % Sham", pct.loc["Reactive", "Sham (% of astrocytes)"], 4.98, 0.005)
check("reactive-like % SNI", pct.loc["Reactive", "SNI (% of astrocytes)"], 9.73, 0.005)
subcomp["Astrocyte state"] = subcomp["Astrocyte state"].replace({"Reactive": "Reactive-like"})

# substate naming scores per Leiden cluster (scores stored by scil_astrocyte_deepdive.py)
nm = (a.obs.groupby("leiden_sub", observed=True)
      .agg(n=("substate", "size"), state=("substate", lambda s: s.astype(str).iloc[0]),
           syn=("dn_synapse", "mean"), rea=("dn_reactive", "mean")).reset_index())
assert (nm.groupby("leiden_sub")["state"].nunique() <= 1).all()
naming = pd.DataFrame({"Leiden cluster (astrocyte reclustering)": nm["leiden_sub"].astype(str),
                       "Nuclei (n)": nm["n"], "Synapse-associated marker score (mean)": nm["syn"].round(4),
                       "Reactive-like marker score (mean)": nm["rea"].round(4),
                       "Assigned state": nm["state"].replace({"Reactive": "Reactive-like"})})

# substate dot plot (Fig. 3F)
sg = [g for gs in SUB_DOT.values() for g in gs]
SM = mat(a, sg)
smean = np.vstack([SM[sub == s].mean(0) for s in SUB_MAIN])
sscaled = (smean - smean.min(0)) / (np.ptp(smean, axis=0) + 1e-9)
sub_dot = []
for i, s in enumerate(SUB_MAIN):
    m = sub == s
    for grp, gs in SUB_DOT.items():
        for g in gs:
            j = sg.index(g)
            sub_dot.append({"Astrocyte state": s.replace("Reactive", "Reactive-like"), "Gene group": grp,
                            "Gene": g, "% nuclei expressing": round(100 * (SM[m, j] > 0).mean(), 2),
                            "Mean expression (log-normalized)": round(smean[i, j], 4),
                            "Scaled mean (0–1 across states)": round(sscaled[i, j], 4)})
sub_dot = pd.DataFrame(sub_dot)
smk = pd.read_csv(TAB / "astro_substate_markers.csv")
sub_markers = pd.DataFrame({"Astrocyte state": smk["substate"].replace({"Reactive": "Reactive-like"}),
                            "Gene": smk["names"], "Wilcoxon z": smk["scores"].round(4),
                            "log2FC (state vs other astrocytes)": smk["logfoldchanges"].round(4),
                            "P value": smk["pvals"], "Adjusted P (BH)": smk["pvals_adj"]})

# --- full SNI vs Sham DE in astrocytes (same call as scil_astrocyte_deepdive.py)
print("astrocyte DE ...")
aa = a.copy()
aa.obs["condition"] = aa.obs["condition"].astype(str).astype("category")
vl = aa.var_names.str.lower()
tech = np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl"))) | np.asarray(vl.str.match(r"^hb[ab]"))
aa = aa[:, ~(np.asarray(aa.var_names.isin(set(UBIQUITOUS))) | tech)].copy()
sc.tl.rank_genes_groups(aa, "condition", groups=["sni"], reference="sham", method="wilcoxon",
                        use_raw=False, pts=True, n_genes=aa.n_vars)
de = sc.get.rank_genes_groups_df(aa, group="sni").sort_values("pvals_adj")
old = pd.read_csv(TAB / "astro_de_sni_vs_sham_deepdive.csv").set_index("names")
assert np.allclose(de.set_index("names").loc[old.index, "scores"], old["scores"], atol=1e-4), "DE does not reproduce"
X = aa.X.tocsc() if sparse.issparse(aa.X) else sparse.csc_matrix(aa.X)
def grp_stats(mask):
    S = X[mask]
    return (pd.Series(np.asarray(S.mean(0)).ravel(), index=aa.var_names),
            pd.Series(100 * np.asarray((S > 0).mean(0)).ravel(), index=aa.var_names))
m_sh, p_sh = grp_stats(aa.obs["condition"].values == "sham")
m_sn, p_sn = grp_stats(aa.obs["condition"].values == "sni")
mods = pd.read_csv(TAB / "astro_wgcna_gene_modules.csv").set_index("gene")["module"]
g = de["names"]
DE = pd.DataFrame({"Gene": g.values,
                   "Mean expression Sham (log-normalized)": m_sh[g].round(4).values,
                   "Mean expression SNI (log-normalized)": m_sn[g].round(4).values,
                   "% nuclei expressing Sham": p_sh[g].round(2).values,
                   "% nuclei expressing SNI": p_sn[g].round(2).values,
                   "log2FC (SNI vs Sham)": de["logfoldchanges"].round(4).values,
                   "Wilcoxon z": de["scores"].round(4).values,
                   "P value": de["pvals"].values, "Adjusted P (BH)": de["pvals_adj"].values,
                   "Fig. 3H transporter": np.where(g.isin(TRANSPORTERS_3H), "yes", ""),
                   "Perisynaptic homeostatic program (Fig. S7D)": np.where(g.isin(HOMEOSTATIC16), "yes", ""),
                   "Slc6a11-associated program": np.where(g.isin(PROG), "yes", ""),
                   "WGCNA module": g.map(mods).fillna("").values})
# genes absent from one group have no finite fold change; genes absent from all astrocytes carry no data
z_sh, z_sn = DE["% nuclei expressing Sham"].eq(0), DE["% nuclei expressing SNI"].eq(0)
assert DE.loc[z_sh ^ z_sn, "Adjusted P (BH)"].min() > 0.05
N_ABSENT = int((z_sh & z_sn).sum())
DE["log2FC (SNI vs Sham)"] = DE["log2FC (SNI vs Sham)"].astype(object)
DE.loc[z_sh & ~z_sn, "log2FC (SNI vs Sham)"] = "NA (not detected in Sham)"
DE.loc[z_sn & ~z_sh, "log2FC (SNI vs Sham)"] = "NA (not detected in SNI)"
DE = DE[~(z_sh & z_sn)].reset_index(drop=True)
d = DE.set_index("Gene")
check("Slc6a11 log2FC", d.loc["Slc6a11", "log2FC (SNI vs Sham)"], -1.87, 0.005)
check("Slc6a11 % Sham", d.loc["Slc6a11", "% nuclei expressing Sham"], 64.62, 0.005)
check("Slc6a11 % SNI", d.loc["Slc6a11", "% nuclei expressing SNI"], 36.03, 0.005)
tr3h = DE[DE["Fig. 3H transporter"] == "yes"].set_index("Gene").loc[TRANSPORTERS_3H].reset_index()
tr3h = tr3h[["Gene", "% nuclei expressing Sham", "% nuclei expressing SNI", "log2FC (SNI vs Sham)",
             "Wilcoxon z", "P value", "Adjusted P (BH)"]]

# --- S7D predefined homeostatic program
s7d = []
for gg in HOMEOSTATIC16:
    v = col(a, gg)
    s7d.append({"Gene": gg, "Functional category": HOMEO_CAT[gg],
                "Mean expression Sham (log-normalized)": round(v[sh].mean(), 4),
                "Mean expression SNI (log-normalized)": round(v[sn].mean(), 4),
                "% nuclei expressing Sham": round(100 * (v[sh] > 0).mean(), 2),
                "% nuclei expressing SNI": round(100 * (v[sn] > 0).mean(), 2),
                "log2FC (SNI vs Sham)": round(log2fc(v[sn], v[sh]), 4)})
s7d = pd.DataFrame(s7d).sort_values("log2FC (SNI vs Sham)").reset_index(drop=True)
check("S7D genes lower in SNI", int((s7d["log2FC (SNI vs Sham)"] < 0).sum()), 14, 0)

# --- program & OXPHOS scores (Fig. 3I, 5B, S8C–D) — identical calls to scil_fig_featureplots.py
nuc_ox = sorted({gg for gg in a.var_names
                 if re.match(r"(Nduf|Uqcr|Atp5)", gg) or gg in {"Sdha", "Sdhb", "Sdhc", "Sdhd", "Cyc1"}
                 or re.match(r"Cox(4|5|6|7|8|10|11|15|17)", gg)} - {gg for gg in a.var_names if gg.startswith("mt-")})
prog = [gg for gg in PROG if gg in a.var_names]
sc.tl.score_genes(a, prog, score_name="prog", ctrl_size=50, use_raw=False)
sc.tl.score_genes(a, nuc_ox, score_name="oxphos", ctrl_size=50, use_raw=False)
score_rows = []
for nm_, key in [("Slc6a11-associated program score", "prog"), ("OXPHOS score (nuclear-encoded subunits)", "oxphos")]:
    v = a.obs[key].values
    p = mannwhitneyu(v[sh], v[sn]).pvalue
    for lab, m in [("All astrocytes", None)] + [(s, sub == s) for s in SUB_MAIN]:
        for gl, gm in [("Sham", sh), ("SNI", sn)]:
            mm = gm if m is None else (gm & m)
            ds = describe(v[mm])
            score_rows.append({"Score": nm_, "Astrocyte state": lab.replace("Reactive", "Reactive-like"),
                               "Group": gl, "Nuclei (n)": ds["n"], "Mean": round(ds["mean"], 4),
                               "SD": round(ds["sd"], 4), "Median": round(ds["median"], 4),
                               "Q1": round(ds["q1"], 4), "Q3": round(ds["q3"], 4),
                               "Mann–Whitney P (Sham vs SNI)": p if lab == "All astrocytes" and gl == "SNI" else None})
        if lab != "All astrocytes":  # within-state test
            vv = v[m]; cc = cond[m]
            score_rows[-1]["Mann–Whitney P (Sham vs SNI)"] = mannwhitneyu(vv[cc == "sham"], vv[cc == "sni"]).pvalue
scores = pd.DataFrame(score_rows)

au = a.obsm["X_umap"]
astro_nuc = pd.DataFrame({"Barcode": a.obs_names, "Group": [COND[c] for c in cond],
                          "Astrocyte state": pd.Series(sub).replace({"Reactive": "Reactive-like"}).values,
                          "Leiden cluster (astrocyte reclustering)": a.obs["leiden_sub"].astype(str).values,
                          "Astrocyte UMAP_1": au[:, 0].round(4), "Astrocyte UMAP_2": au[:, 1].round(4),
                          "Slc6a11 (log-normalized)": col(a, "Slc6a11").round(4),
                          "Slc6a11-associated program score": a.obs["prog"].values.round(4),
                          "OXPHOS score": a.obs["oxphos"].values.round(4)})
nuc["Astrocyte state (Fig. 3E)"] = nuc["Barcode"].map(astro_nuc.set_index("Barcode")["Astrocyte state"]).fillna("")

# --- OXPHOS subunits by complex (Fig. S8E)
og = pd.read_csv(TAB / "nrf1_axis_oxphos_genes.csv")
rk = pd.read_csv(TAB / "nrf1_axis_rank.csv").set_index("gene")
mt_ox = [gg for gg in rk.index if re.match(r"mt-(Nd|Co|Cyt|Atp)", gg)]
ox = pd.concat([og.assign(origin="Nuclear-encoded"),
                pd.DataFrame({"gene": mt_ox, "complex": "mtDNA-encoded", "log2FC": rk.loc[mt_ox, "log2FC"].values,
                              "origin": "Mitochondrial-encoded"})], ignore_index=True)
ox["complex"] = ox["complex"].str.replace(r" \(.*\)", "", regex=True)
ox["pct_sh"] = [100 * (col(a, gg)[sh] > 0).mean() for gg in ox["gene"]]
ox["pct_sn"] = [100 * (col(a, gg)[sn] > 0).mean() for gg in ox["gene"]]
ox["both"] = (ox["pct_sh"] > 0) & (ox["pct_sn"] > 0)
lfc_disp = ox["log2FC"].round(4).astype(object)
lfc_disp[ox["pct_sh"] == 0] = "NA (not detected in Sham)"
lfc_disp[ox["pct_sn"] == 0] = "NA (not detected in SNI)"
ox_genes = pd.DataFrame({"Gene": ox["gene"], "Respiratory complex": ox["complex"], "Genome": ox["origin"],
                         "% nuclei expressing Sham": ox["pct_sh"].round(2), "% nuclei expressing SNI": ox["pct_sn"].round(2),
                         "log2FC (SNI vs Sham)": lfc_disp})
ox_sum = []
for (cpx, org), x in ox.groupby(["complex", "origin"], sort=False):
    ox_sum.append({"Respiratory complex": cpx, "Genome": org, "Genes (n)": len(x),
                   "Median log2FC (Fig. S8E)": round(x["log2FC"].median(), 4),
                   "Genes detected in both groups (n)": int(x["both"].sum()),
                   "Mean log2FC (genes detected in both groups)": round(x.loc[x["both"], "log2FC"].mean(), 4),
                   "Fraction of genes lower in SNI": round((x["log2FC"] < 0).mean(), 3)})
ox_sum = pd.DataFrame(ox_sum)
for cpx, want in [("CI", -0.23), ("CII", -0.38), ("CIII", -0.26), ("CIV", -0.25), ("CV", -0.31)]:
    check(f"S8E median {cpx}", ox_sum.set_index("Respiratory complex").loc[cpx, "Median log2FC (Fig. S8E)"], want, 0.006)
check("S8E mtDNA mean", ox_sum.set_index("Respiratory complex").loc["mtDNA-encoded", "Mean log2FC (genes detected in both groups)"], 0.742, 0.001)
check("mtDNA-encoded genes", len(mt_ox), 13, 0)

# --- gene sets
genesets = pd.DataFrame([
    {"Gene set": "Predefined perisynaptic homeostatic program", "Genes (n)": len(HOMEOSTATIC16),
     "Genes": ", ".join(HOMEOSTATIC16), "Used in": "Fig. S7D"},
    {"Gene set": "Slc6a11-associated program", "Genes (n)": len(prog), "Genes": ", ".join(prog),
     "Used in": "Program score, Figs 3I, 5B, S8C; NRF1 targets, Figs 5E–F"},
    {"Gene set": "Nuclear-encoded OXPHOS subunits (OXPHOS score)", "Genes (n)": len(nuc_ox), "Genes": ", ".join(nuc_ox),
     "Used in": "OXPHOS score, Figs 5B, S8D"},
    {"Gene set": "Synapse-associated state markers", "Genes (n)": len(SYN_MARKERS), "Genes": ", ".join(SYN_MARKERS),
     "Used in": "Astrocyte state annotation (Figs 3E–G)"},
    {"Gene set": "Reactive-like state markers", "Genes (n)": len(REACT_MARKERS), "Genes": ", ".join(REACT_MARKERS),
     "Used in": "Astrocyte state annotation (Figs 3E–G)"},
    {"Gene set": "Astrocyte selection: astrocyte markers", "Genes (n)": 3, "Genes": "Slc1a3, Aqp4, Gja1",
     "Used in": "High-confidence astrocytic nuclei"},
    {"Gene set": "Astrocyte selection: non-astrocyte markers", "Genes (n)": 5,
     "Genes": "Snap25, Syt1 (neuronal); Plp1, Mbp (oligodendrocyte); Pdgfra (OPC)",
     "Used in": "High-confidence astrocytic nuclei"},
    {"Gene set": "Neurotransmitter transporters", "Genes (n)": len(TRANSPORTERS_3H), "Genes": ", ".join(TRANSPORTERS_3H),
     "Used in": "Fig. 3H"},
])

# ================================================================ Augur (Fig. 3C–D)
au1 = pd.read_csv(TAB / "augur_celltype_auc.csv"); au2 = pd.read_csv(TAB / "augur_decomposition.csv")
aug = au1.merge(au2[["celltype", "composition_auc", "intrinsic_auc", "n_matched_subtypes", "matched_coverage"]],
                on="celltype", how="left")
single = aug["n_matched_subtypes"] == 1
aug.loc[single & aug["composition_auc"].isna(), "composition_auc"] = 0.5
augur = pd.DataFrame({"Cell type": aug["celltype"].map(CT_DISP), "Sham (n)": aug["n_sham"], "SNI (n)": aug["n_sni"],
                      "Augur AUC (mean)": aug["mean_auc"].round(4), "Augur AUC (SD)": aug["std_auc"].round(4),
                      "AUC Q1": aug["auc_q25"].round(4), "AUC Q3": aug["auc_q75"].round(4),
                      "Label-permuted AUC (mean)": aug["mean_auc_perm"].round(4),
                      "Composition AUC": aug["composition_auc"].round(4),
                      "Cell-intrinsic AUC (within matched subtypes)": aug["intrinsic_auc"].round(4),
                      "Matched subtypes (n)": aug["n_matched_subtypes"].astype("Int64"),
                      "Fraction of nuclei in matched subtypes": aug["matched_coverage"],
                      "Shown in Fig. 3C–D": np.where(aug["n_sham"] + aug["n_sni"] >= 250, "yes", "no (n < 250)")})
ag = augur.set_index("Cell type")
check("Augur AUC astrocyte", ag.loc["Astrocyte", "Augur AUC (mean)"], 0.863, 0.0005)
check("Augur intrinsic AUC astrocyte", ag.loc["Astrocyte", "Cell-intrinsic AUC (within matched subtypes)"], 0.860, 0.0005)
wc = pd.read_csv(TAB / "augur_within_cluster_auc.csv")
wc["leiden"] = wc["leiden"].astype(int)
wc = wc.sort_values(["celltype", "leiden"])
augur_sub = pd.DataFrame({"Cell type": wc["celltype"].map(CT_DISP), "Leiden cluster (subtype)": wc["leiden"],
                          "Sham (n)": wc["n_sham"], "SNI (n)": wc["n_sni"],
                          "SNI fraction": (wc["n_sni"] / (wc["n_sham"] + wc["n_sni"])).round(4),
                          "Within-subtype AUC": wc["within_cluster_auc"].round(4),
                          "Matched subtype (≥40 nuclei per group)": np.where((wc["n_sham"] >= 40) & (wc["n_sni"] >= 40), "yes", "no")})

# ================================================================ WGCNA (Fig. S7E–G)
print("WGCNA ...")
Xm = pd.read_csv(TAB / "astro_metacell_expr.csv", index_col=0)
md = pd.read_csv(TAB / "astro_metacell_meta.csv", index_col=0).loc[Xm.index]
mods_df = pd.read_csv(TAB / "astro_wgcna_gene_modules.csv")
mt_ = pd.read_csv(TAB / "astro_wgcna_module_trait.csv")


def eigengene(genes):
    Z = Xm[genes]; Z = ((Z - Z.mean()) / Z.std(ddof=1)).fillna(0)
    u, s, _ = np.linalg.svd(Z.values, full_matrices=False); pc = u[:, 0] * s[0]
    return -pc if np.corrcoef(pc, Z.values.mean(1))[0, 1] < 0 else pc


slc = Xm["Slc6a11"].values; sni_ind = (md["condition"] == "sni").astype(int).values
MEs = {m: eigengene([gg for gg in mods_df.gene[mods_df.module == m] if gg in Xm.columns]) for m in mt_["module"]}
for m in mt_["module"]:
    r_, _ = pearsonr(MEs[m], slc)
    assert abs(r_ - mt_.set_index("module").loc[m, "cor_slc6a11"]) < 0.01, f"ME mismatch {m}"
tq = [gg for gg in mods_df.gene[mods_df.module == "turquoise"] if gg in Xm.columns]
me_no = eigengene([gg for gg in tq if gg != "Slc6a11"])
r1, p1 = pearsonr(me_no, slc); r2, p2 = pearsonr(me_no, sni_ind)
check("turquoise ME r(Slc6a11)", mt_.set_index("module").loc["turquoise", "cor_slc6a11"], 0.874, 0.0005)
check("turquoise ME r(SNI)", mt_.set_index("module").loc["turquoise", "cor_condition"], -0.589, 0.0005)
check("turquoise ME w/o Slc6a11 r(Slc6a11)", r1, 0.872, 0.0005)
check("turquoise ME w/o Slc6a11 r(SNI)", r2, -0.588, 0.0005)
wg_mod = pd.DataFrame({"Module": mt_["module"], "Genes (n)": mt_["size"],
                       "Eigengene r with Slc6a11": mt_["cor_slc6a11"].round(4), "P (Slc6a11)": mt_["p_slc6a11"],
                       "Eigengene r with SNI status": mt_["cor_condition"].round(4), "P (SNI status)": mt_["p_condition"]})
wg_mod.loc[len(wg_mod)] = ["turquoise, eigengene recomputed without Slc6a11", len(tq) - 1, round(r1, 4), p1, round(r2, 4), p2]
wg_mc = pd.DataFrame({"Metacell": Xm.index, "Group": md["condition"].map(COND).values,
                      "Nuclei (n)": md["n_cells"].values,
                      "Most frequent astrocyte state": md["substate_top"].replace({"Reactive": "Reactive-like"}).values,
                      "Slc6a11 (mean log-normalized)": md["Slc6a11"].round(4).values})
for m in mt_["module"]:
    if m != "grey":
        wg_mc[f"ME {m}"] = np.round(MEs[m], 4)
wg_mc["ME turquoise without Slc6a11"] = np.round(me_no, 4)
# kME of every network gene to its own module eigengene
Zall = Xm[mods_df.gene]
km = []
for gg, m in zip(mods_df.gene, mods_df.module):
    km.append(np.nan if m == "grey" else pearsonr(Zall[gg].values, MEs[m])[0])
mods_df["kME"] = km
kst = pd.read_csv(TAB / "astro_wgcna_slc6a11_module.csv").set_index("gene")["kME"]
assert np.allclose(mods_df.set_index("gene").loc[kst.index, "kME"], kst, atol=0.01), "kME mismatch"
mods_df["rank"] = mods_df.groupby("module")["kME"].rank(ascending=False).astype("Int64")
mods_df = mods_df.sort_values(["module", "rank"])
top20 = set(kst.sort_values(ascending=False).index[:20])
wg_genes = pd.DataFrame({"Gene": mods_df["gene"], "Module": mods_df["module"],
                         "Module membership (kME)": mods_df["kME"].round(4),
                         "Rank within module": mods_df["rank"],
                         "Fig. S7F hub gene": np.where(mods_df["gene"].isin(top20) & (mods_df["module"] == "turquoise"), "yes", "")})
check("Slc6a11 kME rank in turquoise", int(wg_genes.set_index("Gene").loc["Slc6a11", "Rank within module"]), 1, 0)

comp_en = pd.read_csv(TAB / "astro_wgcna_turquoise_comprehensive.csv")
comp_en["Fig. S7G label"] = ""
for key, disp in S7G_TERMS:
    h = comp_en[comp_en["Term"].str.contains(key, case=False, regex=False)].sort_values("Adjusted P-value")
    comp_en.loc[h.index[0], "Fig. S7G label"] = disp
comp_en = comp_en.sort_values("Adjusted P-value")
wg_en = pd.DataFrame({"Library": comp_en["Gene_set"], "Term": comp_en["Term"], "Overlap": comp_en["Overlap"],
                      "P value": comp_en["P-value"], "Adjusted P (BH)": comp_en["Adjusted P-value"],
                      "Odds ratio": comp_en["Odds Ratio"].round(3), "Combined score": comp_en["Combined Score"].round(3),
                      "Genes": comp_en["Genes"], "Fig. S7G label": comp_en["Fig. S7G label"]})

# ================================================================ GSEA (Fig. 5A, 5C)
kg = pd.read_csv(TAB / "nrf1_axis_kegg_full.csv").sort_values("nes")
kegg = pd.DataFrame({"KEGG 2019 Mouse term": kg["term"], "ES": kg["ES"].round(4), "NES": kg["nes"].round(4),
                     "Nominal P": kg["p"], "FDR q": kg["fdr"], "FWER P": kg["FWER p-val"],
                     "Leading-edge / set size": kg["Tag %"], "Leading-edge genes": kg["Lead_genes"],
                     "Shown in Fig. 5A": np.where(kg["term"].isin(KEGG_5A), "yes", ""),
                     "Shown in Fig. 5C": np.where(kg["term"] == "Oxidative phosphorylation", "yes", "")})
ko = kegg.set_index("KEGG 2019 Mouse term").loc["Oxidative phosphorylation"]
check("KEGG OXPHOS NES", ko["NES"], -1.57, 0.005); check("KEGG OXPHOS FDR", ko["FDR q"], 0.002, 0.0005)
print("Hallmark GSEA ...")
hall = {}
for line in open(GMT):
    p_ = line.rstrip("\n").split("\t"); hall[p_[0]] = [x for x in p_[2:] if x]
rnk = rk.reset_index()[["gene", "z"]].dropna()
rnk["gene"] = rnk["gene"].str.upper()
rnk = rnk.drop_duplicates("gene").sort_values("z", ascending=False).reset_index(drop=True)
pre = gp.prerank(rnk=rnk, gene_sets=hall, min_size=15, max_size=500, permutation_num=2000, seed=7,
                 no_plot=True, outdir=None, threads=8)
hr = pre.res2d.copy()
for c_ in ["ES", "NES", "NOM p-val", "FDR q-val", "FWER p-val"]:
    hr[c_] = hr[c_].astype(float)
hr = hr.sort_values("NES")
hallmark = pd.DataFrame({"MSigDB Hallmark 2020 term": hr["Term"], "ES": hr["ES"].round(4), "NES": hr["NES"].round(4),
                         "Nominal P": hr["NOM p-val"], "FDR q": hr["FDR q-val"], "FWER P": hr["FWER p-val"],
                         "Leading-edge / set size": hr["Tag %"], "Leading-edge genes": hr["Lead_genes"]})
ho = hallmark.set_index("MSigDB Hallmark 2020 term").loc["Oxidative Phosphorylation"]
check("Hallmark OXPHOS NES", ho["NES"], -1.49, 0.005); check("Hallmark OXPHOS FDR", ho["FDR q"], 0.005, 0.0006)

# ================================================================ TF analyses (Fig. 5D–G)
cr = pd.read_csv(TAB / "slc6a11_candidate_regulators.csv")
check("TFs screened", len(cr), 217, 0)
hl = (cr["frac_of_max"] >= 0.7) & (cr["motif_z_vs_bg"] >= 1.5) & (cr["log2FC_sni"] < -0.15)
tfscreen = pd.DataFrame({"Transcription factor": cr["TF"], "JASPAR motif": cr["jaspar"],
                         "Best motif match score in Slc6a11": cr["slc6a11_motif_score"],
                         "Motif z-score vs background genes": cr["motif_z_vs_bg"],
                         "Match score / maximal score": cr["frac_of_max"],
                         "% astrocytic nuclei expressing": cr["pct"],
                         "Mean expression Sham": cr["mean_sham"], "Mean expression SNI": cr["mean_sni"],
                         "Own log2FC (SNI vs Sham)": cr["log2FC_sni"],
                         "Highlighted in Fig. 5D": np.where(hl, "yes", "")}).sort_values("Motif z-score vs background genes", ascending=False)
tfa = pd.read_csv(TAB / "astro_tf_sham_vs_sni.csv").set_index("TF")
cmpx = pd.read_csv(TAB / "slc6a11_tf_comparison.csv").set_index("TF").loc[TF_5E]
pos = pd.read_csv(TAB / "slc6a11_tf_site_positions.csv").set_index("TF").loc[TF_5E]
tf5e = pd.DataFrame({"Transcription factor": TF_5E, "Motif z-score": cmpx["motif_z"].values,
                     "Match score / maximal score": cmpx["motif_frac"].values,
                     "Own log2FC (SNI vs Sham)": cmpx["own_log2FC"].values,
                     "Δ inferred regulon activity (SNI − Sham)": cmpx["activity_delta"].round(4).values,
                     "Adjusted P, regulon activity (BH)": tfa.loc[TF_5E, "padj"].values,
                     "Mean log2FC of CollecTRI targets": cmpx["target_mean_log2FC"].values,
                     "CollecTRI targets in Slc6a11-associated program (n)": cmpx["n_program_targets"].values,
                     "Best motif position (bp from TSS)": pos["best_pos"].values,
                     "Best motif strand": pos["strand"].values})
nt = pd.read_csv(TAB / "nrf1_program_targets_mrna.csv")
nt = nt.set_index("gene").loc[["Nrf1", "Grin3a", "Slc25a5", "Gria2", "Atp1b1"]].reset_index()
tf5f = pd.DataFrame({"Gene": nt["gene"], "Role": ["Transcription factor"] + ["NRF1 target (CollecTRI) in Slc6a11-associated program"] * 4,
                     "% nuclei expressing Sham": nt["pct_sham"], "% nuclei expressing SNI": nt["pct_sni"],
                     "log2FC (SNI vs Sham)": nt["log2FC"].round(4), "Mann–Whitney P": nt["mwu_p"]})
pg = pd.read_csv(TAB / "nrf1_axis_pgc1a_mrna.csv").set_index("gene").loc["Ppargc1a"]
tf5g = [{"Regulator": "PGC-1α (Ppargc1a)", "Readout": "mRNA (log-normalized)", "Sham": None, "SNI": None,
         "% nuclei expressing Sham": pg["pct_sham"], "% nuclei expressing SNI": pg["pct_sni"],
         "Change (log2FC or Δ activity)": pg["log2FC"], "P (Mann–Whitney)": pg["mwu_p"], "Adjusted P (BH)": None}]
for tf, lab in RESP_TF_5G:
    r_ = tfa.loc[tf]
    tf5g.append({"Regulator": lab, "Readout": "Inferred regulon activity (decoupleR ULM, CollecTRI)",
                 "Sham": round(r_["mean_sham"], 4), "SNI": round(r_["mean_sni"], 4),
                 "% nuclei expressing Sham": None, "% nuclei expressing SNI": None,
                 "Change (log2FC or Δ activity)": round(r_["delta_sni"], 4), "P (Mann–Whitney)": r_["mwu_p"],
                 "Adjusted P (BH)": r_["padj"]})
tf5g = pd.DataFrame(tf5g)
tfall = tfa.reset_index().sort_values("padj")
tf_activity = pd.DataFrame({"Transcription factor": tfall["TF"], "Mean activity Sham": tfall["mean_sham"].round(4),
                            "Mean activity SNI": tfall["mean_sni"].round(4),
                            "Δ activity (SNI − Sham)": tfall["delta_sni"].round(4),
                            "Mann–Whitney P": tfall["mwu_p"], "Adjusted P (BH)": tfall["padj"]})

# ================================================================ NRF1 motif & ChIP (Fig. S8F–H)
site = pd.read_csv(TAB / "slc6a11_nrf1_sites.csv").iloc[0]
motif = pd.DataFrame([
    {"Species": "Mouse", "Gene": "Slc6a11", "Assembly": "mm10", "Transcript": "ENSMUST00000032451",
     "TSS": "chr6:114,131,239", "Exon 1": "chr6:114,131,239–114,131,517 (279 bp)",
     "NRF1 motif": "chr6:114,131,644–114,131,658", "Position (bp from TSS)": "+412", "Location": "Intron 1",
     "Strand": site["strand"], "Matched sequence": site["seq"], "Motif score (JASPAR MA0506.2)": site["score"]},
    {"Species": "Human", "Gene": "SLC6A11", "Assembly": "hg38", "Transcript": "ENST00000454147",
     "TSS": "chr3:10,816,201", "Exon 1": "chr3:10,816,201–10,816,521", "NRF1 motif": "chr3:10,816,603–10,816,617",
     "Position (bp from TSS)": "+409", "Location": "Intron 1", "Strand": "+",
     "Matched sequence": "TCCCGCGCCTGCGTG", "Motif score (JASPAR MA0506.2)": None}])
pfm = pd.read_csv(TAB / "nrf1_pfm.csv"); pfm.insert(0, "Position", range(1, len(pfm) + 1))
pfm[["A", "C", "G", "T"]] = pfm[["A", "C", "G", "T"]].astype(int)
cm = pd.read_csv(TAB / "slc6a11_nrf1_chip_evidence.csv")
chip_m = pd.DataFrame({"Chromosome": cm["chrom"], "Peak start (mm10)": cm["peak_start_mm10"], "Peak end (mm10)": cm["peak_end_mm10"],
                       "MACS2 score": cm["macs2_score"], "Covers NRF1 motif": np.where(cm["covers_motif"] == 1, "yes", "no"),
                       "Experiment (SRX)": cm["SRX"], "Antigen @ cell type": cm["cell"], "Sample": cm["sample"],
                       "Source": "ChIP-Atlas"})
ch = pd.read_csv(TAB / "slc6a11_nrf1_chip_evidence_human.csv")
chip_h = pd.DataFrame({"Chromosome": ch["chrom"], "Peak start (hg38)": ch["peak_start_hg38"], "Peak end (hg38)": ch["peak_end_hg38"],
                       "MACS2 score": ch["macs2_score"], "Covers NRF1 motif": np.where(ch["covers_motif"] == 1, "yes", "no"),
                       "Experiment (SRX)": ch["SRX"], "Antigen @ cell type": ch["cell"], "Sample": ch["sample"],
                       "Source": np.where(ch["sample"].str.contains("ENC|Stanford", regex=True), "ENCODE (via ChIP-Atlas)", "ChIP-Atlas")})

# ================================================================ assemble sheets
SAMPLE = ("IL tissue from three mice per group was pooled into one library per group (one Sham and one SNI library); "
          "nuclei are the units of the per-nucleus statistics.")
add("1_QC", "Quality control of the Sham and SNI single-nucleus libraries",
    ["Related: STAR Methods (Single-nucleus RNA sequencing). " + SAMPLE], qc)
add("2_Nuclei", "Per-nucleus metadata for all 23,909 nuclei",
    ["Related: Figs 3A–B, S7A–C. UMAP = Harmony-integrated embedding of all nuclei (Fig. 3A).",
     "Astrocyte state and excitatory subtype are given for nuclei included in those sub-analyses."], nuc)
add("3_CellTypes", "Major cell-type composition (Fig. 3A)",
    ["The doublet-enriched cluster (66 Sham nuclei) is not displayed in Figs 3A–B."], comp)
add("4_CellTypeMarkers", "Canonical marker expression across major cell types (Fig. 3B)",
    ["% nuclei expressing = fraction of nuclei with non-zero expression; scaled mean = min–max scaled per gene across cell types (dot colour in Fig. 3B)."], dot)
add("5_Augur", "Cell-type prioritization, Sham vs SNI (Fig. 3C–D)",
    ["Augur (scikit-learn random forest, 100 trees; 2,000 HVGs; 50 balanced subsamples of 40 nuclei per group; 3-fold CV). Fig. 3C shows mean ± SD.",
     "Composition AUC uses the SNI fraction of each nucleus's subtype as classifier score (0.5 for cell types with a single subtype); "
     "cell-intrinsic AUC = nucleus-weighted mean of within-subtype AUCs (subtypes with ≥40 nuclei per group; Fig. 3D).",
     "VLMC/Fibroblast (182 nuclei) was not displayed; Pericyte/VSMC and Ependymal had too few nuclei for the 40-per-group subsampling."],
    ("A. Cell-type AUCs", augur), ("B. Within-subtype AUCs (Leiden clusters of the whole dataset)", augur_sub))
add("6_AstroStates", "Astrocyte states and their composition (Figs 3E–G, S8A–B)",
    ["1,821 high-confidence astrocytic nuclei reclustered (Leiden resolution 0.3); clusters annotated as synapse-associated or reactive-like when the corresponding "
     "marker score exceeded 0.6 and exceeded the alternative score by more than 0.3, homeostatic otherwise; clusters with < 50 nuclei = low quality."],
    ("A. State composition (Fig. 3G)", subcomp), ("B. Cluster-level annotation scores", naming))
add("7_AstroStateMarkers", "Astrocyte state marker genes (Fig. 3F)",
    ["Scaled mean = min–max scaled per gene across the three states (dot colour in Fig. 3F)."],
    ("A. Dot-plot values (Fig. 3F)", sub_dot),
    ("B. De novo marker genes per state (Wilcoxon, state vs all other astrocytes; top 25)", sub_markers))
add("8_AstroDE", "Differential expression, SNI vs Sham astrocytic nuclei (all genes)",
    ["Related: Figs 3H, S7D and all astrocyte gene-level statements. Wilcoxon rank-sum test with Benjamini–Hochberg correction (Scanpy).",
     "log2FC = log2 ratio of the expm1-transformed mean log-normalized expression (SNI / Sham). Mitochondrial, ribosomal and hemoglobin genes "
     "and a small set of ubiquitous transcripts (Malat1, Xist, Kcnq1ot1, Gm lncRNAs) were not tested.",
     "Sorted by adjusted P. Flag columns mark the genes shown in individual figure panels. log2FC is not given for genes detected in only one group; "
     f"genes not detected in any astrocytic nucleus (n = {N_ABSENT:,}) are omitted."],
    ("A. Neurotransmitter transporters (Fig. 3H)", tr3h), ("B. All tested genes", DE))
add("9_HomeostaticProgram", "Predefined 16-gene perisynaptic homeostatic program (Fig. S7D)",
    ["Genes ordered by log2FC as in Fig. S7D. Gene-level Wilcoxon statistics are in sheet 8_AstroDE."], s7d)
add("10_ProgramScores", "Slc6a11-associated program and OXPHOS scores (Figs 3I, 5B, S8C–D)",
    ["Per-nucleus scores calculated with Scanpy score_genes (50 control genes per gene). Gene lists in sheet 11_GeneSets; per-nucleus values in sheet 12_AstroNuclei.",
     "Mann–Whitney P compares Sham and SNI nuclei (all astrocytes, or within each state)."], scores)
add("11_GeneSets", "Gene sets used in the astrocyte analyses", [], genesets)
add("12_AstroNuclei", "Per-nucleus astrocyte data (Figs 3E, 3I, 5B, S8A–D)",
    ["UMAP = astrocyte-only embedding (Figs 3E, 5B, S8A–D)."], astro_nuc)
add("13_ExcitatorySubtypes", "Excitatory neuron subtypes (Fig. S7A–C)",
    ["7,291 excitatory nuclei after removal of a 29-nucleus microglia-doublet cluster. Z-scored mean = dot colour in Fig. S7C."],
    ("A. Subtype composition (Figs S7A–B)", exn_counts), ("B. Marker dot-plot values (Fig. S7C)", exn_dot))
add("14_WGCNA_Modules", "WGCNA modules of astrocytic metacells (Fig. S7E)",
    ["101 metacells (~15 nuclei each) generated within each group; signed network, soft-threshold power 9, 5,000 genes. "
     "Pearson correlation of module eigengenes with metacell Slc6a11 expression and SNI status (Sham = 0, SNI = 1); grey = unassigned genes."],
    ("A. Module–trait correlations", wg_mod), ("B. Metacell eigengenes", wg_mc))
add("15_WGCNA_Genes", "WGCNA gene module assignment and module membership (Fig. S7F)",
    ["kME = Pearson correlation between a gene's metacell expression and its module eigengene. Fig. S7F shows the top 20 genes of the Slc6a11-containing (turquoise) module."],
    wg_genes)
add("16_WGCNA_Enrichment", "Functional enrichment of the Slc6a11-containing module (Fig. S7G)",
    ["Enrichr over-representation analysis of the 446 turquoise-module genes (GO Biological Process / Molecular Function / Cellular Component 2021, "
     "KEGG 2019 Mouse, Reactome 2022, WikiPathways 2019 Mouse, MSigDB Hallmark 2020); terms with adjusted P < 0.1, sorted by adjusted P."],
    wg_en)
add("17_GSEA_KEGG", "GSEA of SNI vs Sham astrocytes, KEGG 2019 Mouse (Figs 5A, 5C)",
    ["GSEApy prerank; genes ranked by the Wilcoxon statistic (SNI vs Sham, all genes); 2,000 permutations. Negative NES = lower in SNI."], kegg)
add("18_GSEA_Hallmark", "GSEA of SNI vs Sham astrocytes, MSigDB Hallmark 2020",
    ["Same ranking as sheet 17 (gene symbols upper-cased for the human-symbol library); 2,000 permutations; gene-set size 15–500."], hallmark)
add("19_TF_MotifScreen", "Slc6a11 promoter-proximal motif screen of 217 astrocyte-expressed transcription factors (Fig. 5D)",
    ["JASPAR 2022 CORE vertebrate motifs scanned over −2,500 to +500 bp of the Slc6a11 TSS; z-score relative to 13 astrocyte-expressed background genes (Aqp4, Gja1, Glul, Slc1a3, Apoe, Sparcl1, Gfap, Atp1a2, Fth1, Clu, Ntsr2, Mt1, Slc7a10); "
     "factors detected in ≥5% of astrocytic nuclei.",
     "Highlighted: match score ≥ 70% of maximum, motif z ≥ 1.5 and own log2FC < −0.15."], tfscreen)
add("20_TF_Candidates", "Evidence matrix for candidate Slc6a11 regulators (Fig. 5E)",
    ["Regulon activity inferred per nucleus with decoupleR (ULM, mouse CollecTRI); Mann–Whitney with BH correction (full list in sheet 23_TF_Activity)."], tf5e)
add("21_NRF1_Targets", "Nrf1 and its targets within the Slc6a11-associated program (Fig. 5F)", [], tf5f)
add("22_PGC1a_Regulators", "PGC-1α expression and inferred activity of PGC-1α-associated transcription factors (Fig. 5G)",
    ["PGC-1α (Ppargc1a) has no CollecTRI regulon and is assessed at the mRNA level."], tf5g)
add("23_TF_Activity", "Inferred transcription-factor activity, SNI vs Sham astrocytes (all CollecTRI regulons)",
    ["decoupleR v2.1.6 univariate linear model over the mouse CollecTRI network; per-nucleus activities compared with Mann–Whitney tests and BH correction."],
    tf_activity)
add("24_OXPHOS_Subunits", "Respiratory-chain subunit expression changes by complex (Fig. S8E)",
    ["log2FC, SNI vs Sham astrocytic nuclei. Nuclear-encoded subunits form the OXPHOS score; mtDNA-encoded subunits are listed separately (grey row in Fig. S8E)."],
    ("A. Summary by complex", ox_sum), ("B. Individual genes", ox_genes))
add("25_NRF1_Motif_ChIP", "NRF1 motif in Slc6a11 / SLC6A11 intron 1 and public NRF1 ChIP-seq peaks (Fig. S8F–H)", [],
    ("A. NRF1 motif matches (Fig. S8F)", motif), ("B. JASPAR MA0506.2 position frequency matrix", pfm),
    ("C. Mouse NRF1 ChIP-seq peaks at the Slc6a11 locus (Fig. S8G)", chip_m),
    ("D. Human NRF1 ChIP-seq peaks at the SLC6A11 locus (Fig. S8H)", chip_h))

bad = [c for c in CHECKS if not c[3]]
if bad:
    sys.exit(f"manuscript checks failed: {bad}")


# ================================================================ write workbook
def is_p(name):
    n = name.lower()
    return n.startswith("p ") or n in {"p value", "nominal p", "fdr q", "fwer p", "mann–whitney p"} or "adjusted p" in n \
        or n.startswith("p (") or "mann–whitney p" in n


print("writing", OUT)
with pd.ExcelWriter(OUT, engine="xlsxwriter") as xw:
    wb = xw.book
    wb.formats[0].set_font_name("Arial"); wb.formats[0].set_font_size(10)
    f_title = wb.add_format({"bold": True, "font_name": "Arial", "font_size": 12})
    f_note = wb.add_format({"italic": True, "font_name": "Arial", "font_size": 9, "font_color": "#444444"})
    f_sub = wb.add_format({"bold": True, "font_name": "Arial", "font_size": 10, "font_color": "#1F3864"})
    f_head = wb.add_format({"bold": True, "font_name": "Arial", "font_size": 10, "bg_color": "#E7ECF3",
                            "bottom": 1, "text_wrap": True, "valign": "top"})
    f_p = wb.add_format({"font_name": "Arial", "font_size": 10, "num_format": "0.00E+00"})
    f_txt = wb.add_format({"font_name": "Arial", "font_size": 10})
    f_bold = wb.add_format({"bold": True, "font_name": "Arial", "font_size": 10})

    # README
    ws = wb.add_worksheet("README")
    ws.write(0, 0, "Supplementary Table — single-nucleus RNA-seq data (IL, Sham vs SNI, postoperative day 28)", f_title)
    readme = [
        "Data underlying the single-nucleus RNA-seq analyses in Figures 3A–3I, 5A–5G, S7A–S7G and S8A–S8H.",
        SAMPLE,
        "Pipeline: Cell Ranger (mm10, intronic reads included) → Scanpy 1.12 QC, Scrublet, normalization (10,000 counts, log1p), Harmony, Leiden; "
        "astrocyte reclustering; Wilcoxon DE; GSEApy 1.1.12; WGCNA 1.74; decoupleR 2.1.6; JASPAR 2022 / Biopython 1.85.",
        "Expression values are log-normalized unless stated otherwise. log2FC is SNI relative to Sham. P values are per-nucleus tests unless stated otherwise.",
    ]
    for i, t in enumerate(readme):
        ws.write(2 + i, 0, t, f_txt)
    r0 = 3 + len(readme)
    ws.write(r0, 0, "Sheet", f_head); ws.write(r0, 1, "Content", f_head)
    for i, (sheet, title, _, _) in enumerate(SHEETS):
        ws.write_url(r0 + 1 + i, 0, f"internal:'{sheet}'!A1", string=sheet)
        ws.write(r0 + 1 + i, 1, title, f_txt)
    ws.set_column(0, 0, 24); ws.set_column(1, 1, 120)

    for sheet, title, notes, blocks in SHEETS:
        ws = wb.add_worksheet(sheet)
        ws.write(0, 0, title, f_title)
        r = 1
        for n_ in notes:
            ws.write(r, 0, n_, f_note); r += 1
        r += 1
        widths = {}
        first_header = None
        for subtitle, df in blocks:
            if subtitle:
                ws.write(r, 0, subtitle, f_sub); r += 1
            for j, c in enumerate(df.columns):
                ws.write(r, j, c, f_head)
                widths[j] = max(widths.get(j, 8), min(len(str(c)), 28))
            if first_header is None:
                first_header = r
            for j, c in enumerate(df.columns):
                vals = df[c].tolist()
                fmt = f_p if is_p(c) else None
                for i, v in enumerate(vals):
                    if v is None or (isinstance(v, float) and np.isnan(v)) or v is pd.NA:
                        continue
                    if isinstance(v, (np.integer,)):
                        v = int(v)
                    elif isinstance(v, (np.floating,)):
                        v = float(v)
                    if fmt is not None and isinstance(v, float):
                        ws.write_number(r + 1 + i, j, v, fmt)
                    else:
                        ws.write(r + 1 + i, j, v)
                sample_len = max([len(str(x)) for x in vals[:300]] + [0])
                widths[j] = max(widths[j], min(sample_len + 2, 60))
            r += len(df) + 2
        for j, w in widths.items():
            ws.set_column(j, j, w)
        if len(blocks) == 1:
            ws.freeze_panes(first_header + 1, 0)

print(f"\n{len(CHECKS)} manuscript checks passed; {len(SHEETS)} data sheets written to {OUT}")
