#!/usr/bin/env python3
"""Single-cell feature plots on the astrocyte UMAP: key genes + program/pathway scores,
plus a sham-vs-SNI split that shows the spatial collapse of the Slc6a11 program / OXPHOS."""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
import numpy as np
import scanpy as sc
from scipy import sparse
import re
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.0})
OUT = Path("results/scil_reanalysis/figures/pub")
TEAL, RED, BLUE, GREY = "#2E8B8B", "#B64342", "#4C72A8", "#9AA0A6"
EXPR_CMAP = LinearSegmentedColormap.from_list("expr", ["#E9E9E9", "#FED976", "#FD8D3C", "#BD0026"])
SUB_COL = {"Homeostatic": "#9AA0A6", "Synapse-associated": "#2E8B8B",
           "Reactive": "#B64342", "Low-quality": "#D9D9D9"}
COND_COL = {"sham": "#4C72A8", "sni": "#B64342"}
PROG = ["Slc6a11", "Slc6a1", "Atp1b1", "Atp1a2", "Atp1b2", "Gria1", "Gria2", "Gria3", "Gria4",
        "Grin2b", "Grin3a", "Kcnj10", "Slc4a4", "Slc25a18", "Slc25a5", "Car10"]


def vec(a, g):
    v = a[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def feat(ax, xy, vals, title, cmap=EXPR_CMAP, vmin=None, vmax=None, cbar=True, italic=False):
    o = np.argsort(vals)  # low first so high-expressing cells plot on top
    vmin = float(np.min(vals)) if vmin is None else vmin
    vmax = float(np.percentile(vals, 99.5)) if vmax is None else vmax
    sca = ax.scatter(xy[o, 0], xy[o, 1], c=vals[o], cmap=cmap, vmin=vmin, vmax=vmax,
                     s=3.2, linewidths=0, rasterized=True)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title(title, fontsize=7.6, style="italic" if italic else "normal", pad=1)
    if cbar:
        cax = ax.inset_axes([0.78, 0.02, 0.04, 0.30])
        cb = ax.figure.colorbar(sca, cax=cax)
        cb.set_ticks([vmin, vmax]); cb.set_ticklabels(["0" if vmin == 0 else f"{vmin:.1f}", f"{vmax:.1f}"])
        cb.ax.tick_params(labelsize=4.6, length=1.5); cb.outline.set_linewidth(0.4)


def feat_cat(ax, xy, labels, colmap, title, legend=True):
    for lab, col in colmap.items():
        m = labels == lab
        ax.scatter(xy[m, 0], xy[m, 1], c=col, s=3.2, linewidths=0, rasterized=True, label=lab)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title(title, fontsize=7.6, pad=1)
    if legend:
        ax.legend(loc="lower left", frameon=False, fontsize=4.8, handletextpad=0.1,
                  markerscale=1.4, borderpad=0.1, labelspacing=0.18)


def main():
    a = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    xy = a.obsm["X_umap"]
    cond = a.obs["condition"].astype(str).values
    sub = a.obs["substate"].astype(str).values
    prog = [g for g in PROG if g in a.var_names]
    nuc_ox = sorted({g for g in a.var_names
                     if re.match(r"(Nduf|Uqcr|Atp5)", g) or g in {"Sdha", "Sdhb", "Sdhc", "Sdhd", "Cyc1"}
                     or re.match(r"Cox(4|5|6|7|8|10|11|15|17)", g)} - {g for g in a.var_names if g.startswith("mt-")})
    sc.tl.score_genes(a, prog, score_name="prog", ctrl_size=50, use_raw=False)
    sc.tl.score_genes(a, nuc_ox, score_name="oxphos", ctrl_size=50, use_raw=False)
    progv = a.obs["prog"].values; oxv = a.obs["oxphos"].values

    # ---------- Figure 1: feature-plot grid ----------
    GENES = ["Slc6a11", "Slc6a1", "Kcnj10", "Slc4a4", "Atp1b1", "Gria2", "Nrf1", "Ppargc1a"]
    fig = plt.figure(figsize=(9.2, 7.0))
    gs = fig.add_gridspec(3, 4, hspace=0.22, wspace=0.06, left=0.02, right=0.98, top=0.93, bottom=0.02)
    feat_cat(fig.add_subplot(gs[0, 0]), xy, sub, SUB_COL, "Substate")
    feat_cat(fig.add_subplot(gs[0, 1]), xy, cond, COND_COL, "Condition")
    pv = max(abs(np.percentile(progv, 1)), abs(np.percentile(progv, 99)))
    ov = max(abs(np.percentile(oxv, 1)), abs(np.percentile(oxv, 99)))
    feat(fig.add_subplot(gs[0, 2]), xy, progv, "Slc6a11 program score", cmap="RdBu_r", vmin=-pv, vmax=pv)
    feat(fig.add_subplot(gs[0, 3]), xy, oxv, "OXPHOS score", cmap="RdBu_r", vmin=-ov, vmax=ov)
    for i, g in enumerate(GENES):
        ax = fig.add_subplot(gs[1 + i // 4, i % 4])
        feat(ax, xy, vec(a, g), g, vmin=0, italic=True)
    fig.suptitle("Astrocyte UMAP feature plots — perisynaptic transport program, NRF1 axis genes & scores",
                 fontsize=9.5, fontweight="bold", y=0.975)
    fig.text(0.5, 0.005, "1,821 PFC astrocyte nuclei; expression = log-normalized; scores = Scanpy score_genes (z-like). Exploratory, n=1/condition.",
             ha="center", fontsize=5.2, color="0.5")
    stem = OUT / "fig_astro_featureplots"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight", dpi=300)
    fig.savefig(f"{stem}.png", dpi=170, bbox_inches="tight")
    plt.close(fig); print("wrote", stem)

    # ---------- Figure 2: sham vs SNI split (shared scale per row) ----------
    rows = [("Slc6a11", vec(a, "Slc6a11"), EXPR_CMAP, 0, None, True),
            ("Slc6a11 program score", progv, "RdBu_r", -pv, pv, False),
            ("OXPHOS score", oxv, "RdBu_r", -ov, ov, False)]
    fig2 = plt.figure(figsize=(5.2, 7.2))
    gs2 = fig2.add_gridspec(3, 2, hspace=0.18, wspace=0.05, left=0.06, right=0.93, top=0.92, bottom=0.03)
    for r, (name, vals, cmap, vmn, vmx, ital) in enumerate(rows):
        vmax = float(np.percentile(vals, 99.5)) if vmx is None else vmx
        for c, cnd in enumerate(["sham", "sni"]):
            ax = fig2.add_subplot(gs2[r, c])
            ax.scatter(xy[:, 0], xy[:, 1], c="#ECECEC", s=2.4, linewidths=0, rasterized=True)
            m = cond == cnd
            o = np.argsort(vals[m])
            sca = ax.scatter(xy[m][o, 0], xy[m][o, 1], c=vals[m][o], cmap=cmap, vmin=vmn, vmax=vmax,
                             s=3.4, linewidths=0, rasterized=True)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect("equal")
            for s in ax.spines.values():
                s.set_visible(False)
            if r == 0:
                ax.set_title("Sham" if cnd == "sham" else "SNI", fontsize=8.5, fontweight="bold",
                             color=COND_COL[cnd], pad=2)
            if c == 0:
                ax.text(-0.06, 0.5, name, transform=ax.transAxes, rotation=90, va="center", ha="center",
                        fontsize=7.6, fontweight="bold", style="italic" if ital else "normal")
            if c == 1:
                cax = ax.inset_axes([1.04, 0.15, 0.045, 0.6])
                cb = fig2.colorbar(sca, cax=cax); cb.ax.tick_params(labelsize=4.8, length=1.5)
                cb.outline.set_linewidth(0.4)
    fig2.suptitle("Spatial collapse of the Slc6a11 program & OXPHOS in SNI", fontsize=9, fontweight="bold", y=0.965)
    fig2.text(0.5, 0.008, "Same astrocyte UMAP; grey = all cells, coloured = that condition (shared colour scale per row).",
              ha="center", fontsize=5.0, color="0.5")
    stem2 = OUT / "fig_astro_featureplots_split"
    for ext in ["svg", "pdf"]:
        fig2.savefig(f"{stem2}.{ext}", bbox_inches="tight", dpi=300)
    fig2.savefig(f"{stem2}.png", dpi=180, bbox_inches="tight")
    plt.close(fig2); print("wrote", stem2)


if __name__ == "__main__":
    main()
