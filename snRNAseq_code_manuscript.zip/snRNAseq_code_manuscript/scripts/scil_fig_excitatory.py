#!/usr/bin/env python3
"""Supplementary: excitatory-neuron subtypes (layer-resolved projection neurons + local-circuit /
near-projecting types). UMAP + marker dot plot. Exploratory, n=1 library/condition."""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8})
OUT = Path("results/scil_reanalysis/figures/pub")

# leiden(res0.5) -> subtype; cluster 2 = microglia doublet (dropped)
LABELS = {"0": "L5/6 IT (Erbb4+)", "1": "L6 CT", "3": "L5/6 NP", "4": "L2/3 IT", "5": "L2/3 IT",
          "6": "L5 ET/PT", "7": "L6 IT", "8": "L4/5 IT (Rorb+)", "9": "L5 ET/PT",
          "10": "L5/6 deep (Trpm3+)"}
ORDER = ["L2/3 IT", "L4/5 IT (Rorb+)", "L5 ET/PT", "L5/6 NP", "L5/6 IT (Erbb4+)",
         "L6 IT", "L6 CT", "L5/6 deep (Trpm3+)"]
COLORS = {"L2/3 IT": "#4C72A8", "L4/5 IT (Rorb+)": "#54A0A0", "L5 ET/PT": "#B64342",
          "L5/6 NP": "#E0A030", "L5/6 IT (Erbb4+)": "#8E6FB0", "L6 IT": "#6FA85B",
          "L6 CT": "#3a3a3a", "L5/6 deep (Trpm3+)": "#C97BA0"}
# local-circuit / near-projecting ("interneuron-like") excitatory subtypes
LOCAL = {"L4/5 IT (Rorb+)", "L5/6 NP", "L5/6 IT (Erbb4+)"}
DOT = {"Pan-exc": ["Slc17a7", "Satb2"], "L2/3": ["Cux2", "Rasgrf2", "Calb1"],
       "L4/5 IT": ["Rorb"], "L5 ET/PT": ["Fezf2", "Bcl11b", "Pcp4"], "NP": ["Tshz2", "Slc17a6"],
       "L6 IT": ["Sulf1", "Oprk1"], "L6 CT": ["Foxp2", "Tle4", "Zfpm2", "Syt6"],
       "Local/atyp.": ["Erbb4", "Trpm3"], "GABAergic\n(neg. ctrl)": ["Gad1", "Gad2"]}


def expr_mat(a, genes):
    X = a[:, genes].X
    return np.asarray(X.todense()) if sparse.issparse(X) else np.asarray(X)


def main():
    e = sc.read_h5ad("results/scil_reanalysis/objects/excitatory_subset.h5ad")
    e = e[e.obs["sub"].astype(str).isin(LABELS)].copy()
    e.obs["subtype"] = pd.Categorical(e.obs["sub"].astype(str).map(LABELS), categories=ORDER)
    xy = e.obsm["X_umap"]; st = e.obs["subtype"].values
    cond = e.obs["condition"].astype(str).values

    genes = [g for grp in DOT.values() for g in grp if g in e.var_names]
    M = expr_mat(e, genes)
    # dot plot stats per subtype
    pct = np.zeros((len(ORDER), len(genes))); mean = np.zeros_like(pct)
    for i, s in enumerate(ORDER):
        m = (st == s)
        pct[i] = (M[m] > 0).mean(0) * 100
        mean[i] = M[m].mean(0)
    z = (mean - mean.mean(0)) / (mean.std(0) + 1e-9)
    gad = {g: mean[:, genes.index(g)] for g in ["Gad1", "Gad2"] if g in genes}

    fig = plt.figure(figsize=(11.2, 8.6))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.05, 0.95], width_ratios=[1.0, 0.62],
                          hspace=0.30, wspace=0.16, left=0.06, right=0.985, top=0.93, bottom=0.30)

    # ---- a UMAP by subtype
    axu = fig.add_subplot(gs[0, 0])
    for s in ORDER:
        m = st == s
        axu.scatter(xy[m, 0], xy[m, 1], s=5, color=COLORS[s], linewidths=0, rasterized=True,
                    label=f"{s} (n={int(m.sum())})")
        axu.text(np.median(xy[m, 0]), np.median(xy[m, 1]), s.split(" (")[0], fontsize=6.2,
                 fontweight="bold", ha="center", va="center",
                 path_effects=None, color="white" if s == "L6 CT" else "black")
    axu.set_xticks([]); axu.set_yticks([]); axu.set_aspect("equal")
    for sp in axu.spines.values():
        sp.set_visible(False)
    axu.set_title("Excitatory-neuron subtypes (7,291 nuclei; layer-resolved)", fontsize=8.5, pad=3)
    leg = axu.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False, fontsize=6.0,
                     handletextpad=0.2, labelspacing=0.35, markerscale=1.6)
    for t, s in zip(leg.get_texts(), ORDER):
        if s in LOCAL:
            t.set_color("#7A4FA0"); t.set_fontstyle("italic")
    axu.text(1.02, 0.04, "italic = local-circuit / near-projecting\n(\"excitatory-interneuron-like\")",
             transform=axu.transAxes, fontsize=5.2, color="#7A4FA0", style="italic")

    # ---- b UMAP by condition
    axc = fig.add_subplot(gs[0, 1])
    for cnd, col in [("sham", "#4C72A8"), ("sni", "#B64342")]:
        m = cond == cnd
        axc.scatter(xy[m, 0], xy[m, 1], s=4, color=col, linewidths=0, rasterized=True,
                    label="Sham" if cnd == "sham" else "SNI", alpha=0.6)
    axc.set_xticks([]); axc.set_yticks([]); axc.set_aspect("equal")
    for sp in axc.spines.values():
        sp.set_visible(False)
    axc.set_title("Condition", fontsize=8.5, pad=3)
    axc.legend(loc="lower right", frameon=False, fontsize=6.5, markerscale=1.8, handletextpad=0.2)

    # ---- c dot plot (spans both columns)
    axd = fig.add_subplot(gs[1, :])
    ng = len(genes); ns = len(ORDER)
    xs = np.arange(ng)
    for i in range(ns):
        sizes = (pct[i] / 100) * 120 + 2
        axd.scatter(xs, np.full(ng, ns - 1 - i), s=sizes, c=z[i], cmap="Reds",
                    vmin=-0.5, vmax=2.0, edgecolor="0.5", linewidth=0.3, zorder=3)
    axd.set_xticks(xs); axd.set_xticklabels(genes, rotation=90, fontsize=6.4, style="italic")
    axd.set_yticks(range(ns)); axd.set_yticklabels(ORDER[::-1], fontsize=7.0)
    for t, s in zip(axd.get_yticklabels(), ORDER[::-1]):
        t.set_color(COLORS[s])
        if s in LOCAL:
            t.set_fontstyle("italic")
    axd.set_ylim(-0.7, ns - 0.3); axd.set_xlim(-0.7, ng - 0.3)
    for sp in ["top", "right"]:
        axd.spines[sp].set_visible(False)
    # marker group separators + labels
    gi = 0
    for grp, gl in DOT.items():
        gl = [g for g in gl if g in genes]
        if not gl:
            continue
        x0, x1 = gi - 0.5, gi + len(gl) - 0.5
        axd.axvspan(x0, x1, color="#F2F4F6" if (list(DOT).index(grp) % 2 == 0) else "white", zorder=0)
        axd.text((x0 + x1) / 2, ns - 0.2, grp, ha="center", va="bottom", fontsize=5.6, color="0.35")
        gi += len(gl)
    axd.set_title("Layer / projection-class markers across excitatory subtypes "
                  "(Gad1/Gad2 negative confirms glutamatergic identity)", fontsize=8.0, pad=14)
    # legends: dot size + color
    sl = [Line2D([0], [0], marker="o", color="w", markerfacecolor="0.5", markersize=np.sqrt(p / 100 * 120 + 2),
                 label=f"{p}%") for p in [20, 50, 80]]
    l1 = axd.legend(handles=sl, title="% expressing", loc="upper left", bbox_to_anchor=(1.005, 1.02),
                    frameon=False, fontsize=5.6, title_fontsize=6.0, labelspacing=0.9, handletextpad=0.3)
    axd.add_artist(l1)
    cax = axd.inset_axes([1.01, 0.05, 0.018, 0.32])
    sm = plt.cm.ScalarMappable(cmap="Reds", norm=plt.Normalize(-0.5, 2.0)); sm.set_array([])
    cb = fig.colorbar(sm, cax=cax); cb.set_label("z-scored\nmean expr", fontsize=5.6)
    cb.ax.tick_params(labelsize=5.2)

    fig.suptitle("Excitatory neurons of the PFC resolve into layer-specific projection and local-circuit subtypes",
                 fontsize=9.5, fontweight="bold", y=0.975)
    fig.text(0.5, 0.015, "snRNA-seq, mouse PFC; UMAP after Harmony (batch = library). A 29-cell microglia-doublet cluster was removed. "
             "No striatal medium-spiny-neuron contamination (Ppp1r1b/Drd1/Drd2 absent). Exploratory, n=1 library/condition.",
             ha="center", fontsize=5.2, color="0.5")

    stem = OUT / "figS_excitatory_subtypes"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight", dpi=300)
    fig.savefig(f"{stem}.png", dpi=170, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)
    print("Gad means per subtype (should be ~0):")
    for g, v in gad.items():
        print(" ", g, {s: round(float(x), 3) for s, x in zip(ORDER, v)})


if __name__ == "__main__":
    main()
