#!/usr/bin/env python3
"""Public NRF1 ChIP-seq peaks at the mouse Slc6a11 / human SLC6A11 promoter (Fig. S8G-H; Supplementary Table).

ChIP-Atlas assembled peak calls for NRF1 across all cell types (MACS2, q < 1e-5; files
Oth.ALL.05.Nrf1.AllCell.bed for mm10 and Oth.ALL.05.NRF1.AllCell.bed for hg38, ~180 MB each, downloaded
once into results/scil_reanalysis/chip_atlas/). Peaks overlapping a 5-kb window around the promoter are kept;
"covers_motif" = the NRF1 motif centre (mouse +412, human +409 from the TSS) lies inside the peak.
Outputs: tables/slc6a11_nrf1_chip_evidence.csv (mouse), tables/slc6a11_nrf1_chip_evidence_human.csv
"""
from __future__ import annotations
import urllib.parse
import urllib.request
from pathlib import Path
import pandas as pd

RES = Path("results/scil_reanalysis")
TAB, DL = RES / "tables", RES / "chip_atlas"
URL = "https://chip-atlas.dbcls.jp/data/{build}/assembled/Oth.ALL.05.{ag}.AllCell.bed"
LOCI = {
    "mouse": dict(build="mm10", ag="Nrf1", chrom="chr6", win=(114129000, 114134000), motif=(114131644, 114131658),
                  out="slc6a11_nrf1_chip_evidence.csv", sort="start"),
    "human": dict(build="hg38", ag="NRF1", chrom="chr3", win=(10814000, 10819000), motif=(10816603, 10816617),
                  out="slc6a11_nrf1_chip_evidence_human.csv", sort="score"),
}


def peaks(cfg):
    fn = DL / f"{cfg['build']}_Oth.ALL.05.{cfg['ag']}.AllCell.bed"
    if not fn.exists():
        DL.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(URL.format(**cfg), fn)
    lo, hi = cfg["win"]; mc = (cfg["motif"][0] + cfg["motif"][1]) // 2
    rows = []
    with open(fn) as f:
        next(f)                                                    # track line
        for line in f:
            if not line.startswith(cfg["chrom"] + "\t"):
                continue
            p = line.rstrip("\n").split("\t"); s, e = int(p[1]), int(p[2])
            if e < lo or s > hi:
                continue
            meta = dict(kv.split("=", 1) for kv in urllib.parse.unquote(p[3]).replace("<br>", "").split(";") if "=" in kv)
            rows.append({"chrom": p[0], "start": s, "end": e, "macs2_score": int(p[4]),
                         "covers_motif": int(s <= mc <= e), "SRX": meta.get("ID"), "cell": meta.get("Name"),
                         "sample": meta.get("Title", "").split(";")[0], "cell_group": meta.get("Cell group")})
    df = pd.DataFrame(rows)
    return df.sort_values("start" if cfg["sort"] == "start" else "macs2_score", ascending=cfg["sort"] == "start",
                          kind="mergesort").reset_index(drop=True)


def main():
    for sp, cfg in LOCI.items():
        df = peaks(cfg)
        b = cfg["build"]
        df = df.rename(columns={"start": f"peak_start_{b}", "end": f"peak_end_{b}"})
        cols = ["chrom", f"peak_start_{b}", f"peak_end_{b}", "macs2_score", "covers_motif", "SRX", "cell"]
        cols += ["sample", "cell_group"] if sp == "mouse" else ["cell_group", "sample"]
        df[cols].to_csv(TAB / cfg["out"], index=False)
        print(f"{sp}: {len(df)} peaks, {df.covers_motif.sum()} cover the NRF1 motif -> {cfg['out']}")


if __name__ == "__main__":
    main()
