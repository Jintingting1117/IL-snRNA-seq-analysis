#!/usr/bin/env python3
"""Revised Figure S7D: predefined astrocyte homeostatic gene set, Sham vs SNI astrocytic nuclei.

Replaces the earlier S7D, which plotted the data-informed 16-gene Slc6a11-associated signature
(Gria/Grin/Slc25a/Car10) while the STAR Methods listed a different, predefined gene set. This panel
plots exactly the 16 genes defined a priori in the Methods (GABA transport, K+ buffering, acid-base,
Na+/K+-ATPase, gap junctions, water, glutamate uptake/metabolism, Cl- homeostasis, S100b).

Right-hand columns: log2FC (SNI vs Sham; log2 of the ratio of expm1-transformed mean log-normalized
expression, as elsewhere in the paper) and % of nuclei with detectable expression (Sham -> SNI).
No nucleus-level P values are drawn: one pooled library per group, so nuclei are not independent
biological replicates (descriptive only).

Outputs: PDF/SVG and a 600-dpi PNG of the panel at final print size (2.23 x 1.90 in).
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy import sparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scil_panel_box import Panel
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 5.0, "axes.linewidth": 0.6,
                     "axes.spines.right": False, "axes.spines.top": False})

OBJ = "results/scil_reanalysis/objects/astrocytes_deepdive.h5ad"
OUT = Path("results/scil_reanalysis/figures/revision_1011"); OUT.mkdir(parents=True, exist_ok=True)
TAB = Path("results/scil_reanalysis/tables")
SHAM, SNI, RED, BLUE = "#4C72A8", "#B64342", "#B64342", "#4C72A8"
# STAR Methods, "16-gene perisynaptic homeostatic program" (predefined, function-based)
PREDEFINED = ["Slc6a11", "Slc6a1", "Kcnj10", "Slc4a4", "Atp1a2", "Atp1b2", "Gja1", "Aqp4", "Glul",
              "Slc1a2", "Slc1a3", "Kcnj16", "Clcn2", "Slc12a2", "S100b", "Gjb6"]
SLOT_PX = (490, 419)          # panel size in px at 220 dpi (2.23 x 1.90 in)
SLOT_DPI = 220


def expr(a, g):
    v = a[:, g].X
    return np.asarray(v.todense()).ravel() if sparse.issparse(v) else np.asarray(v).ravel()


def compute():
    """Per-gene stats (sorted by log2FC), long-format expression and per-group means."""
    a = sc.read_h5ad(OBJ)
    cond = a.obs["condition"].astype(str).values
    genes = [g for g in PREDEFINED if g in a.var_names]
    assert len(genes) == 16, genes
    rows = []
    for g in genes:
        v = expr(a, g); sh, sn = v[cond == "sham"], v[cond == "sni"]
        rows.append({"gene": g,
                     "log2FC": float(np.log2((np.expm1(sn.mean()) + 1e-9) / (np.expm1(sh.mean()) + 1e-9))),
                     "pct_sham": 100 * (sh > 0).mean(), "pct_sni": 100 * (sn > 0).mean(),
                     "mean_sham": float(sh.mean()), "mean_sni": float(sn.mean())})
    st = pd.DataFrame(rows).sort_values("log2FC").reset_index(drop=True)
    order = st.gene.tolist()
    long = pd.DataFrame([{"gene": g, "expr": val, "cond": "SNI" if c == "sni" else "Sham"}
                         for g in order for val, c in zip(expr(a, g), cond)])
    return st, long


def draw(fig, P, st, long, letter="D"):
    """Draw the panel into Panel box P (see scil_panel_box.Panel)."""
    from matplotlib.transforms import blended_transform_factory
    order = st.gene.tolist()
    ax = P.axes(0.185, 0.115, 0.50, 0.745)
    tr = blended_transform_factory(fig.transFigure, ax.transData)
    sns.violinplot(data=long, y="gene", x="expr", hue="cond", order=order, hue_order=["Sham", "SNI"],
                   split=True, cut=0, inner=None, density_norm="width", gap=0.06, linewidth=0.25,
                   bw_adjust=1.3, palette={"Sham": SHAM, "SNI": SNI}, ax=ax, legend=False)
    for coll in ax.collections:
        coll.set_alpha(0.85)
    for i, r in st.iterrows():
        ax.scatter([r.mean_sham], [i - 0.17], color="white", edgecolor=SHAM, s=3.5, lw=0.45, zorder=6)
        ax.scatter([r.mean_sni], [i + 0.17], color="white", edgecolor=SNI, s=3.5, lw=0.45, zorder=6)
    ax.set_xlabel("log-normalized expression", fontsize=5.0, labelpad=1.2)
    ax.set_ylabel("")
    ax.set_xlim(left=-0.15)
    ax.tick_params(axis="both", labelsize=5.0, length=2, width=0.5, pad=1.2)
    ax.set_ylim(len(order) - 0.45, -0.75)
    for i, r in st.iterrows():
        if r.gene == "Slc6a11":
            ax.axhspan(i - 0.5, i + 0.5, color="#FBE9D0", zorder=0)
        col = RED if r.log2FC <= -0.15 else BLUE if r.log2FC >= 0.15 else "0.5"
        ax.text(P.fx(0.70), i, f"{r.log2FC:+.2f}", va="center", ha="left", fontsize=4.8, color=col, transform=tr,
                fontweight="bold" if r.gene == "Slc6a11" else "normal", clip_on=False)
        ax.text(P.fx(0.835), i, f"{r.pct_sham:.0f}→{r.pct_sni:.0f}", va="center", ha="left", fontsize=4.6,
                color="0.35", transform=tr, clip_on=False)
    ax.text(P.fx(0.70), -0.95, "log2FC", fontsize=4.6, color="0.35", ha="left", va="bottom", transform=tr, clip_on=False)
    ax.text(P.fx(0.835), -0.95, "% nuclei", fontsize=4.6, color="0.35", ha="left", va="bottom", transform=tr, clip_on=False)
    for lab in ax.get_yticklabels():
        if lab.get_text() == "Slc6a11":
            lab.set_color(RED); lab.set_fontweight("bold")
    P.text(0.52, 0.985, "Perisynaptic homeostatic program", ha="center", va="top", fontsize=5.8, fontweight="bold")
    if letter:
        P.text(0.04, 0.985, letter, ha="left", va="top", fontsize=8.5, fontweight="bold")
    for k, (lbl, c) in enumerate([("Sham", SHAM), ("SNI", SNI)]):
        y = 0.065 - k * 0.05
        x0, y0 = P.xy(0.80, y - 0.011)
        fig.patches.append(plt.Rectangle((x0, y0), 0.02 * P.w, 0.024 * P.h, transform=fig.transFigure,
                                         color=c, figure=fig))
        P.text(0.83, y, lbl, va="center", fontsize=5.0)
    return ax


def main():
    st, long = compute()
    st.drop(columns=["mean_sham", "mean_sni"]).to_csv(TAB / "figS7D_predefined_homeostatic_geneset.csv", index=False)
    print(st.round(2).to_string(index=False))
    print(f"lower in SNI: {(st.log2FC < 0).sum()}/16")
    fig = plt.figure(figsize=(SLOT_PX[0] / SLOT_DPI, SLOT_PX[1] / SLOT_DPI))
    draw(fig, Panel(fig), st, long)
    stem = OUT / "FigS7D_predefined_homeostatic_geneset"
    for ext in ("pdf", "svg"):
        fig.savefig(f"{stem}.{ext}")
    fig.savefig(f"{stem}_600dpi.png", dpi=600)
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
