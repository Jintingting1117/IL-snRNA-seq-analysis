#!/usr/bin/env python3
"""Functional enrichment of the Slc6a11-containing (turquoise) WGCNA module (Fig. S7G).

Enrichr over-representation analysis (gseapy.enrichr; online) of the turquoise-module genes from
scil_wgcna.R against seven libraries; terms with adjusted P < 0.1 are kept.
Output: results/scil_reanalysis/tables/astro_wgcna_turquoise_comprehensive.csv
"""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import gseapy as gp

TAB = Path("results/scil_reanalysis/tables")
LIBS = ["GO_Biological_Process_2021", "GO_Molecular_Function_2021", "GO_Cellular_Component_2021",
        "KEGG_2019_Mouse", "Reactome_2022", "WikiPathways_2019_Mouse", "MSigDB_Hallmark_2020"]


def main():
    mods = pd.read_csv(TAB / "astro_wgcna_gene_modules.csv")
    genes = mods.loc[mods["module"] == "turquoise", "gene"].tolist()
    enr = gp.enrichr(gene_list=genes, gene_sets=LIBS, organism="mouse", outdir=None, cutoff=1.0)
    res = enr.results
    sig = res[res["Adjusted P-value"] < 0.1].reset_index(drop=True)
    sig.to_csv(TAB / "astro_wgcna_turquoise_comprehensive.csv", index=False)
    print(f"turquoise module: {len(genes)} genes; {len(sig)} terms with adjusted P < 0.1")
    print(sig["Gene_set"].value_counts().to_string())


if __name__ == "__main__":
    main()
