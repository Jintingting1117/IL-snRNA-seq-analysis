#!/usr/bin/env python3
"""Figure S8F: JASPAR NRF1 motif (MA0506.2) with the aligned human SLC6A11 (+409) and mouse
Slc6a11 (+412) intron-1 matches.

Standalone version of the header inset drawn in scil_fig_nrf1_chip_combined.py (same drawing code and
figure geometry); the ChIP-seq tracks of Figure S8G-H are drawn by scil_fig_s8gh_chip_panels.py.
Input: results/scil_reanalysis/tables/nrf1_pfm.csv (scil_nrf1_promoter_prep.py).
"""
import os
from pathlib import Path
import pandas as pd, logomaker
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["svg.fonttype"] = "none"
matplotlib.rcParams["pdf.fonttype"] = 42
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch

ROOT = Path(os.environ.get("SCIL_ROOT", Path(__file__).resolve().parents[1]))
OUT = ROOT / "results/scil_reanalysis/figures/revision_1011"; OUT.mkdir(parents=True, exist_ok=True)
PFM_PATH = ROOT / "results/scil_reanalysis/tables/nrf1_pfm.csv"
BASE_COL = {"A": "#008000", "C": "#0000CC", "G": "#E69F00", "T": "#CC0000"}
HUM_SEQ, MOU_SEQ, CORE_S = "TCCCGCGCCTGCGTG", "CTCTGCGCCTGCGTG", 4

fig = plt.figure(figsize=(9.4, 11.0), dpi=300)
fig.add_artist(FancyBboxPatch((0.305, 0.812, ), 0.42, 0.150, transform=fig.transFigure,
               boxstyle="round,pad=0.006,rounding_size=0.010",
               facecolor="#F7F7F4", edgecolor="#BBBBBB", lw=0.8, zorder=0))
pfm = pd.read_csv(PFM_PATH)
info = logomaker.transform_matrix(pfm.div(pfm.sum(axis=1), axis=0), from_type="probability", to_type="information")
ax_logo = fig.add_axes([0.435, 0.895, 0.255, 0.052]); ax_logo.set_facecolor("none")
logomaker.Logo(info, ax=ax_logo, color_scheme="classic", show_spines=False)
ax_logo.set_ylim(0, 2); ax_logo.set_xticks([]); ax_logo.set_xlim(-0.5, 14.5)
ax_logo.set_yticks([0, 2]); ax_logo.set_yticklabels(["0", "2"], fontsize=6)
ax_logo.set_ylabel("bits", fontsize=6.2, labelpad=1); ax_logo.tick_params(length=1.4, pad=1)
fig.text(0.345, 0.955, "JASPAR NRF1  ·  MA0506.2", ha="left", va="bottom", fontsize=8.5, fontweight="bold", color="#333")

ax_seq = fig.add_axes([0.435, 0.845, 0.255, 0.045]); ax_seq.set_facecolor("none"); ax_seq.axis("off")
ax_seq.set_xlim(-0.5, len(HUM_SEQ) - 0.5); ax_seq.set_ylim(0, 1)
ax_seq.add_patch(Rectangle((CORE_S - 0.5, 0.04), len(HUM_SEQ) - CORE_S, 0.92,
                 facecolor="#FCE7C9", edgecolor="#E4A94F", lw=0.8, zorder=0))
for row_y, seq, tag, tcol, fy in [(0.72, HUM_SEQ, "human", "#111", 0.877), (0.26, MOU_SEQ, "mouse", "#555", 0.856)]:
    fig.text(0.432, fy, tag, ha="right", va="center", fontsize=6.8, color=tcol, style="italic")
    for i, b in enumerate(seq):
        ax_seq.text(i, row_y, b, ha="center", va="center", family="monospace", fontsize=7.8, fontweight="bold", color=BASE_COL[b], zorder=2)
fig.text(0.345, 0.822, "core GCGCCTGCGTG identical (11/11)  ·  human +409 / mouse +412", ha="left", va="bottom", fontsize=6.9, color="#555")

# crop to the inset box (the drawing uses figure coordinates of the original 9.4 x 11 in canvas)
W, H = fig.get_size_inches()
bbox = matplotlib.transforms.Bbox([[0.295 * W, 0.800 * H], [0.735 * W, 0.972 * H]])
for ext in ("png", "pdf", "svg"):
    fig.savefig(OUT / f"FigS8F_NRF1_motif.{ext}", dpi=300, bbox_inches=bbox)
print("wrote", OUT / "FigS8F_NRF1_motif.{png,pdf,svg}")
