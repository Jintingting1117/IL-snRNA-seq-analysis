#!/usr/bin/env python3
"""Build astrocyte metacells (within-condition) for robust co-expression / WGCNA.

Single-cell pairwise correlation is dropout-noisy and, pooled across conditions, conflates the
sham/SNI batch difference with co-expression. Metacells (k-means on the Harmony latent space,
WITHIN each condition so none mixes sham+SNI) reduce dropout. mt/ribo/hb genes are dropped.

Manuscript setting (Fig. S7E-G): states Homeostatic/Synapse-associated/Reactive, 80 k-means clusters per
group (clusters with < 3 nuclei discarded -> 101 metacells, median 15 nuclei), the 5,000 most variable
genes detected in > 10% of nuclei.

--substates restricts to a subset of states (e.g. only 'Synapse-associated' to remove between-state
identity, asking what co-regulates with Slc6a11 WITHIN a state). --suffix names the output files.
"""
from __future__ import annotations
import argparse, os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import numpy as np
import pandas as pd
import scanpy as sc
import warnings
from scipy import sparse
from sklearn.cluster import KMeans
warnings.simplefilter("ignore")

OBJ = Path("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
OUT = Path("results/scil_reanalysis/tables")
MIN_DET = 0.10
SEED = 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--substates", default="Homeostatic,Synapse-associated,Reactive")
    ap.add_argument("--n-mc", type=int, default=80, help="k-means clusters per group (0 = use --cells-per-mc)")
    ap.add_argument("--cells-per-mc", type=int, default=15)
    ap.add_argument("--n-hvg", type=int, default=5000)
    ap.add_argument("--suffix", default="")
    args = ap.parse_args()
    keep_states = [s.strip() for s in args.substates.split(",")]

    a = sc.read_h5ad(OBJ)
    a = a[a.obs["substate"].astype(str).isin(keep_states)].copy()
    X = a.X.toarray() if sparse.issparse(a.X) else np.asarray(a.X)
    det = (X > 0).mean(0)
    vl = a.var_names.str.lower()
    tech = (np.asarray(vl.str.startswith("mt-")) | np.asarray(vl.str.startswith(("rps", "rpl")))
            | np.asarray(vl.str.match(r"^hb[ab]")))
    keep = (det > MIN_DET) & ~tech
    gi = np.where(keep)[0]
    hv = gi[np.argsort(X[:, keep].var(0))[::-1][:args.n_hvg]]
    if a.var_names.get_loc("Slc6a11") not in hv:
        hv = np.append(hv, a.var_names.get_loc("Slc6a11"))
    genes = a.var_names[hv].to_numpy(); Xg = X[:, hv]

    mc_rows, meta = [], []
    for cond in ["sham", "sni"]:
        m = (a.obs["condition"].astype(str) == cond).to_numpy()
        if m.sum() < 10:
            continue
        k = args.n_mc if args.n_mc > 0 else max(6, int(m.sum() // args.cells_per_mc))
        km = KMeans(n_clusters=k, random_state=SEED, n_init=10).fit(a.obsm["X_pca_harmony"][m])
        Xc = Xg[m]; sub = a.obs["substate"].astype(str).values[m]
        for c in range(k):
            cm = km.labels_ == c
            if cm.sum() < 3:
                continue
            mc_rows.append(Xc[cm].mean(0))
            meta.append({"metacell": f"{cond}_mc{c}", "condition": cond, "n_cells": int(cm.sum()),
                         "substate_top": pd.Series(sub[cm]).mode()[0]})
    M = pd.DataFrame(np.vstack(mc_rows), columns=genes, index=[r["metacell"] for r in meta])
    md = pd.DataFrame(meta).set_index("metacell"); md["Slc6a11"] = M["Slc6a11"].values
    M.to_csv(OUT / f"astro_metacell_expr{args.suffix}.csv")
    md.to_csv(OUT / f"astro_metacell_meta{args.suffix}.csv")
    print(f"[{args.substates}] metacells: {M.shape[0]} (sham {md.condition.eq('sham').sum()}/sni "
          f"{md.condition.eq('sni').sum()}); genes: {M.shape[1]}; median cells/mc: {md.n_cells.median():.0f}")


if __name__ == "__main__":
    main()
