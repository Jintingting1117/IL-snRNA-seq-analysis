#!/usr/bin/env bash
# Download the NRF1 ChIP-seq bigWig tracks used by scil_fig_nrf1_chip_{mouse,human,combined}.py.
# Source: ChIP-Atlas (https://chip-atlas.dbcls.jp). Files are large (~1.5 GB total) and are NOT
# committed to the repo; run this once to populate the bigWig directory.
#
# Destination (override with NRF1_BW_DIR):  <repo>/results/scil_reanalysis/chip_bigwig
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${NRF1_BW_DIR:-$ROOT/results/scil_reanalysis/chip_bigwig}"
BASE="https://chip-atlas.dbcls.jp/data"
mkdir -p "$DEST"

# mouse (mm10) -> plain SRX*.bw
MM_SRX=(SRX12197087 SRX12197081 SRX1280435)
# human (hg38) -> hs_SRX*.bw  (all ENCODE)
HS_SRX=(SRX2636389 SRX150388 SRX186635)

fetch () {  # $1=url  $2=outfile
  if [ -s "$2" ]; then echo "  have $(basename "$2")"; return; fi
  echo "  downloading $(basename "$2")"
  curl -fSL --retry 3 -o "$2" "$1"
}

echo "mouse (mm10) NRF1 bigWigs -> $DEST"
for srx in "${MM_SRX[@]}"; do fetch "$BASE/mm10/eachData/bw/${srx}.bw" "$DEST/${srx}.bw"; done
echo "human (hg38) NRF1 bigWigs -> $DEST"
for srx in "${HS_SRX[@]}"; do fetch "$BASE/hg38/eachData/bw/${srx}.bw" "$DEST/hs_${srx}.bw"; done

echo "done. bigWig dir: $DEST"
