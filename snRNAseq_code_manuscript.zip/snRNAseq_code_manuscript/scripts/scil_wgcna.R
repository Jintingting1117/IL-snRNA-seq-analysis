#!/usr/bin/env Rscript
# WGCNA co-expression modules on astrocyte metacells -> find the Slc6a11 module.
# Input: metacell x gene matrix + metadata (from scil_astro_metacells.py).
suppressMessages(library(WGCNA))
options(stringsAsFactors = FALSE)
enableWGCNAThreads(8)

args <- commandArgs(trailingOnly = TRUE)
suffix <- if (length(args) >= 1) args[1] else ""          # e.g. "_synapse"
minMod <- if (length(args) >= 2) as.integer(args[2]) else 30
tab <- "results/scil_reanalysis/tables"
datExpr <- as.matrix(read.csv(file.path(tab, sprintf("astro_metacell_expr%s.csv", suffix)), row.names = 1, check.names = FALSE))
meta   <- read.csv(file.path(tab, sprintf("astro_metacell_meta%s.csv", suffix)), row.names = 1, check.names = FALSE)
cat(sprintf("suffix='%s'  minModuleSize=%d\n", suffix, minMod))
meta   <- meta[rownames(datExpr), ]
cat(sprintf("datExpr: %d metacells x %d genes\n", nrow(datExpr), ncol(datExpr)))

gsg <- goodSamplesGenes(datExpr, verbose = 0)
datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]

# soft-threshold power
powers <- c(1:10, seq(12, 30, 2))
sft <- pickSoftThreshold(datExpr, powerVector = powers, networkType = "signed", verbose = 0)
ok <- which(-sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2] > 0.80)
power <- if (length(ok)) powers[min(ok)] else 12
cat(sprintf("chosen soft power: %d\n", power))

net <- blockwiseModules(datExpr, power = power, networkType = "signed", TOMType = "signed",
                        minModuleSize = minMod, mergeCutHeight = 0.25, deepSplit = 2,
                        numericLabels = TRUE, maxBlockSize = 6000, verbose = 0, randomSeed = 0)
moduleColors <- labels2colors(net$colors)
genes <- colnames(datExpr)
gmod <- data.frame(gene = genes, module = moduleColors)
write.csv(gmod, file.path(tab, sprintf("astro_wgcna_gene_modules%s.csv", suffix)), row.names = FALSE)
cat("modules:\n"); print(table(moduleColors))

# module eigengenes
MEs <- moduleEigengenes(datExpr, moduleColors)$eigengenes
MEs <- orderMEs(MEs)

# traits: condition (sni=1) and Slc6a11 metacell expression
trait_cond <- as.numeric(meta$condition == "sni")
trait_slc  <- as.numeric(meta$Slc6a11)
mt <- data.frame(module = sub("^ME", "", colnames(MEs)),
                 size = as.integer(table(moduleColors)[sub("^ME", "", colnames(MEs))]),
                 cor_condition = NA, p_condition = NA, cor_slc6a11 = NA, p_slc6a11 = NA)
for (i in seq_len(ncol(MEs))) {
  cc <- cor.test(MEs[, i], trait_cond); cs <- cor.test(MEs[, i], trait_slc)
  mt$cor_condition[i] <- cc$estimate; mt$p_condition[i] <- cc$p.value
  mt$cor_slc6a11[i]  <- cs$estimate; mt$p_slc6a11[i]  <- cs$p.value
}
mt <- mt[order(-abs(mt$cor_slc6a11)), ]
write.csv(mt, file.path(tab, sprintf("astro_wgcna_module_trait%s.csv", suffix)), row.names = FALSE)
cat("\nmodule-trait (sorted by |cor with Slc6a11|):\n"); print(mt, digits = 2)

# which module is Slc6a11 in? + hub genes (kME) of that module
slc_mod <- gmod$module[gmod$gene == "Slc6a11"]
cat(sprintf("\n>>> Slc6a11 is in module: %s (size %d)\n", slc_mod, sum(moduleColors == slc_mod)))
kME <- signedKME(datExpr, MEs)
modgenes <- genes[moduleColors == slc_mod]
kcol <- paste0("kME", slc_mod)
ord <- order(-kME[moduleColors == slc_mod, kcol])
hub <- data.frame(gene = modgenes[ord], kME = kME[moduleColors == slc_mod, kcol][ord])
write.csv(hub, file.path(tab, sprintf("astro_wgcna_slc6a11_module%s.csv", suffix)), row.names = FALSE)
cat(sprintf("Slc6a11 module top hub genes:\n%s\n", paste(head(hub$gene, 30), collapse = ", ")))

# top hub genes (kME) for EVERY module -> for supplementary per-module figures
allhubs <- do.call(rbind, lapply(setdiff(unique(moduleColors), "grey"), function(mod) {
  mg <- genes[moduleColors == mod]
  k  <- kME[moduleColors == mod, paste0("kME", mod)]
  o  <- order(-k)
  data.frame(module = mod, gene = mg[o], kME = k[o])[seq_len(min(20, length(mg))), ]
}))
write.csv(allhubs, file.path(tab, sprintf("astro_wgcna_all_hubs%s.csv", suffix)), row.names = FALSE)
cat("wrote all-module hubs\nDONE\n")
