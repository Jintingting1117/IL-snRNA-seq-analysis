#!/usr/bin/env python3
"""Excitatory-neuron subset for Figure S7A-C  ->  results/scil_reanalysis/objects/excitatory_subset.h5ad

Excitatory nuclei of the annotated dataset (celltype_final == "Excitatory_neuron"; 7,320 nuclei):
  - clusters ("sub"): Leiden, resolution 0.5, on a 15-nearest-neighbour graph of the dataset-wide
    Harmony embedding (X_pca_harmony, inherited from scil_reanalysis.py);
  - layout (X_umap): UMAP of a 15-NN graph on the subset's own PCA (2,000 HVGs, scaled, 30 PCs);
  - subtype markers: Wilcoxon, each cluster vs the rest.
Cluster -> subtype labels (and removal of the 29-nucleus microglia-doublet cluster 2) are defined in
scil_fig_excitatory.py.
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
from pathlib import Path
import warnings
import scanpy as sc

warnings.simplefilter("ignore")
OBJ = Path("results/scil_reanalysis/objects")
SEED = 0


def main():
    a = sc.read_h5ad(OBJ / "scil_reanalysis_annotated.h5ad")
    e = a[a.obs["celltype_final"].astype(str) == "Excitatory_neuron"].copy()
    del a
    print(f"excitatory nuclei: {e.n_obs}")

    sc.pp.highly_variable_genes(e, n_top_genes=2000, flavor="seurat")
    hv = e[:, e.var["highly_variable"].to_numpy()].copy()
    sc.pp.scale(hv, max_value=10)
    sc.tl.pca(hv, n_comps=30, svd_solver="arpack", random_state=SEED)
    e.obsm["X_pca"] = hv.obsm["X_pca"]

    # layout: UMAP on the subset PCA
    sc.pp.neighbors(e, n_neighbors=15, use_rep="X_pca", random_state=SEED)
    sc.tl.umap(e, random_state=SEED)

    # clusters: Leiden on the dataset-wide Harmony embedding
    sc.pp.neighbors(e, n_neighbors=15, use_rep="X_pca_harmony", random_state=SEED)
    sc.tl.leiden(e, resolution=0.5, key_added="sub", random_state=SEED, flavor="igraph",
                 n_iterations=2, directed=False)
    print("[clusters]", e.obs["sub"].value_counts().sort_index().to_dict())

    sc.tl.rank_genes_groups(e, "sub", method="wilcoxon", use_raw=True)
    e.write_h5ad(OBJ / "excitatory_subset.h5ad")
    print("wrote", OBJ / "excitatory_subset.h5ad")


if __name__ == "__main__":
    main()
