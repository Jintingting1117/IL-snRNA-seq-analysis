#!/usr/bin/env python3
"""WGCNA co-expression modules: the Slc6a11 module and its decline in SNI (rigorous version).

a  Modules positioned by eigengene correlation with condition (x) vs with Slc6a11 (y); points are
   WGCNA modules (colored by module, sized by size). The turquoise module = the Slc6a11 module
   (top-left: Slc6a11-up, SNI-down); black = the opposite (SNI-up).
b  Top hub genes (kME) of the Slc6a11/turquoise module — transporters/channels highlighted.
c  Pathway enrichment of the turquoise (Slc6a11) module.

Metacell-based WGCNA (within-condition metacells, mt/ribo excluded) -> robust to dropout and to the
sham/SNI batch artifact that distorted naive single-cell correlation. n=1/condition (module-condition
association is exploratory; module structure is valid).
"""
from __future__ import annotations
import os
from pathlib import Path
os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
warnings.simplefilter("ignore")

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"; plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8,
                     "axes.spines.right": False, "axes.spines.top": False})
TAB = Path("results/scil_reanalysis/tables"); OUT = Path("results/scil_reanalysis/figures/pub")
HIGHLIGHT = {"Slc6a11", "Slc6a1", "Kcnj10", "Slc4a4", "Car10", "Gria1", "Slc25a18", "Cntn1"}
MODCOLOR = {"turquoise": "#1FB6B6", "black": "#333333", "brown": "#9C6B3F", "blue": "#3775BA",
            "red": "#C0392B", "green": "#3a9c54", "pink": "#E59AB8", "yellow": "#D8B72E"}


def panel_modules(ax):
    # per-module label offset (dx_pt, dy_pt, ha, va) to avoid overlap of nearby modules
    OFF = {"turquoise": (7, -1, "left", "center"), "brown": (-6, 5, "right", "bottom"),
           "blue": (7, -4, "left", "top"), "pink": (-4, 8, "right", "bottom"),
           "yellow": (7, -4, "left", "top"), "green": (-3, 6, "right", "bottom"),
           "red": (7, -1, "left", "center"), "black": (-7, -1, "right", "center")}
    mt = pd.read_csv(TAB / "astro_wgcna_module_trait.csv")
    mt = mt[mt.module != "grey"]
    for _, r in mt.iterrows():
        c = MODCOLOR.get(r["module"], "#888888")
        hero = r["module"] in ("turquoise", "black")
        ax.scatter(r["cor_condition"], r["cor_slc6a11"], s=20 + r["size"] * 0.28, c=c,
                   edgecolor="black" if hero else "white", linewidth=0.8 if hero else 0.4, zorder=3,
                   alpha=0.95)
        lab = r["module"] + ("  (Slc6a11 module)" if r["module"] == "turquoise" else "")
        dx, dy, ha, va = OFF.get(r["module"], (5, 5, "left", "bottom"))
        ax.annotate(lab, (r["cor_condition"], r["cor_slc6a11"]), xytext=(dx, dy),
                    textcoords="offset points", fontsize=5.6, ha=ha, va=va,
                    fontweight="bold" if hero else "normal",
                    color=c if r["module"] != "yellow" else "#9c8412")
    ax.axhline(0, color="0.6", lw=0.7); ax.axvline(0, color="0.6", lw=0.7)
    ax.set_xlim(-0.80, 0.82); ax.set_ylim(-0.6, 1.02)
    ax.set_xlabel("module eigengene cor. with condition (SNI)")
    ax.set_ylabel("module eigengene cor. with Slc6a11")
    ax.set_title("WGCNA modules vs Slc6a11 & condition", fontsize=8, pad=4)


def panel_hub(ax):
    hub = pd.read_csv(TAB / "astro_wgcna_slc6a11_module.csv").head(20).iloc[::-1]
    y = np.arange(len(hub))
    colors = ["#C0392B" if g in HIGHLIGHT else "#1FB6B6" for g in hub["gene"]]
    ax.barh(y, hub["kME"], color=colors, height=0.72, edgecolor="white", linewidth=0.4)
    ax.set_yticks(y); ax.set_yticklabels(hub["gene"], fontsize=5.8, style="italic")
    for tl, g in zip(ax.get_yticklabels(), hub["gene"]):
        if g in HIGHLIGHT:
            tl.set_color("#C0392B"); tl.set_fontweight("bold")
    ax.set_xlabel("module membership (kME)")
    ax.set_title("Slc6a11 (turquoise) module hub genes", fontsize=8, pad=4)
    ax.set_xlim(min(0.5, hub["kME"].min() - 0.02), 1.0)
    ax.scatter([], [], marker="s", color="#C0392B", label="transporters / channels")
    ax.legend(loc="lower right", fontsize=5.4, frameon=False)


def panel_enrich(ax):
    # REAL enriched terms across the module's relevant themes (peri-synaptic, process cytoskeleton,
    # ErbB/RTK), shown uniformly. No standalone GABAergic term is enriched (only 3 GABA genes), so
    # the GABA arm is noted as module members.
    comp = pd.read_csv(TAB / "astro_wgcna_turquoise_comprehensive.csv")
    CUR = [("regulation of cation channel activity", "Cation-channel regulation"),
           ("regulation of neurotransmitter receptor activity", "Neurotransmitter-receptor reg."),
           ("modulation of chemical synaptic", "Synaptic transmission modulation"),
           ("RHO GTPase Cycle", "Rho-GTPase cycle"),
           ("regulation of cell migration", "Cell-migration regulation"),
           ("Signaling By Receptor Tyrosine Kinases", "Receptor tyrosine-kinase sig."),
           ("ErbB signaling pathway", "ErbB signaling (Erbb4)")]
    rows = []
    for key, disp in CUR:
        h = comp[comp["Term"].str.contains(key, case=False, regex=False)].sort_values("Adjusted P-value")
        if len(h):
            rows.append({"disp": disp, "nlp": -np.log10(h["Adjusted P-value"].iloc[0])})
    d = pd.DataFrame(rows).sort_values("nlp")
    y = np.arange(len(d))
    ax.barh(y, d["nlp"], color="#1FB6B6", height=0.74, edgecolor="white", linewidth=0.4)
    ax.set_yticks(y); ax.set_yticklabels(d["disp"], fontsize=5.8)
    ax.set_xlabel("-log10 adjusted P")
    ax.set_title("Slc6a11 module — peri-synaptic, process & trophic", fontsize=7.2, pad=13)
    ax.text(0.0, 1.02, "GABA-clearance members: Slc6a11/GAT-3 · Slc6a1/GAT-1 · Gabra2",
            transform=ax.transAxes, fontsize=5.0, style="italic", color="#178f8f", va="bottom")
    ax.axvline(-np.log10(0.05), color="0.5", ls="--", lw=0.8)


def main():
    fig = plt.figure(figsize=(8.9, 3.4))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 0.78, 1.28], wspace=0.6)
    ax_a = fig.add_subplot(gs[0, 0]); panel_modules(ax_a)
    ax_b = fig.add_subplot(gs[0, 1]); panel_hub(ax_b)
    ax_c = fig.add_subplot(gs[0, 2]); panel_enrich(ax_c)
    for ax, lab, dx in [(ax_a, "a", -0.24), (ax_b, "b", -0.40), (ax_c, "c", -0.5)]:
        ax.text(dx, 1.05, lab, transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom")
    fig.text(0.5, -0.03, "WGCNA on 101 astrocyte metacells (within-condition; mt/ribo excluded). "
             "n = 1 library/condition — module–condition association exploratory; module structure valid.",
             ha="center", fontsize=5.0, color="0.5")
    stem = OUT / "fig_wgcna_slc6a11"
    for ext in ["svg", "pdf"]:
        fig.savefig(f"{stem}.{ext}", bbox_inches="tight")
    fig.savefig(f"{stem}.png", dpi=400, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem)


if __name__ == "__main__":
    main()
