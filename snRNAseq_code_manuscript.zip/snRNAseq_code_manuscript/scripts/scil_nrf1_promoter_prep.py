#!/usr/bin/env python3
"""Prep for the NRF1 promoter-structure figure: NRF1 motif PFM, its sites on the Slc6a11 promoter,
and a parallel TF-comparison matrix (evidence-based). Saves intermediates so the figure can iterate."""
from __future__ import annotations
import io, re, time
from pathlib import Path
import requests
import numpy as np
import pandas as pd
import scanpy as sc
import decoupler as dc
import warnings
from scipy import sparse
from scipy.stats import mannwhitneyu
from Bio import motifs
from Bio.Seq import Seq
warnings.simplefilter("ignore")

TAB = Path("results/scil_reanalysis/tables")
ENS = "https://rest.ensembl.org"; HDRJ = {"Content-Type": "application/json"}
UP, DOWN = 2500, 500
CANDS = ["Nrf1", "Klf9", "Srebf1", "Srebf2", "Esrrg", "Tcf12"]
# Slc6a11-associated program (STAR Methods); n_program_targets = CollecTRI targets of the TF in this set
PROG = ["Slc6a11", "Slc6a1", "Atp1b1", "Atp1a2", "Atp1b2", "Gria1", "Gria2", "Gria3", "Gria4",
        "Grin2b", "Grin3a", "Kcnj10", "Slc4a4", "Slc25a18", "Slc25a5", "Car10"]


def get(url, headers=None, timeout=60, tries=8):
    """requests.get with retries (Ensembl REST / JASPAR occasionally return transient errors)."""
    for i in range(tries):
        try:
            r = requests.get(url, headers=headers, timeout=max(timeout, 60))
            if r.status_code == 200:
                return r
        except requests.RequestException:
            pass
        time.sleep(2 ** i)
    raise RuntimeError(f"request failed after {tries} attempts: {url}")


def main():
    # 1. NRF1 motif (MA0506.2)
    j = get("https://jaspar.genereg.net/api/v1/matrix/MA0506.2/", timeout=40).json()
    pfm = j["pfm"]
    pd.DataFrame({b: [float(x) for x in pfm[b]] for b in "ACGT"}).to_csv(TAB / "nrf1_pfm.csv", index=False)
    m = motifs.Motif(alphabet="ACGT", counts={b: [float(x) for x in pfm[b]] for b in "ACGT"})
    m.pseudocounts = 0.5; pssm = m.pssm; w = len(m)
    print(f"NRF1 motif len {w}, consensus {m.consensus}")

    # 2. Slc6a11 promoter (gene-oriented) + scan NRF1 sites
    info = get(f"{ENS}/lookup/symbol/mus_musculus/Slc6a11", headers=HDRJ, timeout=30).json()
    strand, chrom = info["strand"], info["seq_region_name"]
    tss = info["start"] if strand == 1 else info["end"]
    a, b = (tss - UP, tss + DOWN) if strand == 1 else (tss - DOWN, tss + UP)
    seq = get(f"{ENS}/sequence/region/mus_musculus/{chrom}:{a}..{b}:{strand}",
                       headers={"Content-Type": "text/plain"}, timeout=30).text.strip().upper()
    seq = re.sub("[^ACGT]", "A", seq)
    s = Seq(seq); rc = s.reverse_complement(); L = len(s)
    thr = 0.62 * pssm.max
    hits = []
    for i, sc_ in enumerate(pssm.calculate(s)):
        if sc_ >= thr:
            hits.append({"dist_tss": i + w // 2 - UP, "strand": "+", "score": round(float(sc_), 2), "seq": str(s[i:i + w])})
    for i, sc_ in enumerate(pssm.calculate(rc)):
        if sc_ >= thr:
            pf = L - w - i
            hits.append({"dist_tss": pf + w // 2 - UP, "strand": "-", "score": round(float(sc_), 2), "seq": str(rc[i:i + w])})
    hdf = pd.DataFrame(hits).sort_values("score", ascending=False)
    hdf.to_csv(TAB / "slc6a11_nrf1_sites.csv", index=False)
    print(f"NRF1 strong sites in Slc6a11 promoter (>= 0.8*max): {len(hdf)}")
    print(hdf.head(8).to_string(index=False))

    # 3. parallel TF comparison (evidence)
    ad = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    X = ad.X.toarray() if sparse.issparse(ad.X) else np.asarray(ad.X)
    cond = ad.obs["condition"].astype(str).values
    gi = {g: i for i, g in enumerate(ad.var_names)}

    def lfc(g):
        if g not in gi:
            return np.nan
        v = X[:, gi[g]]
        return float(np.log2((np.expm1(v[cond == "sni"].mean()) + 1e-9) / (np.expm1(v[cond == "sham"].mean()) + 1e-9)))

    cdf = pd.read_csv(TAB / "slc6a11_candidate_regulators.csv").set_index("TF")
    act = pd.read_csv(TAB / "astro_tf_sham_vs_sni.csv").set_index("TF")
    net = dc.op.collectri(organism="mouse")
    rows = []
    for tf in CANDS:
        tg = [g for g in set(net.loc[net.source == tf, "target"]) if g in ad.var_names]
        tl = [lfc(g) for g in tg]; tl = [x for x in tl if np.isfinite(x)]
        rows.append({"TF": tf,
                     "motif_z": cdf.loc[tf, "motif_z_vs_bg"], "motif_frac": cdf.loc[tf, "frac_of_max"],
                     "own_log2FC": cdf.loc[tf, "log2FC_sni"],
                     "activity_delta": float(act.loc[tf, "delta_sni"]) if tf in act.index else np.nan,
                     "target_mean_log2FC": round(float(np.mean(tl)), 3) if tl else np.nan,
                     "in_turquoise": int(cdf.loc[tf, "wgcna_module"] == "turquoise"),
                     "n_program_targets": len(set(tg) & set(PROG))})
    comp = pd.DataFrame(rows)
    comp.to_csv(TAB / "slc6a11_tf_comparison.csv", index=False)
    print("\nTF comparison matrix:")
    print(comp.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
