#!/usr/bin/env python3
"""Unbiased nomination of candidate Slc6a11 regulators (promoter motif + expression integration).

Scans the Slc6a11 promoter (TSS -2.5/+0.5 kb, GRCm39) with the full JASPAR CORE vertebrate motif
set, scores each TF motif vs a background of astrocyte-gene promoters (z-score => motif specifically
strong in the Slc6a11 promoter), then keeps only TFs that are (i) expressed in astrocytes and
(ii) co-vary with Slc6a11 (a regulator should track its target). Outputs a ranked candidate table.

Motif presence is hypothesis-generating, not proof of regulation.
"""
from __future__ import annotations
import io, time, re
from pathlib import Path
import requests
import numpy as np
import pandas as pd
import scanpy as sc
import warnings
from scipy import sparse
from scipy.stats import spearmanr
from Bio import motifs
from Bio.Seq import Seq
warnings.simplefilter("ignore")

TAB = Path("results/scil_reanalysis/tables")
ENS = "https://rest.ensembl.org"; HDRJ = {"Content-Type": "application/json"}
UP, DOWN = 2500, 500


def get(url, headers=None, timeout=60, tries=8):
    """requests.get with retries (Ensembl REST / JASPAR occasionally return transient errors)."""
    for i in range(tries):
        try:
            r = requests.get(url, headers=headers, timeout=max(timeout, 60))
            if r.status_code == 200:
                return r
        except requests.RequestException:
            pass
        time.sleep(2 ** i)
    raise RuntimeError(f"request failed after {tries} attempts: {url}")
# Background promoters for the motif z-score. The published analysis used these 13 genes: Aldoc, also in the
# original list, was not retrieved in that run (failed Ensembl request) and so did not enter the background.
BG_GENES = ["Aqp4", "Gja1", "Glul", "Slc1a3", "Apoe", "Sparcl1", "Gfap",
            "Atp1a2", "Fth1", "Clu", "Ntsr2", "Mt1", "Slc7a10"]
JASPAR_URLS = [
    "https://jaspar.genereg.net/download/data/2022/CORE/JASPAR2022_CORE_vertebrates_non-redundant_pfms_jaspar.txt",
    "https://jaspar.elixir.no/download/data/2022/CORE/JASPAR2022_CORE_vertebrates_non-redundant_pfms_jaspar.txt",
]


CACHE = Path("results/scil_reanalysis/cache/promoters")


def promoter(sym):
    """Promoter-proximal sequence (+ strand, TSS-UP..TSS+DOWN); cached locally after the first download."""
    fn = CACHE / f"{sym}_tss-{UP}_+{DOWN}.txt"
    if fn.exists():
        return fn.read_text().strip()
    seq = _promoter_remote(sym)
    CACHE.mkdir(parents=True, exist_ok=True); fn.write_text(seq)
    return seq


def _promoter_remote(sym):
    info = get(f"{ENS}/lookup/symbol/mus_musculus/{sym}", headers=HDRJ, timeout=25).json()
    tss = info["start"] if info["strand"] == 1 else info["end"]
    txt = get(f"{ENS}/sequence/region/mus_musculus/{info['seq_region_name']}:{tss-UP}..{tss+DOWN}:1",
                       headers={"Content-Type": "text/plain"}, timeout=25).text.strip().upper()
    return re.sub("[^ACGT]", "A", txt)


def best_score(pssm, fwd, rev):
    return float(max(pssm.calculate(fwd).max(), pssm.calculate(rev).max()))


def main():
    # 1. JASPAR motifs
    txt = None
    for u in JASPAR_URLS:
        try:
            txt = get(u, timeout=60).text; break
        except Exception:
            continue
    mlist = list(motifs.parse(io.StringIO(txt), "jaspar"))
    print(f"JASPAR motifs: {len(mlist)}")

    # 2. promoters (Slc6a11 + background)
    seqs = {}
    for g in ["Slc6a11"] + BG_GENES:
        try:
            seqs[g] = promoter(g); time.sleep(0.34)
        except Exception as e:
            print("  promoter fail", g, e)
    print(f"promoters fetched: {len(seqs)} (bg {len(seqs)-1})")
    if len(seqs) < 1 + len(BG_GENES):
        raise SystemExit("promoter download incomplete; the motif z-scores need all background promoters")
    prep = {g: (Seq(s), Seq(s).reverse_complement()) for g, s in seqs.items()}

    # 3. expression context from astrocytes
    a = sc.read_h5ad("results/scil_reanalysis/objects/astrocytes_deepdive.h5ad")
    X = a.X.toarray() if sparse.issparse(a.X) else np.asarray(a.X)
    slc = X[:, a.var_names.get_loc("Slc6a11")]
    cond = a.obs["condition"].astype(str).values
    gidx = {g: i for i, g in enumerate(a.var_names)}
    try:
        gmod = pd.read_csv(TAB / "astro_wgcna_gene_modules.csv").set_index("gene")["module"].to_dict()
    except Exception:
        gmod = {}

    def expr_ctx(tf):
        if tf not in gidx:
            return None
        v = X[:, gidx[tf]]
        if (v > 0).mean() < 0.05:
            return None
        s, n = v[cond == "sham"].mean(), v[cond == "sni"].mean()
        return {"pct": round(100 * (v > 0).mean(), 1), "mean_sham": round(float(s), 3), "mean_sni": round(float(n), 3),
                "log2FC_sni": round(float(np.log2((np.expm1(n) + 1e-9) / (np.expm1(s) + 1e-9))), 2),
                "corr_Slc6a11": round(float(spearmanr(slc, v).statistic), 3),
                "wgcna_module": gmod.get(tf, "")}

    # 4. scan: for each motif, best score in Slc6a11 vs background -> z; keep TFs expressed in astro
    rows = []
    for m in mlist:
        m.pseudocounts = 0.5
        pssm = m.pssm
        bs = {g: best_score(pssm, f, r) for g, (f, r) in prep.items()}
        bg = np.array([bs[g] for g in seqs if g != "Slc6a11"])
        z = (bs["Slc6a11"] - bg.mean()) / (bg.std() + 1e-9)
        for tf in re.split(r"::", m.name):
            sym = tf.strip().capitalize()
            ctx = expr_ctx(sym)
            if ctx is None:
                continue
            rows.append({"TF": sym, "jaspar": m.matrix_id, "slc6a11_motif_score": round(bs["Slc6a11"], 2),
                         "motif_z_vs_bg": round(float(z), 2), "frac_of_max": round(bs["Slc6a11"] / pssm.max, 2),
                         **ctx})
    df = pd.DataFrame(rows).sort_values("TF")
    # keep the best motif per TF (max z)
    df = df.sort_values("motif_z_vs_bg", ascending=False).drop_duplicates("TF")
    df.to_csv(TAB / "slc6a11_candidate_regulators.csv", index=False)

    # 5. prioritize: strong specific motif (z>1) AND co-vary with Slc6a11 (corr>0.1, i.e. down together)
    cand = df[(df.motif_z_vs_bg > 1.0) & (df.corr_Slc6a11 > 0.10)].sort_values("corr_Slc6a11", ascending=False)
    print(f"\nTFs scanned w/ astrocyte expression: {len(df)}")
    print(f"\n== Candidate Slc6a11 regulators (specific motif z>1 AND co-down with Slc6a11) ==")
    print(cand.head(18)[["TF", "motif_z_vs_bg", "frac_of_max", "pct", "log2FC_sni", "corr_Slc6a11", "wgcna_module"]].to_string(index=False))
    print(f"\n(for reference) Hif1a row:")
    print(df[df.TF == "Hif1a"][["TF", "motif_z_vs_bg", "frac_of_max", "log2FC_sni", "corr_Slc6a11"]].to_string(index=False))
    print("\nwrote", TAB / "slc6a11_candidate_regulators.csv")


if __name__ == "__main__":
    main()
