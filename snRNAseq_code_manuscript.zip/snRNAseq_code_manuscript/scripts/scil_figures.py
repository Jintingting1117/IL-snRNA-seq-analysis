#!/usr/bin/env python3
"""Publication-quality figures for the scIL PFC sham/SNI snRNA-seq re-analysis.

Produces a coarse cell-type UMAP and a PFC marker dot plot, each saved as both
PDF (vector, editable text) and PNG (300 dpi). Run after scil_reanalysis.py.
"""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "8")
os.environ.setdefault("OMP_NUM_THREADS", "8")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
import scanpy as sc
import warnings

warnings.simplefilter("ignore")

matplotlib.rcParams.update({
    "pdf.fonttype": 42,           # TrueType -> editable text in Illustrator
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 11,
    "axes.linewidth": 0.8,
    "figure.dpi": 150,
})

OBJ = Path("results/scil_reanalysis/objects/scil_reanalysis_annotated.h5ad")
OUT = Path("results/scil_reanalysis/figures/pub")
OUT.mkdir(parents=True, exist_ok=True)

# Coarse cell-type order, display names, on-UMAP abbreviations, and a fixed palette.
ORDER = ["Excitatory_neuron", "Inhibitory_neuron", "Astrocyte", "Oligodendrocyte", "OPC",
         "Microglia", "Endothelial", "Pericyte_VSMC", "Fibroblast_meningeal", "Ependymal"]
DISPLAY = {
    "Excitatory_neuron": "Excitatory neuron", "Inhibitory_neuron": "Inhibitory neuron",
    "Astrocyte": "Astrocyte", "Oligodendrocyte": "Oligodendrocyte", "OPC": "OPC",
    "Microglia": "Microglia", "Endothelial": "Endothelial", "Pericyte_VSMC": "Pericyte/VSMC",
    "Fibroblast_meningeal": "VLMC/Fibroblast", "Ependymal": "Ependymal",
}
ABBR = {
    "Excitatory_neuron": "ExN", "Inhibitory_neuron": "InN", "Astrocyte": "Astro",
    "Oligodendrocyte": "Oligo", "OPC": "OPC", "Microglia": "Micro", "Endothelial": "Endo",
    "Pericyte_VSMC": "Peri", "Fibroblast_meningeal": "VLMC", "Ependymal": "Epen",
}
PALETTE = {
    "Excitatory_neuron": "#3b6fb6", "Inhibitory_neuron": "#e8743b", "Astrocyte": "#4cae4c",
    "Oligodendrocyte": "#9467bd", "OPC": "#8c564b", "Microglia": "#d6427f",
    "Endothelial": "#17becf", "Pericyte_VSMC": "#bcbd22", "Fibroblast_meningeal": "#7f7f7f",
    "Ependymal": "#e6c200",
}
# PFC marker panel (keyed by display name) for the dot plot.
PFC_MARKERS = {
    "Excitatory neuron": ["Slc17a7", "Satb2"],
    "Inhibitory neuron": ["Gad1", "Gad2"],
    "Astrocyte": ["Aqp4", "Gja1", "Slc1a2"],
    "Oligodendrocyte": ["Plp1", "Mobp", "Mog"],
    "OPC": ["Pdgfra", "Cspg4"],
    "Microglia": ["Csf1r", "P2ry12", "C1qa"],
    "Endothelial": ["Cldn5", "Flt1"],
    "Pericyte/VSMC": ["Rgs5", "Pdgfrb"],
    "VLMC/Fibroblast": ["Col1a1", "Dcn"],
    "Ependymal": ["Foxj1", "Tmem212"],
}


def load():
    a = sc.read_h5ad(OBJ)
    a.obs["coarse"] = a.obs["celltype_final"].astype(str)
    present = [c for c in ORDER if c in set(a.obs["coarse"])]
    # Keep only well-defined coarse types for the publication panel.
    a = a[a.obs["coarse"].isin(present)].copy()
    a.obs["coarse"] = pd.Categorical(a.obs["coarse"], categories=present, ordered=True)
    return a, present


def save_both(fig, stem):
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(OUT / f"{stem}.png", dpi=300, bbox_inches="tight")


def umap_fig(a, present):
    xy = a.obsm["X_umap"]
    fig, ax = plt.subplots(figsize=(6.4, 5.2))
    for ct in present:
        mask = (a.obs["coarse"] == ct).to_numpy()
        ax.scatter(xy[mask, 0], xy[mask, 1], s=2.2, c=PALETTE[ct], linewidths=0,
                   rasterized=True, label=DISPLAY[ct])
    for ct in present:
        mask = (a.obs["coarse"] == ct).to_numpy()
        cx, cy = np.median(xy[mask, 0]), np.median(xy[mask, 1])
        ax.text(cx, cy, ABBR[ct], fontsize=8.5, fontweight="bold", ha="center", va="center",
                path_effects=[pe.withStroke(linewidth=2.2, foreground="white")])
    ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.set_title("PFC snRNA-seq — major cell types", fontsize=12, pad=8)
    leg = ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False,
                    markerscale=4.5, handletextpad=0.25, labelspacing=0.45, fontsize=9,
                    borderpad=0)
    for h in leg.legend_handles:
        h.set_rasterized(False)
    fig.tight_layout()
    save_both(fig, "umap_coarse_celltypes")
    plt.close(fig)


def umap_condition_fig(a):
    xy = a.obsm["X_umap"]
    pal = {"sham": "#4c72b0", "sni": "#c44e52"}
    fig, ax = plt.subplots(figsize=(5.6, 5.0))
    order = ["sham", "sni"]
    for cond in order:
        mask = (a.obs["condition"].astype(str) == cond).to_numpy()
        ax.scatter(xy[mask, 0], xy[mask, 1], s=2.0, c=pal[cond], linewidths=0,
                   rasterized=True, label=cond.upper(), alpha=0.6)
    ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.set_title("PFC snRNA-seq — condition", fontsize=12, pad=8)
    ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False,
              markerscale=5, fontsize=10)
    fig.tight_layout()
    save_both(fig, "umap_condition")
    plt.close(fig)


def dotplot_fig(a, present):
    a.obs["coarse_disp"] = a.obs["coarse"].cat.rename_categories(DISPLAY)
    cats = [DISPLAY[c] for c in present]
    a.obs["coarse_disp"] = pd.Categorical(a.obs["coarse_disp"], categories=cats, ordered=True)
    markers = {}
    for disp in cats:
        genes = [g for g in PFC_MARKERS.get(disp, []) if g in a.var_names]
        if genes:
            markers[disp] = genes
    dp = sc.pl.dotplot(
        a, markers, groupby="coarse_disp", categories_order=cats,
        standard_scale="var", cmap="Reds", return_fig=True, figsize=(9.5, 4.2),
        colorbar_title="Scaled mean\nexpression", size_title="Fraction of cells\nin group (%)",
    )
    dp.style(dot_edge_color="0.4", dot_edge_lw=0.25, grid=False)
    dp.savefig(OUT / "dotplot_pfc_markers.pdf", bbox_inches="tight")
    dp.savefig(OUT / "dotplot_pfc_markers.png", dpi=300, bbox_inches="tight")
    plt.close("all")


def main():
    a, present = load()
    print("Cells:", a.n_obs, "| coarse types:", present)
    umap_fig(a, present)
    umap_condition_fig(a)
    dotplot_fig(a, present)
    print("Wrote figures to", OUT)
    for f in sorted(OUT.iterdir()):
        print("  ", f.name)


if __name__ == "__main__":
    main()
