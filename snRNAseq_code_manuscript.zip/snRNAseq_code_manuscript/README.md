# Single-nucleus RNA-seq analysis and figure code

Code for the single-nucleus RNA-seq analyses of the infralimbic cortex (IL), Sham vs SNI, in
*Astrocytic metabolic remodeling links chronic pain to impaired social motivation*. It generates the
snRNA-seq panels of Figures 3A–3I, 5A–5G, S7A–S7G and S8A–S8H and the snRNA-seq supplementary data table.
Code that assembles panels into the composite figures is not included.

## Figure panels

| Panel | Script | Main inputs |
|---|---|---|
| Fig. 3A–B | `scil_figures.py` | `scil_reanalysis_annotated.h5ad` |
| Fig. 3C–D | `scil_fig_augur_pub.py` | `augur_celltype_auc.csv`, `augur_decomposition.csv` |
| Fig. 3E–H | `scil_fig3_astrocyte.py` | `astrocytes_deepdive.h5ad`, `astro_transport_axis_de.csv` |
| Fig. 3I | `scil_fig_slc6a11_program.py` (panel a) | `astrocytes_deepdive.h5ad` |
| Fig. 5A, 5C, 5G; Fig. S8E | `scil_fig_nrf1_axis.py` (panels a, b, c, d) | `nrf1_axis_kegg_full.csv`, `nrf1_axis_gsea_kegg.npz`, `nrf1_axis_resp_tf_activity.csv`, `nrf1_axis_pgc1a_mrna.csv`, `nrf1_axis_oxphos_genes.csv` |
| Fig. 5B (split view); Fig. S8A–D (top row) | `scil_fig_featureplots.py` | `astrocytes_deepdive.h5ad` |
| Fig. 5D–E | `scil_fig_nrf1_story2.py` (panels a, b) | `slc6a11_candidate_regulators.csv`, `slc6a11_tf_comparison.csv`, `slc6a11_tf_site_positions.csv` |
| Fig. 5F | `scil_fig_nrf1_program_targets.py` | `astrocytes_deepdive.h5ad` |
| Fig. S7A–C | `scil_fig_excitatory.py` | `excitatory_subset.h5ad` |
| Fig. S7D | `scil_fig_s7d_predefined_homeostatic.py` | `astrocytes_deepdive.h5ad` |
| Fig. S7E–G | `scil_fig_wgcna.py` | `astro_wgcna_module_trait.csv`, `astro_wgcna_slc6a11_module.csv`, `astro_wgcna_turquoise_comprehensive.csv` |
| Fig. S8F | `scil_fig_s8f_nrf1_motif.py` | `nrf1_pfm.csv` |
| Fig. S8G–H | `scil_fig_s8gh_chip_panels.py` | ChIP-Atlas bigWigs (`scil_fig_nrf1_chip_fetch_data.sh`) |
| Supplementary data table | `scil_supp_table_snrnaseq.py` | all of the above |

Several figure scripts draw more panels than appear in the manuscript (for example the enrichment panel of
`scil_fig3_astrocyte.py`); the table lists the panels that are used.

## Analysis scripts (run order)

| # | Script | Output (under `results/scil_reanalysis/`) |
|---|---|---|
| 1 | `scil_reanalysis.py` | QC, Scrublet, normalization, Harmony, Leiden, annotation → `objects/scil_reanalysis_annotated.h5ad`, `tables/qc_*.csv` |
| 2 | `scil_astrocyte_deepdive.py` | high-confidence astrocytes, reclustering, states, SNI vs Sham DE, Enrichr → `objects/astrocytes_deepdive.h5ad`, `tables/astro_*` |
| 3 | `scil_excitatory_subset.py` | excitatory-neuron subclusters → `objects/excitatory_subset.h5ad` |
| 4 | `scil_augur.py`, `scil_augur_matched.py` | cell-type prioritization, composition vs cell-intrinsic AUC |
| 5 | `scil_astro_metacells.py` → `scil_wgcna.R` → `scil_wgcna_enrichment.py` | metacells, WGCNA modules, turquoise-module enrichment |
| 6 | `scil_astrocyte_tf.py` | decoupleR/CollecTRI TF activity |
| 7 | `scil_slc6a11_regulators.py` | JASPAR motif screen of the Slc6a11 promoter-proximal region (217 TFs) |
| 8 | `scil_nrf1_promoter_prep.py`, `scil_slc6a11_tf_sites.py` | NRF1 PFM and intron-1 site, candidate-regulator evidence matrix, best-site positions |
| 9 | `scil_nrf1_axis_stats.py` | gene ranking, OXPHOS subunits, PGC-1α mRNA, respiratory-TF activity |
| 10 | `scil_gsea_kegg_hallmark.py` | GSEA prerank, KEGG 2019 Mouse and MSigDB Hallmark 2020 |
| 11 | `scil_nrf1_chip_peaks.py`, `scil_fig_nrf1_chip_fetch_data.sh` | NRF1 ChIP-seq peaks (ChIP-Atlas) and bigWig tracks |

`scil_panel_box.py` is a small layout helper imported by the S7D and S8G–H panel scripts.

## Running

```bash
bash run_all.sh               # from the processed objects (default)
bash run_all.sh --from-raw    # QC, integration and clustering from the Cell Ranger matrices
```

Scripts are run from the package root and read/write `results/scil_reanalysis/{objects,tables,figures}`.

Inputs:

- **Cell Ranger matrices** (`sham/EGFP/`, `sni/EGFP/`; `matrix.mtx.gz`, `features.tsv.gz`, `barcodes.tsv.gz`) —
  [GEO accession]. Needed only for `--from-raw`. The `noEGFP` folders hold the same libraries aligned to a reference
  without the EGFP transgene and are not used.
- **Processed objects** `scil_reanalysis_annotated.h5ad` (all 23,909 nuclei; annotation, Harmony embedding, UMAP)
  and `astrocytes_deepdive.h5ad` (1,821 astrocytic nuclei; states, astrocyte UMAP) — [GEO accession], placed in
  `results/scil_reanalysis/objects/`.
- **Downloaded at run time** (internet access needed): Enrichr libraries (gseapy), CollecTRI (decoupleR),
  JASPAR 2022 CORE vertebrates, Ensembl REST promoter sequences, ChIP-Atlas NRF1 peak files (~180 MB each) and
  bigWig tracks (~1.5 GB).
- `published_results/`: the QC summary tables, the gene ranking used for GSEA and the KEGG GSEA result drawn in
  Fig. 5A/5C (see below).

## Reproducibility

- Starting from the processed objects, `run_all.sh` reproduces every table and figure panel listed above
  (verified 2026-10-12 against the files used for the manuscript; see `VERIFICATION.md`).
- Harmony (harmonypy 0.2.0, PyTorch backend) does not return identical embeddings on repeated runs. Re-running
  `scil_reanalysis.py` from the raw matrices reproduces QC and doublet removal exactly (23,909 nuclei), but the
  clustering after integration, and therefore a small fraction of cell-type labels, can differ from the published
  object. The same applies to the astrocyte reclustering in `scil_astrocyte_deepdive.py`; with `--from-object`
  that script reuses the published astrocyte object and recomputes only the state annotation, differential
  expression and enrichment.
- About half of the genes share a value in the GSEA ranking, so permutation FDRs depend on how tied genes are
  ordered, and that order depends on the NumPy sort implementation. GSEA therefore uses the published ranking
  (`published_results/nrf1_axis_rank.csv`; same per-gene statistics as the re-computed
  `nrf1_axis_rank_rerun.csv`), and Fig. 5A/5C are drawn from the published KEGG result; the re-run from
  `scil_gsea_kegg_hallmark.py` is kept as `nrf1_axis_kegg_full_rerun.csv` (NES equal to two decimals, FDRs within
  permutation variability).
- The motif z-scores (`scil_slc6a11_regulators.py`) use 13 background promoters, as in the published analysis;
  promoter sequences are cached in `results/scil_reanalysis/cache/promoters/` after the first download.
- Results that depend on online resources (Enrichr, JASPAR, Ensembl, ChIP-Atlas) assume the library versions
  named in the scripts.

## Software

Python 3.13 with the packages in `requirements.txt`; R 4.5.1 with WGCNA 1.74.
