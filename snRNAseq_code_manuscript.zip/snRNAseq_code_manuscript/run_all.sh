#!/usr/bin/env bash
# Reproduce the snRNA-seq analyses and figure panels (Figs 3A-I, 5A-G, S7A-G, S8A-H) and the
# supplementary data table. Run from the package root.
#
#   bash run_all.sh             start from the processed objects (default; reproduces the published panels)
#   bash run_all.sh --from-raw  re-run QC, Scrublet, Harmony and clustering from the Cell Ranger matrices
#                               (sham/EGFP, sni/EGFP); see README "Reproducibility" before using this
#
# Set PYTHON to choose the interpreter (default: python3).
set -euo pipefail
cd "$(dirname "$0")"
PY=${PYTHON:-python3}
OBJ=results/scil_reanalysis/objects
TAB=results/scil_reanalysis/tables
mkdir -p "$OBJ" "$TAB"

echo "== 1. processed objects"
if [[ "${1:-}" == "--from-raw" ]]; then
  $PY scripts/scil_reanalysis.py --input-root . --outdir results/scil_reanalysis
  $PY scripts/scil_astrocyte_deepdive.py
else
  for f in scil_reanalysis_annotated.h5ad astrocytes_deepdive.h5ad; do
    [[ -s "$OBJ/$f" ]] || { echo "missing $OBJ/$f (processed object; see README)"; exit 1; }
  done
  cp published_results/qc_summary_by_sample.csv published_results/qc_thresholds.csv "$TAB/"
  $PY scripts/scil_astrocyte_deepdive.py --from-object
fi

echo "== 2. analyses"
$PY scripts/scil_excitatory_subset.py
$PY scripts/scil_augur.py
$PY scripts/scil_augur_matched.py
$PY scripts/scil_astro_metacells.py
Rscript scripts/scil_wgcna.R
$PY scripts/scil_wgcna_enrichment.py
$PY scripts/scil_astrocyte_tf.py
$PY scripts/scil_slc6a11_regulators.py
$PY scripts/scil_nrf1_promoter_prep.py
$PY scripts/scil_slc6a11_tf_sites.py
$PY scripts/scil_nrf1_axis_stats.py
# GSEA uses the published gene ranking: identical statistics, but the order of tied genes depends on the
# NumPy sort implementation; the re-computed ranking is kept as nrf1_axis_rank_rerun.csv (see README)
mv "$TAB/nrf1_axis_rank.csv" "$TAB/nrf1_axis_rank_rerun.csv"
cp published_results/nrf1_axis_rank.csv "$TAB/"
$PY scripts/scil_gsea_kegg_hallmark.py
# Fig. 5A/5C are drawn from the published KEGG GSEA result; the re-run is kept as *_rerun (see README)
for f in nrf1_axis_kegg_full.csv nrf1_axis_gsea_kegg.npz; do
  mv "$TAB/$f" "$TAB/${f%.*}_rerun.${f##*.}"
  cp "published_results/$f" "$TAB/$f"
done
$PY scripts/scil_nrf1_chip_peaks.py
bash scripts/scil_fig_nrf1_chip_fetch_data.sh

echo "== 3. figure panels"
$PY scripts/scil_figures.py                         # Fig. 3A-B
$PY scripts/scil_fig_augur_pub.py                   # Fig. 3C-D
$PY scripts/scil_fig3_astrocyte.py                  # Fig. 3E-H
$PY scripts/scil_fig_slc6a11_program.py             # Fig. 3I
$PY scripts/scil_fig_nrf1_axis.py                   # Fig. 5A, 5C, 5G, S8E
$PY scripts/scil_fig_featureplots.py                # Fig. 5B, S8A-D
$PY scripts/scil_fig_nrf1_story2.py                 # Fig. 5D-E
$PY scripts/scil_fig_nrf1_program_targets.py        # Fig. 5F
$PY scripts/scil_fig_excitatory.py                  # Fig. S7A-C
$PY scripts/scil_fig_s7d_predefined_homeostatic.py  # Fig. S7D
$PY scripts/scil_fig_wgcna.py                       # Fig. S7E-G
$PY scripts/scil_fig_s8f_nrf1_motif.py              # Fig. S8F
$PY scripts/scil_fig_s8gh_chip_panels.py            # Fig. S8G-H

echo "== 4. supplementary data table"
$PY scripts/scil_supp_table_snrnaseq.py results/TableS_snRNAseq.xlsx

echo "done: figures in results/scil_reanalysis/figures/{pub,revision_1011}, table in results/TableS_snRNAseq.xlsx"
